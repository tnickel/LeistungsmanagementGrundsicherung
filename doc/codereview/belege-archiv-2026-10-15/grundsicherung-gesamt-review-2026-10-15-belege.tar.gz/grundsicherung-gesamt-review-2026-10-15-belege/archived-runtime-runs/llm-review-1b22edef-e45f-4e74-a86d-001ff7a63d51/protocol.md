# Echte LLM-Nachprüfung

Prüfung: 1b22edef-e45f-4e74-a86d-001ff7a63d51
Modell (angefordert): glm-5.3
Ergebnis: PASS
Fälle: 18/18

Manifest, Requests und API-Antworten liegen im selben Verzeichnis; etwaige Schlüssel-Echos sind bereinigt und die gespeicherten Bytes mit SHA-256 gebunden.

## Sendeversuche

- Fallgruppe 1, Versuch 1: gültig; Request: request-1-attempt-1.json; Response: response-1-attempt-1.json

- Fallgruppe 2, Versuch 1: gültig; Request: request-2-attempt-1.json; Response: response-2-attempt-1.json

- Fallgruppe 3, Versuch 1: gültig; Request: request-3-attempt-1.json; Response: response-3-attempt-1.json

- Fallgruppe 4, Versuch 1: gültig; Request: request-4-attempt-1.json; Response: response-4-attempt-1.json

- Fallgruppe 5, Versuch 1: gültig; Request: request-5-attempt-1.json; Response: response-5-attempt-1.json

- Fallgruppe 6, Versuch 1: gültig; Request: request-6-attempt-1.json; Response: response-6-attempt-1.json

## POSITIV:run-20261015-100353-13234168534251085179:TF01
PASS

Eigene Nachrechnung p1: RBS Stufe 1 = 563.00; keine Mehrbedarfe (G/Schwangerschaft/Alleinerziehend/dezentrales Warmwasser alle nein). KdU = 550+75+100 = 725.00, kein zentraler WW-Abzug (Anteil 0), BG-Grenze 0 (deaktiviert). Gesamtbedarf = 1288.00. Einkommen 0, Freibetrag 0, Absetzungen 0, anrechenbar 0. Personen-zahlbetrag 1288.00 (vor Vermögenseinsatz). Vermögen 0, Schonvermögen 10000, verwertbar 0. BG-Zahlbetrag = 1288.00. budget_rest_hypothetisch = 1448.00 − 1288.00 = 160.00, deckt budget_rest_erwartet. Alle dokumentierten Zwischenwerte stimmen mit eigener Rechnung überein; Ablauf (Anlegen, Anordnen ANGELEGT, Vier-Augen-Wechsel zu sb-web-02, Freigabe BEREIT) konsistent mit V1–V6; V7 dokumentierte Zweitrechnung 0 Abweichungen; V8 durch globale Kopfprüfungen (60/60, 0 Übergaben ohne Freigabe) belegt.

Befunde: []

## NEGATIV:run-20261015-100608-12296938910290168033:TF01
PASS

Reiner Workflow-/Sperrlogikfall ohne Rechenblock; laut Auftrag keine personenbezogene Nachrechnung behauptet. Abwehr folgt zwingend aus den Regeln: IBAN mit falscher Prüfziffer verletzt ISO-13616-Modulo-97-Regel => VALIDATION 'Ungültige IBAN'; 7-Zeichen-BIC verletzt ISO 9362 (8 oder 11 Zeichen) => VALIDATION 'Ungültiger BIC'. STATE_SNAPSHOT-Prüfsummen V1/V2 identisch (5b91b99e37daf82f) belegen unveränderte Fachtabellen; V3 bestätigt kein angelegtes Aktenzeichen SWEET-NW-0001. Globale Laufprüfungen (49/49, 0 Übergaben ohne Freigabe) stützen V4.

Befunde: []

## POSITIV:run-20261015-100353-13234168534251085179:TF02
PASS

Eigene Nachrechnung p1: RBS Stufe 2 = 506.00; keine Mehrbedarfe. KdU = 290+100+130 = 520.00, kein WW-Abzug, Grenze deaktiviert. Gesamtbedarf = 1026.00. Einkommen/Freibeträge/Absetzungen 0, anrechenbar 0. Personen-zahlbetrag 1026.00. Vermögen 0, Schonvermögen 10000, verwertbar 0, BG-Zahlbetrag 1026.00. budget_rest_hypothetisch = 1146.00 − 1026.00 = 120.00 = budget_rest_erwartet. Ablauf mit Erfasser sb-web-02 und Freigabe durch sb-web-03 (Vier-Augen) konsistent mit V1–V6; V7 dokumentiert 0 Abweichungen; V8 durch globale Prüfungen belegt.

Befunde: []

## NEGATIV:run-20261015-100608-12296938910290168033:TF02
PASS

Eigenrechnung: RBS 3 = 451.00; keine Mehrbedarfe (kein G, nicht schwanger, keine Kinder, kein dezentrales Warmwasser); KdU = 370+95+105 = 570.00, keine BG-Grenze (0), kein zentraler WW-Abzug (Anteil 0); Gesamtbedarf = 1021.00; kein Einkommen/Absetz => anrechenbar 0.00, Personen-Zahlbetrag 1021.00; Vermögen 0 <= Schonvermögen 10000 => verwertbar 0.00, BG-Zahlbetrag 1021.00. budget_rest_hypothetisch = 941.00 - 1021.00 = -80.00; Zahlbetrag 1021.00 > Budget 941.00 => Abwehr BUDGET_ERSCHOEPFT zwingend, Budget bleibt 941.00. Alle dokumentierten Werte stimmen überein.

Befunde: []

## POSITIV:run-20261015-100353-13234168534251085179:TF03
PASS

Eigenrechnung: RBS 3 = 451.00; keine Mehrbedarfe (kein G, nicht schwanger, keine Kinder, kein Warmwasser-Zuschlag); KdU = 390+55+90 = 535.00; keine BG-Grenze (0), kein zentraler WW-Abzug; Gesamtbedarf = 986.00; kein Einkommen => anrechenbar 0.00, Personen-Zahlbetrag 986.00; Vermögen 0 => verwertbar 0.00, BG-Zahlbetrag 986.00; budget_rest_hypothetisch = 1186.00 - 986.00 = 200.00 = budget_rest_erwartet. Vier-Augen: Erfasser sb-web-03, Freigabe sb-web-01, Status BEREIT. Alles konsistent.

Befunde: []

## NEGATIV:run-20261015-100608-12296938910290168033:TF03
PASS

Eigenrechnung: RBS 3 = 451.00; keine Mehrbedarfe; KdU = 460+40+65 = 565.00; keine BG-Grenze, kein WW-Abzug; Gesamtbedarf = 1016.00; kein Einkommen => anrechenbar 0.00, Zahlbetrag 1016.00; Vermögen 0 => verwertbar 0.00; budget_rest_hypothetisch = 976.00 - 1016.00 = -40.00; Zahlbetrag 1016.00 > Budget 976.00 => BUDGET_ERSCHOEPFT-Abwehr zwingend, Budget bleibt 976.00. Alle Werte konsistent.

Befunde: []

## POSITIV:run-20261015-100353-13234168534251085179:TF04
PASS

Eigenständige Nachrechnung: RBS Stufe 2 = 506.00; keine Mehrbedarfe (G/Schwangerschaft/Alleinerziehend false, kein dezentrales Warmwasser); KdU = 440.00 + 115.00 + 100.00 = 655.00, kein zentraler WW-Abzug (Anteil 0), BG-Grenze 0 (deaktiviert); Gesamtbedarf 506 + 655 = 1161.00; kein Einkommen, anrechenbar 0.00; Vermögen 0 < Schonvermögen 10000, verwertbar 0.00; Personen-zahlbetrag = BG-Zahlbetrag = 1161.00; hypothetisches Restbudget 1311.00 − 1161.00 = 150.00. Tatsächlicher Endzustand: Storno bucht zurück, BUDGET_REST = 1311.00, Auszahlungsbetrag 1161.00, Status STORNIERT — alle SQL-Erwartungen decken sich mit Ablauf (Anordnung ANGELEGT, Vier-Augen-Freigabe durch sb-web-02 ≠ Erfasser sb-web-01, Admin-Storno). Alle Werte stimmen mit den dokumentierten überein.

Befunde: []

## NEGATIV:run-20261015-100608-12296938910290168033:TF04
PASS

Eigenständige Nachrechnung: RBS 2 = 506.00; alle Mehrbedarfe 0; KdU = 350.00 + 35.00 + 85.00 = 470.00 (kein WW-Abzug, Grenze 0); Gesamtbedarf 976.00; Einkommen 0, anrechenbar 0.00; Vermögen 0 < 10000, verwertbar 0.00; Personen-/BG-Zahlbetrag 976.00; hypothetisch 1146.00 − 976.00 = 170.00. Kein KEIN_ANSPRUCH; Zahlung wurde angeordnet und freigegeben (BEREIT), Budget auf 170.00 gemindert — budget_rest_erwartet 170.00 korrekt. Erwartete Abwehr: Storno-Knopf für Sachbearbeiterrolle ausgeblendet; STATE_SNAPSHOT Vorher=Nachher-Prüfsumme 4af43d91ca604517 identisch ⇒ DB unverändert. Ablauf konsistent: Freigabe durch sb-web-03 ≠ Erfasser sb-web-01.

Befunde: []

## POSITIV:run-20261015-100353-13234168534251085179:TF05
PASS

Eigenständige Nachrechnung: RBS 2 = 506.00; alle Mehrbedarfe 0; KdU = 540.00 + 75.00 + 85.00 = 700.00 (kein WW-Abzug, Grenze 0); Gesamtbedarf 1206.00; Einkommen 0 ⇒ anrechenbar 0.00; Vermögen 0 ⇒ verwertbar 0.00; Personen-/BG-Zahlbetrag 1206.00; hypothetisch 1426.00 − 1206.00 = 220.00 = budget_rest_erwartet (Zahlung BEREIT, Budget gemindert). Alle SQL-Erwartungen decken sich mit Ablauf; Freigabe durch sb-web-03 ≠ Erfasser sb-web-02.

Befunde: []

## NEGATIV:run-20261015-100608-12296938910290168033:TF05
PASS

Eigene Nachrechnung: RBS Stufe 2 = 506.00; keine Mehrbedarfe (G/Schwangerschaft/Alleinerziehend/dezentral Warmwasser alle nicht vorliegend); KdU = 300+45+65 = 410.00, Warmwasserabzug aus (Anteil 0), BG-Grenze 0 (deaktiviert); Gesamtbedarf 916.00; Einkommen 0, anrechenbar 0; Vermögen 0 < Schonvermögen 10000, verwertbar 0; Personen-Zahlbetrag = BG-Zahlbetrag = 916.00. budget_rest_hypothetisch = 1166.00 - 916.00 = 250.00. Erwartete Abwehr der zweiten Anordnung für denselben Monat 2026-10 ist fachlich zwingend (VALIDATION Doppelanordnung); DB-Endzustand unverändert, Budget nur einmal gemindert (250.00).

Befunde: []

## POSITIV:run-20261015-100353-13234168534251085179:TF06
PASS

Eigene Nachrechnung: RBS Stufe 3 = 451.00; alle Mehrbedarfe 0; KdU = 520+35+70 = 625.00; Gesamtbedarf 1076.00; Einkommen 0; Vermögen 0 < 10000, verwertbar 0; Personen-/BG-Zahlbetrag 1076.00. budget_rest_hypothetisch = 1376.00 - 1076.00 = 300.00; budget_rest_erwartet = 1376.00, da die Zahlung nach Übergang in BEREIT durch Admin-Storno vollständig zurückgebucht wurde — konsistent mit §-Regel 'STORNIERT bucht Budget zurück'. Auszahlungsbetrag 1076.00, Vier-Augen-Freigabe durch sb-web-01 (≠ Erfasser sb-web-03) korrekt.

Befunde: []

## NEGATIV:run-20261015-100608-12296938910290168033:TF06
PASS

Reiner Workflow-/Sperrlogikfall ohne personenbezogenen Rechenblock; die KEIN_ANSPRUCH-Abwehr ist aus den dokumentierten Eingaben zwingend herleitbar: RBS 1 = 563.00, KdU 420.00, Gesamtbedarf 983.00; Rente 5000.00 erhält keinen Erwerbsfreibetrag, anrechenbar 5000.00, Vermögen 0; Zahlbetrag = 983.00 - 5000.00 = -4017.00 ≤ 0 ⇒ KEIN_ANSPRUCH (§ 43 Abs. 1). Fehlerdialog meldet exakt -4.017,00 EUR. Budget (1200 EUR) und DB-Endzustand bleiben unberührt (STATE_SNAPSHOT Prüfsummen identisch); keine Zahlung entstanden. Keine personenbezogene Nachrechnung behauptet.

Befunde: []

## POSITIV:run-20261015-100353-13234168534251085179:TF07
PASS

Eigenrechnung: Regelbedarf Stufe 1 = 563.00; alle Mehrbedarfe 0 (keine Merkmale). KdU = 480 + 40 + 85 = 605.00, kein Warmwasserabzug (anteil=0, dezentral false). Gesamtbedarf = 563 + 605 = 1168.00. Kein Einkommen, anrechenbar = 0.00, Vermögen 0 → verwertbar 0. Personen-zahlbetrag 1168.00, bg_zahlbetrag 1168.00. Hypothetisch: 1448.00 - 1168.00 = 280.00, identisch mit budget_rest_erwartet (Zahlung freigegeben, BEREIT). Sätze im Laufkopf stimmen mit den Rechtsgrundlagen 2026 überein.

Befunde: []

## NEGATIV:run-20261015-100608-12296938910290168033:TF07
PASS

Eigenrechnung: Regelbedarf 563.00, keine Mehrbedarfe. KdU = 300 + 80 + 80 = 460.00. Gesamtbedarf = 1023.00, anrechenbar 0.00, Vermögen 0 → bg_zahlbetrag 1023.00. Startbudget 993.00 < 1023.00 → BUDGET_ERSCHOEPFT zwingend; Abwehr mit exakt diesen Beträgen im Fehlerdialog (1.023,00 > 993,00) dokumentiert. Hypothetisch 993.00 - 1023.00 = -30.00; erwarteter Endbestand 993.00 (Budget unberührt) — konsistent mit Snapshot-Gleichheit und V2/V3.

Befunde: []

## POSITIV:run-20261015-100353-13234168534251085179:TF08
PASS

Eigenrechnung: Stufe 2 = 506.00, keine Mehrbedarfe. KdU = 490 + 110 + 70 = 670.00. Gesamtbedarf 1176.00, anrechenbar 0.00, Vermögen 0 → bg_zahlbetrag 1176.00. Hypothetisch 1276.00 - 1176.00 = 100.00; nach Storno [S8] vollständige Rückbuchung → budget_rest_erwartet 1276.00, mit V5 (ist=1276) konsistent. Storno durch Admin web-admin, Status STORNIERT, Monatsfreigabe dokumentiert.

Befunde: []

## NEGATIV:run-20261015-100608-12296938910290168033:TF08
PASS

Reiner Ablauf-/Sperrlogik-Fall ohne Rechenblock (Login mit falschem Passwort). Die Abwehr folgt zwingend aus dem Ablauf: Eine fehlgeschlagene Anmeldung darf keinen Fachdatensatz erzeugen. V1 dokumentiert identische Vorher-/Nachher-Prüfsumme (5b91b99e37daf82f) über alle Fachtabellen, V2 bestätigt 0 Bedarfsgemeinschaften mit Aktenzeichen SWEET-NW-0008, V3 globale Laufverifikation ohne Fehler. Protokoll S1 zeigt abgewehrte Anmeldung mit korrekter Meldung. Keine Betragsberechnung erforderlich; keine Abweichung.

Befunde: []

## POSITIV:run-20261015-100353-13234168534251085179:TF09
PASS

Eigenständige Nachrechnung: RBS Stufe 2 = 506.00; keine Mehrbedarfe (merkzeichen_g=false, schwanger=false, keine Kinder, warmwasser=false, zentraler WW-Abzug deaktiviert mit Anteil 0, BG-Grenze 0 = deaktiviert). KdU = 270.00 + 80.00 + 110.00 = 460.00. Gesamtbedarf = 506.00 + 460.00 = 966.00. Einkommen (Rente 0, Erwerb 0) ⇒ Freibetrag 0, Absetzungen 0, anrechenbar 0, Personen- und BG-Zahlbetrag 966.00. Vermögen 0 < Schonvermögen 10.000 ⇒ verwertbares Vermögen 0, kein Abzug. budget_rest_hypothetisch = 1196.00 − 966.00 = 230.00, deckungsgleich mit budget_rest_erwartet (tatsächliche Zahlung erfolgt). Alle V-Prüfungen (V1–V8) mit ist=erwartet konsistent: genau eine Zahlung, Erfasser sb-web-03 / Freigabe sb-web-01 (Vier-Augen erfüllt), Status BEREIT, Betrag 966, Restbudget 230, Stufe 2 persistiert, unabhängige BigDecimal-Nachrechnung 0 Abweichungen, globale Verifikation 0 Fehler. Protokoll S1–S7 vollständig und fachlich korrekt (Anordnung ANGELEGT, Kollegenwechsel, Freigabe BEREIT).

Befunde: []

## NEGATIV:run-20261015-100608-12296938910290168033:TF09
PASS

Reiner Workflow-Fall ohne personenbezogenen Rechenblock; Angefordert sind keine calculations. Prüfung des Ablaufs: Auszahlung ohne Zahlungsmonat muss abgewehrt werden (Pflichtfeld/Zuordnung zum Bescheidzeitraum), DB-Endzustand unverändert. V1: identische Vorher-/Nachher-Prüfsumme (3e57db9974e6b5fa) belegt unveränderte Fachtabellen. V2: Vorgang SWEET-NW-0009 existiert (1=1, erwartet, da S2 ihn anlegt). V3: keine Zahlung entstanden (0=0). V4: globale Verifikation 0 Fehler. Protokoll S1–S4 zeigt Anmeldung, Vorgangsanlage (Startbudget 1200), SozialFall-Erfassung und abgewehrte Anordnung mit Fehlerdialog; Abwehr folgt zwingend aus dem fehlenden Zahlungsmonat. Keine Abweichung.

Befunde: []

## Unabhängige arithmetische Referenz 2026

[{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"POSITIV:run-20261015-100353-13234168534251085179:TF01","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"NEGATIV:run-20261015-100608-12296938910290168033:TF01","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"POSITIV:run-20261015-100353-13234168534251085179:TF02","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"NEGATIV:run-20261015-100608-12296938910290168033:TF02","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"POSITIV:run-20261015-100353-13234168534251085179:TF03","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"NEGATIV:run-20261015-100608-12296938910290168033:TF03","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"POSITIV:run-20261015-100353-13234168534251085179:TF04","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"NEGATIV:run-20261015-100608-12296938910290168033:TF04","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"POSITIV:run-20261015-100353-13234168534251085179:TF05","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"NEGATIV:run-20261015-100608-12296938910290168033:TF05","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"POSITIV:run-20261015-100353-13234168534251085179:TF06","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"NEGATIV:run-20261015-100608-12296938910290168033:TF06","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"POSITIV:run-20261015-100353-13234168534251085179:TF07","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"NEGATIV:run-20261015-100608-12296938910290168033:TF07","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"POSITIV:run-20261015-100353-13234168534251085179:TF08","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"NEGATIV:run-20261015-100608-12296938910290168033:TF08","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"POSITIV:run-20261015-100353-13234168534251085179:TF09","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]},{"state":"PASS","findings":[],"workflowUnverified":[],"caseId":"NEGATIV:run-20261015-100608-12296938910290168033:TF09","missingInputs":[],"arithmeticIssues":[],"workflowFindings":[]}]
