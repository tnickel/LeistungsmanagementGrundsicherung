# Prüfmenge: vollständige ausgewählte Fälle

Auswahl: 18 Fälle; keine Kürzung innerhalb eines Falls.

# Vollständiger Laufkopf POSITIV / run-20261015-100353-13234168534251085179
Quelle: testsweet/logs/run-20261015-100353-13234168534251085179/testdokumentation.md

# testsweet Lauf

gesamtergebnis = UNVERIFIED
lauf_erfolgreich = false
automatik_bestanden = true
ki_fachstatus = UNVERIFIED
gesamtfehler = KI-Prüfung ist ausstehend.
globale_pruefung = Pruefung[beschreibung=Global: Anzahl SWEET-Vorgänge, erwartet=60, ist=60, ok=true, hinweis=null, sql=null, parameter=[]]
globale_pruefung = Pruefung[beschreibung=Global: keine Übergabe ohne Freigabevermerk, erwartet=0, ist=0, ok=true, hinweis=null, sql=null, parameter=[]]
produkt = SDN.Leistung LMG
modus = 2-web (Weboberfläche/Selenium)
kategorie = POSITIV
start = 2026-10-15T10:03:53.520434700
ende = 2026-10-15T10:06:06.598713500
dauer_s = 133
db = jdbc:oracle:thin:@//localhost:1521/FREEPDB1
db_user = REVIEW_20261015
mitarbeiter = 3
auftraege = 60
seed = 20261015
denkzeit_ms = 0
ergebnis.verifiziert = 60
ergebnis.verifikation_nio = 0
ergebnis.fehlgeschlagen = 0
ergebnis.gesamt = 60
hinweis: Soll-Beträge werden mit der Produktionsberechnung (Leistungsberechnung) ermittelt und jeder erzeugte Rechenblock vor dem Laufurteil unabhängig nachgerechnet (dokumentierter Rechenstand 2026). Zusätzliche Goldwerte-Absicherung: GoldWerteTest im Hauptprojekt (Werte aus doc/regressionstests.md).

## pruefanleitung_fur_ki

Diese Datei ist das maschinenlesbare Protokoll eines testsweet-Laufs der Fachanwendung SDN.Leistung (Grundsicherung im Alter/bei Erwerbsminderung, SGB XII). Bitte unabhängig überprüfen:

1. BETRÄGE NACHRECHNEN (Positivfälle): Je Testfall stehen unter '### rechenwege' die Eingaben je Person (p1_eingaben, p2_eingaben, ...) und JEDE Zwischengröße (regelbedarf, mehrbedarfe, kdu, anrechenbar, bg_zahlbetrag, budget_rest_hypothetisch). Das hypothetische Restbudget beschreibt nur Startbudget minus Anspruch, keine tatsächliche Buchung. Ein explizites budget_rest_erwartet bzw. die SQL-Erwartung beschreibt den Buchungsendzustand; bei Abweisung bleibt das Budget unverändert, Storno gibt den Betrag zurück. Rechne mit den Formeln aus '## rechengrundlagen_2026' jeden Zwischenwert und den Zahlbetrag selbst nach und melde jede Abweichung.
2. ERWARTET/GEGEN IST HALTEN: Unter '### verifikation' steht je Prüfung V1..Vn das prüfende SQL mit konkreten Parametern sowie 'erwartet' und 'ist'. Prüfe, ob die erwarteten Werte fachlich aus den Eingaben folgen und ob ist = erwartet ist (NIO-Zeilen sind Fehler).
3. NEGATIVFÄLLE PLAUSIBILISIEREN: Schritte mit 'ERWARTETER FEHLER (CODE)' müssen fachlich zwingend abgewehrt werden (z. B. KEIN_ANSPRUCH wenn Einkommen/Vermögen den Bedarf übersteigt, VALIDATION bei Doppelanordnung je Monat oder Zahlungsmonat außerhalb des Bewilligungszeitraums, BERECHTIGUNG bei Selbstfreigabe, KONKURRENZ bei veraltetem Maskenstand, BUDGET_ERSCHOEPFT bei zu kleinem Startbudget). Prüfe, dass der Datenbank-Endzustand unverändert geblieben ist (keine Zahlung, Budget unangetastet).
4. GRENZEN: Last-/Stresstests erzeugen nur Aggregate (kein Einzelfall-Nachrechnen); Web-Läufe (modus 2-web) nutzen dieselbe Datenstruktur, dokumentieren aber UI-Schritte. Globale Prüfungen stehen im Kopf als globale_pruefung-Zeilen.
Das verbindliche Antwortschema steht im übergeordneten Prüfauftrag. Dieser Datenanhang legt kein abweichendes Antwortformat fest.

## rechengrundlagen_2026

rbs_eur = {1: 563.00, 2: 506.00, 3: 451.00, 4: 471.00, 5: 390.00, 6: 357.00}  (Anlage zu § 28 SGB XII)
mehrbedarf_g = 0.17 * regelbedarf  (§ 30 Abs. 1)
mehrbedarf_schwanger = 0.17 * regelbedarf  (§ 30 Abs. 2, ab 13. SSW; entfaellt automatisch, wenn entbindungsmonat gesetzt und zahlungsmonat > entbindungsmonat)
mehrbedarf_alleinerziehend = 0.36 * rbs1 bei kind_u7>=1 oder 2<=kinder_u16<=3, sonst 0.12 * rbs1 je minderjaehrigem kind; deckel 0.60 * rbs1 = 337.80  (§ 30 Abs. 3)
mehrbedarf_obergrenze = summe(abs1..5) <= regelbedarf  (§ 30 Abs. 6)
mehrbedarf_warmwasser_anteil = {1: 0.023, 2: 0.023, 3: 0.0, 4: 0.014, 5: 0.012, 6: 0.008}  (§ 30 Abs. 7, zusaetzlich zu Abs. 6)
kdu = kaltmiete + betriebskosten + heizung - zentraler warmwasserabzug; gekappt auf verbleibende BG-Grenze, sofern > 0. Parameter stehen je Block.
erwerbsfreibetrag = min(0.30 * erwerb_brutto, 0.50 * rbs1 = 281.50)  (§ 82 Abs. 3)
anrechenbar = rente + erwerb - freibetrag - absetzbetaetrag >= 0  (absetzbetraege: steuern, sv, versicherungen, erwerbsaufwendungen; § 82 Abs. 2)
schonvermoegen = 10000.00 je volljaehriger person (rbs 1-3) + 500.00 je weiterer person; Produktvertrag ohne Erwachsene: Grundbetrag einmal 10000.00. Referenz des implementierten Vertrags, keine eigenständige Rechtsverifikation.
zahlbetrag = gesamtbedarf - anrechenbares_einkommen - max(vermoegen - schonvermoegen, 0)  (<= 0 => KEIN_ANSPRUCH, § 43 Abs. 1)
rundung = HALF_UP auf 2 nachkommastellen; waehrung EUR
zahlstatus = ANGELEGT (wartet auf freigabe) -> BEREIT -> UEBERGEBEN; STORNIERT gibt monat frei
sepa_iban = ISO 13616: laenderspezifische Gesamtlaenge (Deutschland genau 22 Zeichen); Pruefziffer-Validierung: die verschobene Ziffernfolge (BBAN, dann Laendercode-Verdraengung 1314, dann Pruefziffer) ergibt Modulo 97 genau 1. Abweichung von Laenge oder Pruefziffer => VALIDATION 'Ungueltige IBAN'.
sepa_bic = ISO 9362: genau 8 oder 11 Zeichen (4 Buchstaben Bankcode, 2 Buchstaben Laendercode, 2 alphanumerische Ortskennung, optional 3 alphanumerische Zweigstelle). Andere Laenge/Struktur => VALIDATION 'Ungueltiger BIC'.


# Vollständiger Laufkopf NEGATIV / run-20261015-100608-12296938910290168033
Quelle: testsweet/logs/run-20261015-100608-12296938910290168033/testdokumentation.md

# testsweet Lauf

gesamtergebnis = UNVERIFIED
lauf_erfolgreich = false
automatik_bestanden = true
ki_fachstatus = UNVERIFIED
gesamtfehler = KI-Prüfung ist ausstehend.
globale_pruefung = Pruefung[beschreibung=Global: Anzahl SWEET-Vorgänge, erwartet=49, ist=49, ok=true, hinweis=null, sql=null, parameter=[]]
globale_pruefung = Pruefung[beschreibung=Global: keine Übergabe ohne Freigabevermerk, erwartet=0, ist=0, ok=true, hinweis=null, sql=null, parameter=[]]
produkt = SDN.Leistung LMG
modus = 2-web (Weboberfläche/Selenium)
kategorie = NEGATIV
start = 2026-10-15T10:06:08.343774200
ende = 2026-10-15T10:07:39.794754300
dauer_s = 91
db = jdbc:oracle:thin:@//localhost:1521/FREEPDB1
db_user = REVIEW_20261015
mitarbeiter = 3
auftraege = 60
seed = 20261015
denkzeit_ms = 0
ergebnis.verifiziert = 60
ergebnis.verifikation_nio = 0
ergebnis.fehlgeschlagen = 0
ergebnis.gesamt = 60
hinweis: Soll-Beträge werden mit der Produktionsberechnung (Leistungsberechnung) ermittelt und jeder erzeugte Rechenblock vor dem Laufurteil unabhängig nachgerechnet (dokumentierter Rechenstand 2026). Zusätzliche Goldwerte-Absicherung: GoldWerteTest im Hauptprojekt (Werte aus doc/regressionstests.md).

## pruefanleitung_fur_ki

Diese Datei ist das maschinenlesbare Protokoll eines testsweet-Laufs der Fachanwendung SDN.Leistung (Grundsicherung im Alter/bei Erwerbsminderung, SGB XII). Bitte unabhängig überprüfen:

1. BETRÄGE NACHRECHNEN (Positivfälle): Je Testfall stehen unter '### rechenwege' die Eingaben je Person (p1_eingaben, p2_eingaben, ...) und JEDE Zwischengröße (regelbedarf, mehrbedarfe, kdu, anrechenbar, bg_zahlbetrag, budget_rest_hypothetisch). Das hypothetische Restbudget beschreibt nur Startbudget minus Anspruch, keine tatsächliche Buchung. Ein explizites budget_rest_erwartet bzw. die SQL-Erwartung beschreibt den Buchungsendzustand; bei Abweisung bleibt das Budget unverändert, Storno gibt den Betrag zurück. Rechne mit den Formeln aus '## rechengrundlagen_2026' jeden Zwischenwert und den Zahlbetrag selbst nach und melde jede Abweichung.
2. ERWARTET/GEGEN IST HALTEN: Unter '### verifikation' steht je Prüfung V1..Vn das prüfende SQL mit konkreten Parametern sowie 'erwartet' und 'ist'. Prüfe, ob die erwarteten Werte fachlich aus den Eingaben folgen und ob ist = erwartet ist (NIO-Zeilen sind Fehler).
3. NEGATIVFÄLLE PLAUSIBILISIEREN: Schritte mit 'ERWARTETER FEHLER (CODE)' müssen fachlich zwingend abgewehrt werden (z. B. KEIN_ANSPRUCH wenn Einkommen/Vermögen den Bedarf übersteigt, VALIDATION bei Doppelanordnung je Monat oder Zahlungsmonat außerhalb des Bewilligungszeitraums, BERECHTIGUNG bei Selbstfreigabe, KONKURRENZ bei veraltetem Maskenstand, BUDGET_ERSCHOEPFT bei zu kleinem Startbudget). Prüfe, dass der Datenbank-Endzustand unverändert geblieben ist (keine Zahlung, Budget unangetastet).
4. GRENZEN: Last-/Stresstests erzeugen nur Aggregate (kein Einzelfall-Nachrechnen); Web-Läufe (modus 2-web) nutzen dieselbe Datenstruktur, dokumentieren aber UI-Schritte. Globale Prüfungen stehen im Kopf als globale_pruefung-Zeilen.
Das verbindliche Antwortschema steht im übergeordneten Prüfauftrag. Dieser Datenanhang legt kein abweichendes Antwortformat fest.

## rechengrundlagen_2026

rbs_eur = {1: 563.00, 2: 506.00, 3: 451.00, 4: 471.00, 5: 390.00, 6: 357.00}  (Anlage zu § 28 SGB XII)
mehrbedarf_g = 0.17 * regelbedarf  (§ 30 Abs. 1)
mehrbedarf_schwanger = 0.17 * regelbedarf  (§ 30 Abs. 2, ab 13. SSW; entfaellt automatisch, wenn entbindungsmonat gesetzt und zahlungsmonat > entbindungsmonat)
mehrbedarf_alleinerziehend = 0.36 * rbs1 bei kind_u7>=1 oder 2<=kinder_u16<=3, sonst 0.12 * rbs1 je minderjaehrigem kind; deckel 0.60 * rbs1 = 337.80  (§ 30 Abs. 3)
mehrbedarf_obergrenze = summe(abs1..5) <= regelbedarf  (§ 30 Abs. 6)
mehrbedarf_warmwasser_anteil = {1: 0.023, 2: 0.023, 3: 0.0, 4: 0.014, 5: 0.012, 6: 0.008}  (§ 30 Abs. 7, zusaetzlich zu Abs. 6)
kdu = kaltmiete + betriebskosten + heizung - zentraler warmwasserabzug; gekappt auf verbleibende BG-Grenze, sofern > 0. Parameter stehen je Block.
erwerbsfreibetrag = min(0.30 * erwerb_brutto, 0.50 * rbs1 = 281.50)  (§ 82 Abs. 3)
anrechenbar = rente + erwerb - freibetrag - absetzbetaetrag >= 0  (absetzbetraege: steuern, sv, versicherungen, erwerbsaufwendungen; § 82 Abs. 2)
schonvermoegen = 10000.00 je volljaehriger person (rbs 1-3) + 500.00 je weiterer person; Produktvertrag ohne Erwachsene: Grundbetrag einmal 10000.00. Referenz des implementierten Vertrags, keine eigenständige Rechtsverifikation.
zahlbetrag = gesamtbedarf - anrechenbares_einkommen - max(vermoegen - schonvermoegen, 0)  (<= 0 => KEIN_ANSPRUCH, § 43 Abs. 1)
rundung = HALF_UP auf 2 nachkommastellen; waehrung EUR
zahlstatus = ANGELEGT (wartet auf freigabe) -> BEREIT -> UEBERGEBEN; STORNIERT gibt monat frei
sepa_iban = ISO 13616: laenderspezifische Gesamtlaenge (Deutschland genau 22 Zeichen); Pruefziffer-Validierung: die verschobene Ziffernfolge (BBAN, dann Laendercode-Verdraengung 1314, dann Pruefziffer) ergibt Modulo 97 genau 1. Abweichung von Laenge oder Pruefziffer => VALIDATION 'Ungueltige IBAN'.
sepa_bic = ISO 9362: genau 8 oder 11 Zeichen (4 Buchstaben Bankcode, 2 Buchstaben Laendercode, 2 alphanumerische Ortskennung, optional 3 alphanumerische Zweigstelle). Andere Laenge/Struktur => VALIDATION 'Ungueltiger BIC'.


# Fall-ID: POSITIV:run-20261015-100353-13234168534251085179:TF01
geforderte_pruefpunkte = V1, V2, V3, V4, V5, V6, V7, V8, S1, S2, S3, S4, S5, S6, S7

## TF 01 WEB-STANDARDRENTE SWEET-W-0001
status = VERIFIZIERT
hauptperson = Web, Willi 1
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 5417
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1448.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=550.00, kdu_betrieb=75.00, kdu_heizung=100.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=725.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1288.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1288.00
bg_gesamtbedarf=1288.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1288.00
budget_rest_hypothetisch=160.00
budget_rest_erwartet=160.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0001]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0001, sb-web-01, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0001]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0001]
    erwartet = 1288.00 | ist = 1288
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0001]
    erwartet = 160.00 | ist = 160
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0001]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:07.875 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-01-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:04:08.866 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0001)  [Bild: tf-01-schritt-02.png] -> OK — Vorgang SWEET-W-0001 (Web, Willi 1) mit Startbudget 1448.00 EUR angelegt
2026-10-15 10:04:09.927 sb-web-01 | [S3] SozialFall erfassen (RBS 1, KdU 725.00 EUR)  [Bild: tf-01-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 725.00 EUR) gespeichert
2026-10-15 10:04:10.660 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-01-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:10.976 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-01-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:04:11.665 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-01-schritt-06.png] -> OK — Vorgang SWEET-W-0001 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:12.364 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-01-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)


# Fall-ID: NEGATIV:run-20261015-100608-12296938910290168033:TF01
geforderte_pruefpunkte = V1, V2, V3, V4, S1, S2, S3

## TF 01 WEB-NEG-BANKVERBINDUNG SWEET-NW-0001
status = VERIFIZIERT
hauptperson = —
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 3586
ids = adminKonto=web-admin, kollege=sb-web-02, sitzungKennung=sb-web-01, mitarbeiter=sb-web-01

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Vorgang mit IBAN mit falscher Prüfziffer anlegen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | UI-Fehlversuch ohne Fachänderung: Vorgang mit zu kurzem BIC (7 Zeichen) anlegen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V3: OK | kein Vorgang mit dem Aktenzeichen angelegt
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0001]
    erwartet = 0 | ist = 0
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:23.562 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-01-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:06:24.755 sb-web-01 | [S2] Vorgang mit IBAN mit falscher Prüfziffer anlegen  [Bild: tf-01-schritt-02.png] -> OK — Neuanlage abgewehrt — Fehlerdialog: Ungültige IBAN
2026-10-15 10:06:26.078 sb-web-01 | [S3] Vorgang mit zu kurzem BIC (7 Zeichen) anlegen  [Bild: tf-01-schritt-03.png] -> OK — Neuanlage abgewehrt — Fehlerdialog: Ungültiger BIC


# Fall-ID: POSITIV:run-20261015-100353-13234168534251085179:TF02
geforderte_pruefpunkte = V1, V2, V3, V4, V5, V6, V7, V8, S1, S2, S3, S4, S5, S6, S7

## TF 02 WEB-STANDARDRENTE SWEET-W-0002
status = VERIFIZIERT
hauptperson = Web, Willi 2
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 5430
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1146.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=290.00, kdu_betrieb=100.00, kdu_heizung=130.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=520.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1026.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1026.00
bg_gesamtbedarf=1026.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1026.00
budget_rest_hypothetisch=120.00
budget_rest_erwartet=120.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0002]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0002, sb-web-02, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0002]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0002]
    erwartet = 1026.00 | ist = 1026
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0002]
    erwartet = 120.00 | ist = 120
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0002]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:08.100 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-02-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:04:09.092 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0002)  [Bild: tf-02-schritt-02.png] -> OK — Vorgang SWEET-W-0002 (Web, Willi 2) mit Startbudget 1146.00 EUR angelegt
2026-10-15 10:04:10.154 sb-web-02 | [S3] SozialFall erfassen (RBS 2, KdU 520.00 EUR)  [Bild: tf-02-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 520.00 EUR) gespeichert
2026-10-15 10:04:10.894 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-02-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:11.437 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-02-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:04:12.205 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-02-schritt-06.png] -> OK — Vorgang SWEET-W-0002 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:12.906 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-02-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)


# Fall-ID: NEGATIV:run-20261015-100608-12296938910290168033:TF02
geforderte_pruefpunkte = V1, V2, V3, V4, V5, S1, S2, S3, S4

## TF 02 WEB-NEG-BUDGET SWEET-NW-0002
status = VERIFIZIERT
hauptperson = Web, Negativ 2
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5479
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

block: Bedarf (Budget bewusst zu klein)
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 941.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=370.00, kdu_betrieb=95.00, kdu_heizung=105.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=570.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1021.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1021.00
bg_gesamtbedarf=1021.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1021.00
budget_rest_hypothetisch=-80.00
budget_rest_erwartet=941.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 9ef5203910387f3d, Nachher-Prüfsumme 9ef5203910387f3d (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0002]
    erwartet = 0 | ist = 0
V3: OK | Budget unverändert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0002]
    erwartet = 941.00 | ist = 941
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:23.593 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-02-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:06:24.762 sb-web-03 | [S2] Neuen Vorgang mit Startbudget 941.00 EUR anlegen (bewusst zu klein)  [Bild: tf-02-schritt-02.png] -> OK — Vorgang SWEET-NW-0002 (Web, Negativ 2) mit Startbudget 941.00 EUR angelegt
2026-10-15 10:06:25.984 sb-web-03 | [S3] SozialFall erfassen (Bedarf 1021.00 EUR)  [Bild: tf-02-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 570.00 EUR) gespeichert
2026-10-15 10:06:28.243 sb-web-03 | [S4] Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet  [Bild: tf-02-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Der Zahlbetrag 1.021,00 EUR übersteigt das verfügbare Restbudget von 941,00 EUR


# Fall-ID: POSITIV:run-20261015-100353-13234168534251085179:TF03
geforderte_pruefpunkte = V1, V2, V3, V4, V5, V6, V7, V8, S1, S2, S3, S4, S5, S6, S7

## TF 03 WEB-STANDARDRENTE SWEET-W-0003
status = VERIFIZIERT
hauptperson = Web, Willi 3
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5044
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1186.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=390.00, kdu_betrieb=55.00, kdu_heizung=90.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=535.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=986.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=986.00
bg_gesamtbedarf=986.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=986.00
budget_rest_hypothetisch=200.00
budget_rest_erwartet=200.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0003]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0003, sb-web-03, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0003]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0003]
    erwartet = 986.00 | ist = 986
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0003]
    erwartet = 200.00 | ist = 200
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0003]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:08.414 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-03-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:04:09.376 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0003)  [Bild: tf-03-schritt-02.png] -> OK — Vorgang SWEET-W-0003 (Web, Willi 3) mit Startbudget 1186.00 EUR angelegt
2026-10-15 10:04:10.344 sb-web-03 | [S3] SozialFall erfassen (RBS 3, KdU 535.00 EUR)  [Bild: tf-03-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 535.00 EUR) gespeichert
2026-10-15 10:04:11.272 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-03-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:11.641 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-03-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:04:12.365 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-03-schritt-06.png] -> OK — Vorgang SWEET-W-0003 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:13.073 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-03-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)


# Fall-ID: NEGATIV:run-20261015-100608-12296938910290168033:TF03
geforderte_pruefpunkte = V1, V2, V3, V4, V5, S1, S2, S3, S4

## TF 03 WEB-NEG-BUDGET SWEET-NW-0003
status = VERIFIZIERT
hauptperson = Web, Negativ 3
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 5357
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

block: Bedarf (Budget bewusst zu klein)
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 976.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=460.00, kdu_betrieb=40.00, kdu_heizung=65.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=565.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1016.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1016.00
bg_gesamtbedarf=1016.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1016.00
budget_rest_hypothetisch=-40.00
budget_rest_erwartet=976.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 84d32dd7fe0d3bef, Nachher-Prüfsumme 84d32dd7fe0d3bef (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0003]
    erwartet = 0 | ist = 0
V3: OK | Budget unverändert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0003]
    erwartet = 976.00 | ist = 976
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:23.678 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-03-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:06:24.762 sb-web-02 | [S2] Neuen Vorgang mit Startbudget 976.00 EUR anlegen (bewusst zu klein)  [Bild: tf-03-schritt-02.png] -> OK — Vorgang SWEET-NW-0003 (Web, Negativ 3) mit Startbudget 976.00 EUR angelegt
2026-10-15 10:06:25.984 sb-web-02 | [S3] SozialFall erfassen (Bedarf 1016.00 EUR)  [Bild: tf-03-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 565.00 EUR) gespeichert
2026-10-15 10:06:28.242 sb-web-02 | [S4] Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet  [Bild: tf-03-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Der Zahlbetrag 1.016,00 EUR übersteigt das verfügbare Restbudget von 976,00 EUR


# Fall-ID: POSITIV:run-20261015-100353-13234168534251085179:TF04
geforderte_pruefpunkte = V1, V2, V3, V4, V5, V6, V7, V8, S1, S2, S3, S4, S5, S6, S7, S8

## TF 04 WEB-STORNO SWEET-W-0004
status = VERIFIZIERT
hauptperson = Web, Willi 4
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 6949
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1311.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=440.00, kdu_betrieb=115.00, kdu_heizung=100.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=655.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1161.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1161.00
bg_gesamtbedarf=1161.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1161.00
budget_rest_hypothetisch=150.00
budget_rest_erwartet=1311.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0004]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0004, sb-web-01, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0004]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0004]
    erwartet = 1161.00 | ist = 1161
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0004]
    erwartet = 1311.00 | ist = 1311
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0004]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:13.195 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-04-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:04:14.343 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0004)  [Bild: tf-04-schritt-02.png] -> OK — Vorgang SWEET-W-0004 (Web, Willi 4) mit Startbudget 1311.00 EUR angelegt
2026-10-15 10:04:15.343 sb-web-01 | [S3] SozialFall erfassen (RBS 2, KdU 655.00 EUR)  [Bild: tf-04-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 655.00 EUR) gespeichert
2026-10-15 10:04:16.044 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-04-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:16.327 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-04-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:04:17.049 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-04-schritt-06.png] -> OK — Vorgang SWEET-W-0004 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:17.717 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-04-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:04:19.314 sb-web-01 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-04-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)


# Fall-ID: NEGATIV:run-20261015-100608-12296938910290168033:TF04
geforderte_pruefpunkte = V1, V2, V3, V4, V5, V6, S1, S2, S3, S4, S5, S6, S7, S8

## TF 04 WEB-NEG-STORNO-SB SWEET-NW-0004
status = VERIFIZIERT
hauptperson = Web, Negativ 4
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 6062
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

block: Anordnung + Freigabe
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1146.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=350.00, kdu_betrieb=35.00, kdu_heizung=85.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=470.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=976.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=976.00
bg_gesamtbedarf=976.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=976.00
budget_rest_hypothetisch=170.00
budget_rest_erwartet=170.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 4af43d91ca604517, Nachher-Prüfsumme 4af43d91ca604517 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0004]
    erwartet = 1 | ist = 1
V3: OK | Zahlung bleibt freigegeben (kein Storno durch SB)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-NW-0004]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Budget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0004]
    erwartet = 170.00 | ist = 170
V5: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V6: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:27.124 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-04-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:06:28.233 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0004)  [Bild: tf-04-schritt-02.png] -> OK — Vorgang SWEET-NW-0004 (Web, Negativ 4) mit Startbudget 1146.00 EUR angelegt
2026-10-15 10:06:29.234 sb-web-01 | [S3] SozialFall erfassen  [Bild: tf-04-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 470.00 EUR) gespeichert
2026-10-15 10:06:29.960 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-04-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:06:30.708 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-04-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:06:31.371 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-04-schritt-06.png] -> OK — Vorgang SWEET-NW-0004 über Suchfeld ermittelt und geöffnet
2026-10-15 10:06:32.058 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-04-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:06:32.142 sb-web-01 | [S8] Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten  [Bild: tf-04-schritt-08.png] -> OK — Storno-Knopf für Sachbearbeiter korrekt ausgeblendet (nur Admin-Rolle)


# Fall-ID: POSITIV:run-20261015-100353-13234168534251085179:TF05
geforderte_pruefpunkte = V1, V2, V3, V4, V5, V6, V7, V8, S1, S2, S3, S4, S5, S6, S7

## TF 05 WEB-STANDARDRENTE SWEET-W-0005
status = VERIFIZIERT
hauptperson = Web, Willi 5
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4967
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1426.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=540.00, kdu_betrieb=75.00, kdu_heizung=85.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=700.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1206.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1206.00
bg_gesamtbedarf=1206.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1206.00
budget_rest_hypothetisch=220.00
budget_rest_erwartet=220.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0005]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0005, sb-web-02, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0005]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0005]
    erwartet = 1206.00 | ist = 1206
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0005]
    erwartet = 220.00 | ist = 220
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0005]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:13.273 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-05-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:04:14.406 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0005)  [Bild: tf-05-schritt-02.png] -> OK — Vorgang SWEET-W-0005 (Web, Willi 5) mit Startbudget 1426.00 EUR angelegt
2026-10-15 10:04:15.440 sb-web-02 | [S3] SozialFall erfassen (RBS 2, KdU 700.00 EUR)  [Bild: tf-05-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 700.00 EUR) gespeichert
2026-10-15 10:04:16.161 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-05-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:16.483 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-05-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:04:17.204 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-05-schritt-06.png] -> OK — Vorgang SWEET-W-0005 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:17.874 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-05-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)


# Fall-ID: NEGATIV:run-20261015-100608-12296938910290168033:TF05
geforderte_pruefpunkte = V1, V2, V3, V4, V5, S1, S2, S3, S4, S5

## TF 05 WEB-NEG-DOPPELMONAT SWEET-NW-0005
status = VERIFIZIERT
hauptperson = Web, Negativ 5
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4035
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

block: Erste Anordnung
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1166.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=300.00, kdu_betrieb=45.00, kdu_heizung=65.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=410.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=916.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=916.00
bg_gesamtbedarf=916.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=916.00
budget_rest_hypothetisch=250.00
budget_rest_erwartet=250.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme c25e1d7a8b2d23f9, Nachher-Prüfsumme c25e1d7a8b2d23f9 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | genau eine Zahlung je Vorgang und Monat
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0005]
    erwartet = 1 | ist = 1
V3: OK | Budget nur einmal gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0005]
    erwartet = 250.00 | ist = 250
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:29.077 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-05-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:06:30.053 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0005)  [Bild: tf-05-schritt-02.png] -> OK — Vorgang SWEET-NW-0005 (Web, Negativ 5) mit Startbudget 1166.00 EUR angelegt
2026-10-15 10:06:30.956 sb-web-02 | [S3] SozialFall erfassen  [Bild: tf-05-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 410.00 EUR) gespeichert
2026-10-15 10:06:31.625 sb-web-02 | [S4] Erste Auszahlung für 2026-10 anordnen  [Bild: tf-05-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:06:32.270 sb-web-02 | [S5] ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet  [Bild: tf-05-schritt-05.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Für 2026-10 existiert bereits eine nicht stornierte Zahlung dieser Bedarfsgemeinschaft; ggf. zuerst stornieren


# Fall-ID: POSITIV:run-20261015-100353-13234168534251085179:TF06
geforderte_pruefpunkte = V1, V2, V3, V4, V5, V6, V7, V8, S1, S2, S3, S4, S5, S6, S7, S8

## TF 06 WEB-STORNO SWEET-W-0006
status = VERIFIZIERT
hauptperson = Web, Willi 6
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 6953
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1376.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=520.00, kdu_betrieb=35.00, kdu_heizung=70.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=625.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1076.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1076.00
bg_gesamtbedarf=1076.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1076.00
budget_rest_hypothetisch=300.00
budget_rest_erwartet=1376.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0006]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0006, sb-web-03, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0006]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0006]
    erwartet = 1076.00 | ist = 1076
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0006]
    erwartet = 1376.00 | ist = 1376
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0006]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:13.502 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-06-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:04:14.558 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0006)  [Bild: tf-06-schritt-02.png] -> OK — Vorgang SWEET-W-0006 (Web, Willi 6) mit Startbudget 1376.00 EUR angelegt
2026-10-15 10:04:15.575 sb-web-03 | [S3] SozialFall erfassen (RBS 3, KdU 625.00 EUR)  [Bild: tf-06-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 625.00 EUR) gespeichert
2026-10-15 10:04:16.285 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-06-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:17.064 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-06-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:04:17.718 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-06-schritt-06.png] -> OK — Vorgang SWEET-W-0006 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:18.403 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-06-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:04:20.027 sb-web-03 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-06-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)


# Fall-ID: NEGATIV:run-20261015-100608-12296938910290168033:TF06
geforderte_pruefpunkte = V1, V2, V3, V4, S1, S2, S3, S4

## TF 06 WEB-NEG-KEINANSPRUCH SWEET-NW-0006
status = VERIFIZIERT
hauptperson = Web, Negativ 6
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5312
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — KEIN_ANSPRUCH erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme de0d085dd72f6577, Nachher-Prüfsumme de0d085dd72f6577 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden (KEIN_ANSPRUCH abgewehrt)
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0006]
    erwartet = 0 | ist = 0
V3: OK | SozialFall mit Rente persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?) AND EINKOMMEN_RENTE = ?
    params = [SWEET-NW-0006, 5000.00]
    erwartet = 1 | ist = 1
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:29.059 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-06-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:06:30.427 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0006)  [Bild: tf-06-schritt-02.png] -> OK — Vorgang SWEET-NW-0006 (Web, Negativ 6) mit Startbudget 1200 EUR angelegt
2026-10-15 10:06:31.339 sb-web-03 | [S3] SozialFall mit hoher Rente erfassen  [Bild: tf-06-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 420 EUR, Rente 5000.00 EUR) gespeichert
2026-10-15 10:06:33.556 sb-web-03 | [S4] Auszahlung anordnen — KEIN_ANSPRUCH erwartet  [Bild: tf-06-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Einkommen/Vermögen übersteigen den Gesamtbedarf — kein Anspruch (Zahlbetrag -4.017,00 EUR)


# Fall-ID: POSITIV:run-20261015-100353-13234168534251085179:TF07
geforderte_pruefpunkte = V1, V2, V3, V4, V5, V6, V7, V8, S1, S2, S3, S4, S5, S6, S7

## TF 07 WEB-STANDARDRENTE SWEET-W-0007
status = VERIFIZIERT
hauptperson = Web, Willi 7
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4971
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1448.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=480.00, kdu_betrieb=40.00, kdu_heizung=85.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=605.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1168.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1168.00
bg_gesamtbedarf=1168.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1168.00
budget_rest_hypothetisch=280.00
budget_rest_erwartet=280.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0007]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0007, sb-web-02, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0007]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0007]
    erwartet = 1168.00 | ist = 1168
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0007]
    erwartet = 280.00 | ist = 280
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0007]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:18.809 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-07-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:04:19.751 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0007)  [Bild: tf-07-schritt-02.png] -> OK — Vorgang SWEET-W-0007 (Web, Willi 7) mit Startbudget 1448.00 EUR angelegt
2026-10-15 10:04:20.637 sb-web-02 | [S3] SozialFall erfassen (RBS 1, KdU 605.00 EUR)  [Bild: tf-07-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 605.00 EUR) gespeichert
2026-10-15 10:04:21.295 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-07-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:21.558 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-07-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:04:22.198 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-07-schritt-06.png] -> OK — Vorgang SWEET-W-0007 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:22.846 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-07-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)


# Fall-ID: NEGATIV:run-20261015-100608-12296938910290168033:TF07
geforderte_pruefpunkte = V1, V2, V3, V4, V5, S1, S2, S3, S4

## TF 07 WEB-NEG-BUDGET SWEET-NW-0007
status = VERIFIZIERT
hauptperson = Web, Negativ 7
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 4943
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

block: Bedarf (Budget bewusst zu klein)
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 993.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=300.00, kdu_betrieb=80.00, kdu_heizung=80.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=460.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1023.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1023.00
bg_gesamtbedarf=1023.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1023.00
budget_rest_hypothetisch=-30.00
budget_rest_erwartet=993.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 1213243b120163fe, Nachher-Prüfsumme 1213243b120163fe (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0007]
    erwartet = 0 | ist = 0
V3: OK | Budget unverändert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0007]
    erwartet = 993.00 | ist = 993
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:32.990 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-07-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:06:33.959 sb-web-01 | [S2] Neuen Vorgang mit Startbudget 993.00 EUR anlegen (bewusst zu klein)  [Bild: tf-07-schritt-02.png] -> OK — Vorgang SWEET-NW-0007 (Web, Negativ 7) mit Startbudget 993.00 EUR angelegt
2026-10-15 10:06:34.879 sb-web-01 | [S3] SozialFall erfassen (Bedarf 1023.00 EUR)  [Bild: tf-07-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 460.00 EUR) gespeichert
2026-10-15 10:06:37.086 sb-web-01 | [S4] Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet  [Bild: tf-07-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Der Zahlbetrag 1.023,00 EUR übersteigt das verfügbare Restbudget von 993,00 EUR


# Fall-ID: POSITIV:run-20261015-100353-13234168534251085179:TF08
geforderte_pruefpunkte = V1, V2, V3, V4, V5, V6, V7, V8, S1, S2, S3, S4, S5, S6, S7, S8

## TF 08 WEB-STORNO SWEET-W-0008
status = VERIFIZIERT
hauptperson = Web, Willi 8
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 5840
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1276.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=490.00, kdu_betrieb=110.00, kdu_heizung=70.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=670.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1176.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1176.00
bg_gesamtbedarf=1176.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1176.00
budget_rest_hypothetisch=100.00
budget_rest_erwartet=1276.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0008]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0008, sb-web-01, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0008]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0008]
    erwartet = 1176.00 | ist = 1176
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0008]
    erwartet = 1276.00 | ist = 1276
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0008]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:19.640 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-08-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:04:20.589 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0008)  [Bild: tf-08-schritt-02.png] -> OK — Vorgang SWEET-W-0008 (Web, Willi 8) mit Startbudget 1276.00 EUR angelegt
2026-10-15 10:04:21.485 sb-web-01 | [S3] SozialFall erfassen (RBS 2, KdU 670.00 EUR)  [Bild: tf-08-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 670.00 EUR) gespeichert
2026-10-15 10:04:22.136 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-08-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:22.365 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-08-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:04:23.018 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-08-schritt-06.png] -> OK — Vorgang SWEET-W-0008 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:23.679 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-08-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:04:25.155 sb-web-01 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-08-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)


# Fall-ID: NEGATIV:run-20261015-100608-12296938910290168033:TF08
geforderte_pruefpunkte = V1, V2, V3, S1

## TF 08 WEB-NEG-LOGIN SWEET-NW-0008
status = VERIFIZIERT
hauptperson = —
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 311
ids = kollege=sb-web-01, adminKonto=web-admin, mitarbeiter=sb-web-02

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Anmeldung mit FALSCHEM Passwort versuchen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | kein Vorgang durch die abgewehrte Anmeldung entstanden
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0008]
    erwartet = 0 | ist = 0
V3: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:32.588 sb-web-02 | [S1] Anmeldung mit FALSCHEM Passwort versuchen  [Bild: tf-08-schritt-01.png] -> OK — Anmeldung abgewehrt — Oberfläche meldet: Kennung oder Passwort ist falsch


# Fall-ID: POSITIV:run-20261015-100353-13234168534251085179:TF09
geforderte_pruefpunkte = V1, V2, V3, V4, V5, V6, V7, V8, S1, S2, S3, S4, S5, S6, S7

## TF 09 WEB-STANDARDRENTE SWEET-W-0009
status = VERIFIZIERT
hauptperson = Web, Willi 9
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 4880
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1196.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=270.00, kdu_betrieb=80.00, kdu_heizung=110.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=460.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=966.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=966.00
bg_gesamtbedarf=966.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=966.00
budget_rest_hypothetisch=230.00
budget_rest_erwartet=230.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0009]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0009, sb-web-03, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0009]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0009]
    erwartet = 966.00 | ist = 966
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0009]
    erwartet = 230.00 | ist = 230
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0009]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:20.866 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-09-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:04:21.746 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0009)  [Bild: tf-09-schritt-02.png] -> OK — Vorgang SWEET-W-0009 (Web, Willi 9) mit Startbudget 1196.00 EUR angelegt
2026-10-15 10:04:22.613 sb-web-03 | [S3] SozialFall erfassen (RBS 2, KdU 460.00 EUR)  [Bild: tf-09-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 460.00 EUR) gespeichert
2026-10-15 10:04:23.275 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-09-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:23.542 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-09-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:04:24.228 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-09-schritt-06.png] -> OK — Vorgang SWEET-W-0009 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:24.907 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-09-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)


# Fall-ID: NEGATIV:run-20261015-100608-12296938910290168033:TF09
geforderte_pruefpunkte = V1, V2, V3, V4, S1, S2, S3, S4

## TF 09 WEB-NEG-OHNE-MONAT SWEET-NW-0009
status = VERIFIZIERT
hauptperson = Web, Negativ 9
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4268
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung OHNE Zahlungsmonat anordnen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 3e57db9974e6b5fa, Nachher-Prüfsumme 3e57db9974e6b5fa (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Vorgang angelegt
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0009]
    erwartet = 1 | ist = 1
V3: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0009]
    erwartet = 0 | ist = 0
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:33.305 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-09-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:06:34.275 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0009)  [Bild: tf-09-schritt-02.png] -> OK — Vorgang SWEET-NW-0009 (Web, Negativ 9) mit Startbudget 1200 EUR angelegt
2026-10-15 10:06:35.162 sb-web-02 | [S3] SozialFall erfassen (RBS 1)  [Bild: tf-09-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 540 EUR) gespeichert
2026-10-15 10:06:36.858 sb-web-02 | [S4] Auszahlung OHNE Zahlungsmonat anordnen  [Bild: tf-09-schritt-04.png] -> OK — Anordnung ohne Zahlungsmonat abgewehrt — Fehlerdialog: Bitte den Zahlungsmonat wählen.

