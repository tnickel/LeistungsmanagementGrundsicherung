# testsweet Lauf

gesamtergebnis = UNVERIFIED
lauf_erfolgreich = false
automatik_bestanden = true
ki_fachstatus = UNVERIFIED
gesamtfehler = KI-Prüfung ist ausstehend.
globale_pruefung = Pruefung[beschreibung=Global: Anzahl SWEET-Vorgänge, erwartet=60, ist=60, ok=true, hinweis=null, sql=null, parameter=[]]
globale_pruefung = Pruefung[beschreibung=Global: keine Übergabe ohne Freigabevermerk, erwartet=0, ist=0, ok=true, hinweis=null, sql=null, parameter=[]]
produkt = SDN.Leistung LMG
modus = 2-web (Weboberfläche/Selenium)
kategorie = POSITIV
start = 2026-10-15T10:03:53.520434700
ende = 2026-10-15T10:06:06.598713500
dauer_s = 133
db = jdbc:oracle:thin:@//localhost:1521/FREEPDB1
db_user = REVIEW_20261015
mitarbeiter = 3
auftraege = 60
seed = 20261015
denkzeit_ms = 0
ergebnis.verifiziert = 60
ergebnis.verifikation_nio = 0
ergebnis.fehlgeschlagen = 0
ergebnis.gesamt = 60
hinweis: Soll-Beträge werden mit der Produktionsberechnung (Leistungsberechnung) ermittelt und jeder erzeugte Rechenblock vor dem Laufurteil unabhängig nachgerechnet (dokumentierter Rechenstand 2026). Zusätzliche Goldwerte-Absicherung: GoldWerteTest im Hauptprojekt (Werte aus doc/regressionstests.md).

## pruefanleitung_fur_ki

Diese Datei ist das maschinenlesbare Protokoll eines testsweet-Laufs der Fachanwendung SDN.Leistung (Grundsicherung im Alter/bei Erwerbsminderung, SGB XII). Bitte unabhängig überprüfen:

1. BETRÄGE NACHRECHNEN (Positivfälle): Je Testfall stehen unter '### rechenwege' die Eingaben je Person (p1_eingaben, p2_eingaben, ...) und JEDE Zwischengröße (regelbedarf, mehrbedarfe, kdu, anrechenbar, bg_zahlbetrag, budget_rest_hypothetisch). Das hypothetische Restbudget beschreibt nur Startbudget minus Anspruch, keine tatsächliche Buchung. Ein explizites budget_rest_erwartet bzw. die SQL-Erwartung beschreibt den Buchungsendzustand; bei Abweisung bleibt das Budget unverändert, Storno gibt den Betrag zurück. Rechne mit den Formeln aus '## rechengrundlagen_2026' jeden Zwischenwert und den Zahlbetrag selbst nach und melde jede Abweichung.
2. ERWARTET/GEGEN IST HALTEN: Unter '### verifikation' steht je Prüfung V1..Vn das prüfende SQL mit konkreten Parametern sowie 'erwartet' und 'ist'. Prüfe, ob die erwarteten Werte fachlich aus den Eingaben folgen und ob ist = erwartet ist (NIO-Zeilen sind Fehler).
3. NEGATIVFÄLLE PLAUSIBILISIEREN: Schritte mit 'ERWARTETER FEHLER (CODE)' müssen fachlich zwingend abgewehrt werden (z. B. KEIN_ANSPRUCH wenn Einkommen/Vermögen den Bedarf übersteigt, VALIDATION bei Doppelanordnung je Monat oder Zahlungsmonat außerhalb des Bewilligungszeitraums, BERECHTIGUNG bei Selbstfreigabe, KONKURRENZ bei veraltetem Maskenstand, BUDGET_ERSCHOEPFT bei zu kleinem Startbudget). Prüfe, dass der Datenbank-Endzustand unverändert geblieben ist (keine Zahlung, Budget unangetastet).
4. GRENZEN: Last-/Stresstests erzeugen nur Aggregate (kein Einzelfall-Nachrechnen); Web-Läufe (modus 2-web) nutzen dieselbe Datenstruktur, dokumentieren aber UI-Schritte. Globale Prüfungen stehen im Kopf als globale_pruefung-Zeilen.
Das verbindliche Antwortschema steht im übergeordneten Prüfauftrag. Dieser Datenanhang legt kein abweichendes Antwortformat fest.

## rechengrundlagen_2026

rbs_eur = {1: 563.00, 2: 506.00, 3: 451.00, 4: 471.00, 5: 390.00, 6: 357.00}  (Anlage zu § 28 SGB XII)
mehrbedarf_g = 0.17 * regelbedarf  (§ 30 Abs. 1)
mehrbedarf_schwanger = 0.17 * regelbedarf  (§ 30 Abs. 2, ab 13. SSW; entfaellt automatisch, wenn entbindungsmonat gesetzt und zahlungsmonat > entbindungsmonat)
mehrbedarf_alleinerziehend = 0.36 * rbs1 bei kind_u7>=1 oder 2<=kinder_u16<=3, sonst 0.12 * rbs1 je minderjaehrigem kind; deckel 0.60 * rbs1 = 337.80  (§ 30 Abs. 3)
mehrbedarf_obergrenze = summe(abs1..5) <= regelbedarf  (§ 30 Abs. 6)
mehrbedarf_warmwasser_anteil = {1: 0.023, 2: 0.023, 3: 0.0, 4: 0.014, 5: 0.012, 6: 0.008}  (§ 30 Abs. 7, zusaetzlich zu Abs. 6)
kdu = kaltmiete + betriebskosten + heizung - zentraler warmwasserabzug; gekappt auf verbleibende BG-Grenze, sofern > 0. Parameter stehen je Block.
erwerbsfreibetrag = min(0.30 * erwerb_brutto, 0.50 * rbs1 = 281.50)  (§ 82 Abs. 3)
anrechenbar = rente + erwerb - freibetrag - absetzbetaetrag >= 0  (absetzbetraege: steuern, sv, versicherungen, erwerbsaufwendungen; § 82 Abs. 2)
schonvermoegen = 10000.00 je volljaehriger person (rbs 1-3) + 500.00 je weiterer person; Produktvertrag ohne Erwachsene: Grundbetrag einmal 10000.00. Referenz des implementierten Vertrags, keine eigenständige Rechtsverifikation.
zahlbetrag = gesamtbedarf - anrechenbares_einkommen - max(vermoegen - schonvermoegen, 0)  (<= 0 => KEIN_ANSPRUCH, § 43 Abs. 1)
rundung = HALF_UP auf 2 nachkommastellen; waehrung EUR
zahlstatus = ANGELEGT (wartet auf freigabe) -> BEREIT -> UEBERGEBEN; STORNIERT gibt monat frei
sepa_iban = ISO 13616: laenderspezifische Gesamtlaenge (Deutschland genau 22 Zeichen); Pruefziffer-Validierung: die verschobene Ziffernfolge (BBAN, dann Laendercode-Verdraengung 1314, dann Pruefziffer) ergibt Modulo 97 genau 1. Abweichung von Laenge oder Pruefziffer => VALIDATION 'Ungueltige IBAN'.
sepa_bic = ISO 9362: genau 8 oder 11 Zeichen (4 Buchstaben Bankcode, 2 Buchstaben Laendercode, 2 alphanumerische Ortskennung, optional 3 alphanumerische Zweigstelle). Andere Laenge/Struktur => VALIDATION 'Ungueltiger BIC'.

## TF 01 WEB-STANDARDRENTE SWEET-W-0001
status = VERIFIZIERT
hauptperson = Web, Willi 1
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 5417
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1448.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=550.00, kdu_betrieb=75.00, kdu_heizung=100.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=725.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1288.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1288.00
bg_gesamtbedarf=1288.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1288.00
budget_rest_hypothetisch=160.00
budget_rest_erwartet=160.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0001]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0001, sb-web-01, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0001]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0001]
    erwartet = 1288.00 | ist = 1288
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0001]
    erwartet = 160.00 | ist = 160
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0001]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:07.875 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-01-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:04:08.866 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0001)  [Bild: tf-01-schritt-02.png] -> OK — Vorgang SWEET-W-0001 (Web, Willi 1) mit Startbudget 1448.00 EUR angelegt
2026-10-15 10:04:09.927 sb-web-01 | [S3] SozialFall erfassen (RBS 1, KdU 725.00 EUR)  [Bild: tf-01-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 725.00 EUR) gespeichert
2026-10-15 10:04:10.660 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-01-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:10.976 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-01-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:04:11.665 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-01-schritt-06.png] -> OK — Vorgang SWEET-W-0001 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:12.364 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-01-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 02 WEB-STANDARDRENTE SWEET-W-0002
status = VERIFIZIERT
hauptperson = Web, Willi 2
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 5430
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1146.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=290.00, kdu_betrieb=100.00, kdu_heizung=130.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=520.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1026.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1026.00
bg_gesamtbedarf=1026.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1026.00
budget_rest_hypothetisch=120.00
budget_rest_erwartet=120.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0002]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0002, sb-web-02, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0002]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0002]
    erwartet = 1026.00 | ist = 1026
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0002]
    erwartet = 120.00 | ist = 120
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0002]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:08.100 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-02-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:04:09.092 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0002)  [Bild: tf-02-schritt-02.png] -> OK — Vorgang SWEET-W-0002 (Web, Willi 2) mit Startbudget 1146.00 EUR angelegt
2026-10-15 10:04:10.154 sb-web-02 | [S3] SozialFall erfassen (RBS 2, KdU 520.00 EUR)  [Bild: tf-02-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 520.00 EUR) gespeichert
2026-10-15 10:04:10.894 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-02-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:11.437 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-02-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:04:12.205 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-02-schritt-06.png] -> OK — Vorgang SWEET-W-0002 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:12.906 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-02-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 03 WEB-STANDARDRENTE SWEET-W-0003
status = VERIFIZIERT
hauptperson = Web, Willi 3
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5044
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1186.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=390.00, kdu_betrieb=55.00, kdu_heizung=90.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=535.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=986.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=986.00
bg_gesamtbedarf=986.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=986.00
budget_rest_hypothetisch=200.00
budget_rest_erwartet=200.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0003]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0003, sb-web-03, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0003]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0003]
    erwartet = 986.00 | ist = 986
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0003]
    erwartet = 200.00 | ist = 200
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0003]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:08.414 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-03-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:04:09.376 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0003)  [Bild: tf-03-schritt-02.png] -> OK — Vorgang SWEET-W-0003 (Web, Willi 3) mit Startbudget 1186.00 EUR angelegt
2026-10-15 10:04:10.344 sb-web-03 | [S3] SozialFall erfassen (RBS 3, KdU 535.00 EUR)  [Bild: tf-03-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 535.00 EUR) gespeichert
2026-10-15 10:04:11.272 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-03-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:11.641 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-03-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:04:12.365 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-03-schritt-06.png] -> OK — Vorgang SWEET-W-0003 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:13.073 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-03-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 04 WEB-STORNO SWEET-W-0004
status = VERIFIZIERT
hauptperson = Web, Willi 4
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 6949
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1311.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=440.00, kdu_betrieb=115.00, kdu_heizung=100.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=655.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1161.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1161.00
bg_gesamtbedarf=1161.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1161.00
budget_rest_hypothetisch=150.00
budget_rest_erwartet=1311.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0004]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0004, sb-web-01, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0004]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0004]
    erwartet = 1161.00 | ist = 1161
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0004]
    erwartet = 1311.00 | ist = 1311
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0004]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:13.195 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-04-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:04:14.343 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0004)  [Bild: tf-04-schritt-02.png] -> OK — Vorgang SWEET-W-0004 (Web, Willi 4) mit Startbudget 1311.00 EUR angelegt
2026-10-15 10:04:15.343 sb-web-01 | [S3] SozialFall erfassen (RBS 2, KdU 655.00 EUR)  [Bild: tf-04-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 655.00 EUR) gespeichert
2026-10-15 10:04:16.044 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-04-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:16.327 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-04-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:04:17.049 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-04-schritt-06.png] -> OK — Vorgang SWEET-W-0004 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:17.717 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-04-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:04:19.314 sb-web-01 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-04-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 05 WEB-STANDARDRENTE SWEET-W-0005
status = VERIFIZIERT
hauptperson = Web, Willi 5
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4967
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1426.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=540.00, kdu_betrieb=75.00, kdu_heizung=85.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=700.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1206.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1206.00
bg_gesamtbedarf=1206.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1206.00
budget_rest_hypothetisch=220.00
budget_rest_erwartet=220.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0005]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0005, sb-web-02, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0005]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0005]
    erwartet = 1206.00 | ist = 1206
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0005]
    erwartet = 220.00 | ist = 220
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0005]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:13.273 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-05-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:04:14.406 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0005)  [Bild: tf-05-schritt-02.png] -> OK — Vorgang SWEET-W-0005 (Web, Willi 5) mit Startbudget 1426.00 EUR angelegt
2026-10-15 10:04:15.440 sb-web-02 | [S3] SozialFall erfassen (RBS 2, KdU 700.00 EUR)  [Bild: tf-05-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 700.00 EUR) gespeichert
2026-10-15 10:04:16.161 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-05-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:16.483 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-05-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:04:17.204 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-05-schritt-06.png] -> OK — Vorgang SWEET-W-0005 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:17.874 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-05-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 06 WEB-STORNO SWEET-W-0006
status = VERIFIZIERT
hauptperson = Web, Willi 6
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 6953
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1376.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=520.00, kdu_betrieb=35.00, kdu_heizung=70.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=625.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1076.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1076.00
bg_gesamtbedarf=1076.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1076.00
budget_rest_hypothetisch=300.00
budget_rest_erwartet=1376.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0006]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0006, sb-web-03, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0006]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0006]
    erwartet = 1076.00 | ist = 1076
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0006]
    erwartet = 1376.00 | ist = 1376
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0006]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:13.502 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-06-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:04:14.558 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0006)  [Bild: tf-06-schritt-02.png] -> OK — Vorgang SWEET-W-0006 (Web, Willi 6) mit Startbudget 1376.00 EUR angelegt
2026-10-15 10:04:15.575 sb-web-03 | [S3] SozialFall erfassen (RBS 3, KdU 625.00 EUR)  [Bild: tf-06-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 625.00 EUR) gespeichert
2026-10-15 10:04:16.285 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-06-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:17.064 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-06-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:04:17.718 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-06-schritt-06.png] -> OK — Vorgang SWEET-W-0006 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:18.403 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-06-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:04:20.027 sb-web-03 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-06-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 07 WEB-STANDARDRENTE SWEET-W-0007
status = VERIFIZIERT
hauptperson = Web, Willi 7
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4971
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1448.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=480.00, kdu_betrieb=40.00, kdu_heizung=85.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=605.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1168.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1168.00
bg_gesamtbedarf=1168.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1168.00
budget_rest_hypothetisch=280.00
budget_rest_erwartet=280.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0007]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0007, sb-web-02, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0007]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0007]
    erwartet = 1168.00 | ist = 1168
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0007]
    erwartet = 280.00 | ist = 280
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0007]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:18.809 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-07-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:04:19.751 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0007)  [Bild: tf-07-schritt-02.png] -> OK — Vorgang SWEET-W-0007 (Web, Willi 7) mit Startbudget 1448.00 EUR angelegt
2026-10-15 10:04:20.637 sb-web-02 | [S3] SozialFall erfassen (RBS 1, KdU 605.00 EUR)  [Bild: tf-07-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 605.00 EUR) gespeichert
2026-10-15 10:04:21.295 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-07-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:21.558 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-07-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:04:22.198 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-07-schritt-06.png] -> OK — Vorgang SWEET-W-0007 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:22.846 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-07-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 08 WEB-STORNO SWEET-W-0008
status = VERIFIZIERT
hauptperson = Web, Willi 8
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 5840
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1276.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=490.00, kdu_betrieb=110.00, kdu_heizung=70.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=670.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1176.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1176.00
bg_gesamtbedarf=1176.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1176.00
budget_rest_hypothetisch=100.00
budget_rest_erwartet=1276.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0008]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0008, sb-web-01, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0008]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0008]
    erwartet = 1176.00 | ist = 1176
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0008]
    erwartet = 1276.00 | ist = 1276
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0008]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:19.640 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-08-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:04:20.589 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0008)  [Bild: tf-08-schritt-02.png] -> OK — Vorgang SWEET-W-0008 (Web, Willi 8) mit Startbudget 1276.00 EUR angelegt
2026-10-15 10:04:21.485 sb-web-01 | [S3] SozialFall erfassen (RBS 2, KdU 670.00 EUR)  [Bild: tf-08-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 670.00 EUR) gespeichert
2026-10-15 10:04:22.136 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-08-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:22.365 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-08-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:04:23.018 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-08-schritt-06.png] -> OK — Vorgang SWEET-W-0008 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:23.679 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-08-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:04:25.155 sb-web-01 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-08-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 09 WEB-STANDARDRENTE SWEET-W-0009
status = VERIFIZIERT
hauptperson = Web, Willi 9
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 4880
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1196.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=270.00, kdu_betrieb=80.00, kdu_heizung=110.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=460.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=966.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=966.00
bg_gesamtbedarf=966.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=966.00
budget_rest_hypothetisch=230.00
budget_rest_erwartet=230.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0009]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0009, sb-web-03, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0009]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0009]
    erwartet = 966.00 | ist = 966
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0009]
    erwartet = 230.00 | ist = 230
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0009]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:20.866 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-09-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:04:21.746 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0009)  [Bild: tf-09-schritt-02.png] -> OK — Vorgang SWEET-W-0009 (Web, Willi 9) mit Startbudget 1196.00 EUR angelegt
2026-10-15 10:04:22.613 sb-web-03 | [S3] SozialFall erfassen (RBS 2, KdU 460.00 EUR)  [Bild: tf-09-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 460.00 EUR) gespeichert
2026-10-15 10:04:23.275 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-09-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:23.542 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-09-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:04:24.228 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-09-schritt-06.png] -> OK — Vorgang SWEET-W-0009 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:24.907 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-09-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 10 WEB-STORNO SWEET-W-0010
status = VERIFIZIERT
hauptperson = Web, Willi 10
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 5820
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1113.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=270.00, kdu_betrieb=80.00, kdu_heizung=80.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=430.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=993.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=993.00
bg_gesamtbedarf=993.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=993.00
budget_rest_hypothetisch=120.00
budget_rest_erwartet=1113.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0010]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0010, sb-web-02, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0010]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0010]
    erwartet = 993.00 | ist = 993
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0010]
    erwartet = 1113.00 | ist = 1113
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0010]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:23.124 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-10-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:04:24.031 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0010)  [Bild: tf-10-schritt-02.png] -> OK — Vorgang SWEET-W-0010 (Web, Willi 10) mit Startbudget 1113.00 EUR angelegt
2026-10-15 10:04:24.907 sb-web-02 | [S3] SozialFall erfassen (RBS 1, KdU 430.00 EUR)  [Bild: tf-10-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 430.00 EUR) gespeichert
2026-10-15 10:04:25.607 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-10-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:25.887 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-10-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:04:26.553 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-10-schritt-06.png] -> OK — Vorgang SWEET-W-0010 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:27.219 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-10-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:04:28.668 sb-web-02 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-10-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 11 WEB-MEHRBEDARF SWEET-W-0011
status = VERIFIZIERT
hauptperson = Web, Willi 11
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 4829
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1322.67
p1_eingaben: rbs=3, merkzeichen_g=true, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=470.00, kdu_betrieb=65.00, kdu_heizung=50.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=76.67
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=585.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1112.67
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1112.67
bg_gesamtbedarf=1112.67
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1112.67
budget_rest_hypothetisch=210.00
budget_rest_erwartet=210.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0011]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0011, sb-web-03, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0011]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0011]
    erwartet = 1112.67 | ist = 1112.67
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0011]
    erwartet = 210.00 | ist = 210
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0011]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:25.732 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-11-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:04:26.646 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0011)  [Bild: tf-11-schritt-02.png] -> OK — Vorgang SWEET-W-0011 (Web, Willi 11) mit Startbudget 1322.67 EUR angelegt
2026-10-15 10:04:27.499 sb-web-03 | [S3] SozialFall erfassen (RBS 3, KdU 585.00 EUR)  [Bild: tf-11-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 585.00 EUR) gespeichert
2026-10-15 10:04:28.162 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-11-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:28.426 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-11-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:04:29.085 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-11-schritt-06.png] -> OK — Vorgang SWEET-W-0011 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:29.737 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-11-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 12 WEB-STORNO SWEET-W-0012
status = VERIFIZIERT
hauptperson = Web, Willi 12
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 5709
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1196.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=250.00, kdu_betrieb=45.00, kdu_heizung=115.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=410.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=916.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=916.00
bg_gesamtbedarf=916.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=916.00
budget_rest_hypothetisch=280.00
budget_rest_erwartet=1196.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0012]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0012, sb-web-01, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0012]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0012]
    erwartet = 916.00 | ist = 916
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0012]
    erwartet = 1196.00 | ist = 1196
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0012]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:25.433 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-12-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:04:26.364 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0012)  [Bild: tf-12-schritt-02.png] -> OK — Vorgang SWEET-W-0012 (Web, Willi 12) mit Startbudget 1196.00 EUR angelegt
2026-10-15 10:04:27.204 sb-web-01 | [S3] SozialFall erfassen (RBS 2, KdU 410.00 EUR)  [Bild: tf-12-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 410.00 EUR) gespeichert
2026-10-15 10:04:27.862 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-12-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:28.101 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-12-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:04:28.761 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-12-schritt-06.png] -> OK — Vorgang SWEET-W-0012 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:29.428 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-12-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:04:30.865 sb-web-01 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-12-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 13 WEB-STORNO SWEET-W-0013
status = VERIFIZIERT
hauptperson = Web, Willi 13
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 6676
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1341.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=400.00, kdu_betrieb=65.00, kdu_heizung=110.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=575.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1081.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1081.00
bg_gesamtbedarf=1081.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1081.00
budget_rest_hypothetisch=260.00
budget_rest_erwartet=1341.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0013]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0013, sb-web-02, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0013]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0013]
    erwartet = 1081.00 | ist = 1081
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0013]
    erwartet = 1341.00 | ist = 1341
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0013]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:29.444 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-13-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:04:30.369 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0013)  [Bild: tf-13-schritt-02.png] -> OK — Vorgang SWEET-W-0013 (Web, Willi 13) mit Startbudget 1341.00 EUR angelegt
2026-10-15 10:04:31.177 sb-web-02 | [S3] SozialFall erfassen (RBS 2, KdU 575.00 EUR)  [Bild: tf-13-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 575.00 EUR) gespeichert
2026-10-15 10:04:31.849 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-13-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:32.107 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-13-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:04:32.746 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-13-schritt-06.png] -> OK — Vorgang SWEET-W-0013 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:33.422 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-13-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:04:35.345 sb-web-02 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-13-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 14 WEB-STANDARDRENTE SWEET-W-0014
status = VERIFIZIERT
hauptperson = Web, Willi 14
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 4724
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1361.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=540.00, kdu_betrieb=35.00, kdu_heizung=140.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=715.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1221.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1221.00
bg_gesamtbedarf=1221.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1221.00
budget_rest_hypothetisch=140.00
budget_rest_erwartet=140.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0014]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0014, sb-web-03, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0014]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0014]
    erwartet = 1221.00 | ist = 1221
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0014]
    erwartet = 140.00 | ist = 140
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0014]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:30.540 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-14-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:04:31.378 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0014)  [Bild: tf-14-schritt-02.png] -> OK — Vorgang SWEET-W-0014 (Web, Willi 14) mit Startbudget 1361.00 EUR angelegt
2026-10-15 10:04:32.213 sb-web-03 | [S3] SozialFall erfassen (RBS 2, KdU 715.00 EUR)  [Bild: tf-14-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 715.00 EUR) gespeichert
2026-10-15 10:04:32.881 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-14-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:33.131 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-14-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:04:33.816 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-14-schritt-06.png] -> OK — Vorgang SWEET-W-0014 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:34.462 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-14-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 15 WEB-STORNO SWEET-W-0015
status = VERIFIZIERT
hauptperson = Web, Willi 15
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 7159
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1436.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=550.00, kdu_betrieb=30.00, kdu_heizung=115.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=695.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1146.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1146.00
bg_gesamtbedarf=1146.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1146.00
budget_rest_hypothetisch=290.00
budget_rest_erwartet=1436.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0015]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0015, sb-web-01, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0015]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0015]
    erwartet = 1146.00 | ist = 1146
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0015]
    erwartet = 1436.00 | ist = 1436
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0015]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:31.674 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-15-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:04:32.523 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0015)  [Bild: tf-15-schritt-02.png] -> OK — Vorgang SWEET-W-0015 (Web, Willi 15) mit Startbudget 1436.00 EUR angelegt
2026-10-15 10:04:33.392 sb-web-01 | [S3] SozialFall erfassen (RBS 3, KdU 695.00 EUR)  [Bild: tf-15-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 695.00 EUR) gespeichert
2026-10-15 10:04:34.064 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-15-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:34.297 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-15-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:04:34.946 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-15-schritt-06.png] -> OK — Vorgang SWEET-W-0015 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:35.609 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-15-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:04:38.025 sb-web-01 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-15-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 16 WEB-STANDARDRENTE SWEET-W-0016
status = VERIFIZIERT
hauptperson = Web, Willi 16
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5498
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1293.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=460.00, kdu_betrieb=35.00, kdu_heizung=75.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=570.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1133.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1133.00
bg_gesamtbedarf=1133.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1133.00
budget_rest_hypothetisch=160.00
budget_rest_erwartet=160.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0016]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0016, sb-web-03, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0016]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0016]
    erwartet = 1133.00 | ist = 1133
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0016]
    erwartet = 160.00 | ist = 160
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0016]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:35.254 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-16-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:04:36.413 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0016)  [Bild: tf-16-schritt-02.png] -> OK — Vorgang SWEET-W-0016 (Web, Willi 16) mit Startbudget 1293.00 EUR angelegt
2026-10-15 10:04:37.460 sb-web-03 | [S3] SozialFall erfassen (RBS 1, KdU 570.00 EUR)  [Bild: tf-16-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 570.00 EUR) gespeichert
2026-10-15 10:04:38.159 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-16-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:38.462 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-16-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:04:39.201 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-16-schritt-06.png] -> OK — Vorgang SWEET-W-0016 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:39.961 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-16-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 17 WEB-MEHRBEDARF SWEET-W-0017
status = VERIFIZIERT
hauptperson = Web, Willi 17
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 6607
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1405.95
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=true, kdu_miete=350.00, kdu_betrieb=95.00, kdu_heizung=105.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=12.95
p1_kdu=550.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1125.95
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1125.95
bg_gesamtbedarf=1125.95
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1125.95
budget_rest_hypothetisch=280.00
budget_rest_erwartet=280.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0017]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0017, sb-web-02, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0017]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0017]
    erwartet = 1125.95 | ist = 1125.95
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0017]
    erwartet = 280.00 | ist = 280
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0017]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:36.532 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-17-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:04:37.491 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0017)  [Bild: tf-17-schritt-02.png] -> OK — Vorgang SWEET-W-0017 (Web, Willi 17) mit Startbudget 1405.95 EUR angelegt
2026-10-15 10:04:38.411 sb-web-02 | [S3] SozialFall erfassen (RBS 1, KdU 550.00 EUR)  [Bild: tf-17-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 550.00 EUR) gespeichert
2026-10-15 10:04:39.257 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-17-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:40.010 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-17-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:04:40.975 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-17-schritt-06.png] -> OK — Vorgang SWEET-W-0017 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:41.953 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-17-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 18 WEB-STORNO SWEET-W-0018
status = VERIFIZIERT
hauptperson = Web, Willi 18
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 7125
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1201.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=330.00, kdu_betrieb=50.00, kdu_heizung=75.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=455.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=961.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=961.00
bg_gesamtbedarf=961.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=961.00
budget_rest_hypothetisch=240.00
budget_rest_erwartet=1201.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0018]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0018, sb-web-01, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0018]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0018]
    erwartet = 961.00 | ist = 961
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0018]
    erwartet = 1201.00 | ist = 1201
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0018]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:38.342 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-18-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:04:39.356 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0018)  [Bild: tf-18-schritt-02.png] -> OK — Vorgang SWEET-W-0018 (Web, Willi 18) mit Startbudget 1201.00 EUR angelegt
2026-10-15 10:04:40.992 sb-web-01 | [S3] SozialFall erfassen (RBS 2, KdU 455.00 EUR)  [Bild: tf-18-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 455.00 EUR) gespeichert
2026-10-15 10:04:41.953 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-18-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:42.270 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-18-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:04:42.970 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-18-schritt-06.png] -> OK — Vorgang SWEET-W-0018 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:43.656 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-18-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:04:45.152 sb-web-01 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-18-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 19 WEB-MEHRBEDARF SWEET-W-0019
status = VERIFIZIERT
hauptperson = Web, Willi 19
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5780
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1303.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=410.00, kdu_betrieb=120.00, kdu_heizung=110.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=640.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1203.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1203.00
bg_gesamtbedarf=1203.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1203.00
budget_rest_hypothetisch=100.00
budget_rest_erwartet=100.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0019]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0019, sb-web-03, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0019]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0019]
    erwartet = 1203.00 | ist = 1203
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0019]
    erwartet = 100.00 | ist = 100
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0019]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:41.107 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-19-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:04:42.490 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0019)  [Bild: tf-19-schritt-02.png] -> OK — Vorgang SWEET-W-0019 (Web, Willi 19) mit Startbudget 1303.00 EUR angelegt
2026-10-15 10:04:43.407 sb-web-03 | [S3] SozialFall erfassen (RBS 1, KdU 640.00 EUR)  [Bild: tf-19-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 640.00 EUR) gespeichert
2026-10-15 10:04:44.122 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-19-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:44.390 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-19-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:04:45.059 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-19-schritt-06.png] -> OK — Vorgang SWEET-W-0019 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:45.743 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-19-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 20 WEB-STORNO SWEET-W-0020
status = VERIFIZIERT
hauptperson = Web, Willi 20
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 6937
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1341.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=390.00, kdu_betrieb=75.00, kdu_heizung=140.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=605.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1111.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1111.00
bg_gesamtbedarf=1111.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1111.00
budget_rest_hypothetisch=230.00
budget_rest_erwartet=1341.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0020]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0020, sb-web-02, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0020]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0020]
    erwartet = 1111.00 | ist = 1111
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0020]
    erwartet = 1341.00 | ist = 1341
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0020]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:42.776 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-20-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:04:43.740 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0020)  [Bild: tf-20-schritt-02.png] -> OK — Vorgang SWEET-W-0020 (Web, Willi 20) mit Startbudget 1341.00 EUR angelegt
2026-10-15 10:04:44.654 sb-web-02 | [S3] SozialFall erfassen (RBS 2, KdU 605.00 EUR)  [Bild: tf-20-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 605.00 EUR) gespeichert
2026-10-15 10:04:45.323 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-20-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:46.061 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-20-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:04:46.727 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-20-schritt-06.png] -> OK — Vorgang SWEET-W-0020 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:47.379 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-20-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:04:48.891 sb-web-02 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-20-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 21 WEB-STORNO SWEET-W-0021
status = VERIFIZIERT
hauptperson = Web, Willi 21
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 6416
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1146.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=310.00, kdu_betrieb=50.00, kdu_heizung=65.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=425.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=876.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=876.00
bg_gesamtbedarf=876.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=876.00
budget_rest_hypothetisch=270.00
budget_rest_erwartet=1146.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0021]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0021, sb-web-01, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0021]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0021]
    erwartet = 876.00 | ist = 876
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0021]
    erwartet = 1146.00 | ist = 1146
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0021]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:45.432 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-21-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:04:46.389 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0021)  [Bild: tf-21-schritt-02.png] -> OK — Vorgang SWEET-W-0021 (Web, Willi 21) mit Startbudget 1146.00 EUR angelegt
2026-10-15 10:04:47.286 sb-web-01 | [S3] SozialFall erfassen (RBS 3, KdU 425.00 EUR)  [Bild: tf-21-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 425.00 EUR) gespeichert
2026-10-15 10:04:47.952 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-21-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:48.660 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-21-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:04:49.382 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-21-schritt-06.png] -> OK — Vorgang SWEET-W-0021 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:50.076 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-21-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:04:51.570 sb-web-01 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-21-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 22 WEB-MEHRBEDARF SWEET-W-0022
status = VERIFIZIERT
hauptperson = Web, Willi 22
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5061
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1187.64
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=true, kdu_miete=280.00, kdu_betrieb=95.00, kdu_heizung=105.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=11.64
p1_kdu=480.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=997.64
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=997.64
bg_gesamtbedarf=997.64
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=997.64
budget_rest_hypothetisch=190.00
budget_rest_erwartet=190.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0022]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0022, sb-web-03, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0022]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0022]
    erwartet = 997.64 | ist = 997.64
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0022]
    erwartet = 190.00 | ist = 190
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0022]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:46.513 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-22-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:04:47.491 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0022)  [Bild: tf-22-schritt-02.png] -> OK — Vorgang SWEET-W-0022 (Web, Willi 22) mit Startbudget 1187.64 EUR angelegt
2026-10-15 10:04:48.433 sb-web-03 | [S3] SozialFall erfassen (RBS 2, KdU 480.00 EUR)  [Bild: tf-22-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 480.00 EUR) gespeichert
2026-10-15 10:04:49.135 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-22-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:49.424 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-22-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:04:50.122 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-22-schritt-06.png] -> OK — Vorgang SWEET-W-0022 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:50.805 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-22-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 23 WEB-MEHRBEDARF SWEET-W-0023
status = VERIFIZIERT
hauptperson = Web, Willi 23
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4733
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1496.66
p1_eingaben: rbs=1, merkzeichen_g=true, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=true, kdu_miete=340.00, kdu_betrieb=115.00, kdu_heizung=70.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=95.71
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=12.95
p1_kdu=525.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1196.66
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1196.66
bg_gesamtbedarf=1196.66
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1196.66
budget_rest_hypothetisch=300.00
budget_rest_erwartet=300.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0023]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0023, sb-web-02, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0023]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0023]
    erwartet = 1196.66 | ist = 1196.66
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0023]
    erwartet = 300.00 | ist = 300
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0023]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:49.248 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-23-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:04:50.275 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0023)  [Bild: tf-23-schritt-02.png] -> OK — Vorgang SWEET-W-0023 (Web, Willi 23) mit Startbudget 1496.66 EUR angelegt
2026-10-15 10:04:51.204 sb-web-02 | [S3] SozialFall erfassen (RBS 1, KdU 525.00 EUR)  [Bild: tf-23-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 525.00 EUR) gespeichert
2026-10-15 10:04:51.897 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-23-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:52.150 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-23-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:04:52.857 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-23-schritt-06.png] -> OK — Vorgang SWEET-W-0023 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:53.626 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-23-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 24 WEB-STANDARDRENTE SWEET-W-0024
status = VERIFIZIERT
hauptperson = Web, Willi 24
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5798
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1368.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=410.00, kdu_betrieb=80.00, kdu_heizung=85.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=575.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1138.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1138.00
bg_gesamtbedarf=1138.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1138.00
budget_rest_hypothetisch=230.00
budget_rest_erwartet=230.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0024]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0024, sb-web-03, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0024]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0024]
    erwartet = 1138.00 | ist = 1138
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0024]
    erwartet = 230.00 | ist = 230
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0024]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:51.585 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-24-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:04:52.591 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0024)  [Bild: tf-24-schritt-02.png] -> OK — Vorgang SWEET-W-0024 (Web, Willi 24) mit Startbudget 1368.00 EUR angelegt
2026-10-15 10:04:53.641 sb-web-03 | [S3] SozialFall erfassen (RBS 1, KdU 575.00 EUR)  [Bild: tf-24-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 575.00 EUR) gespeichert
2026-10-15 10:04:54.556 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-24-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:54.812 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-24-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:04:55.924 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-24-schritt-06.png] -> OK — Vorgang SWEET-W-0024 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:56.605 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-24-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 25 WEB-STORNO SWEET-W-0025
status = VERIFIZIERT
hauptperson = Web, Willi 25
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 7338
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1426.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=470.00, kdu_betrieb=105.00, kdu_heizung=65.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=640.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1146.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1146.00
bg_gesamtbedarf=1146.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1146.00
budget_rest_hypothetisch=280.00
budget_rest_erwartet=1426.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0025]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0025, sb-web-01, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0025]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0025]
    erwartet = 1146.00 | ist = 1146
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0025]
    erwartet = 1426.00 | ist = 1426
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0025]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:51.908 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-25-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:04:52.884 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0025)  [Bild: tf-25-schritt-02.png] -> OK — Vorgang SWEET-W-0025 (Web, Willi 25) mit Startbudget 1426.00 EUR angelegt
2026-10-15 10:04:53.991 sb-web-01 | [S3] SozialFall erfassen (RBS 2, KdU 640.00 EUR)  [Bild: tf-25-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 640.00 EUR) gespeichert
2026-10-15 10:04:54.663 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-25-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:55.461 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-25-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:04:56.142 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-25-schritt-06.png] -> OK — Vorgang SWEET-W-0025 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:56.842 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-25-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:04:58.908 sb-web-01 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-25-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 26 WEB-STORNO SWEET-W-0026
status = VERIFIZIERT
hauptperson = Web, Willi 26
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 7976
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1313.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=410.00, kdu_betrieb=95.00, kdu_heizung=65.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=570.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1133.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1133.00
bg_gesamtbedarf=1133.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1133.00
budget_rest_hypothetisch=180.00
budget_rest_erwartet=1313.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0026]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0026, sb-web-02, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0026]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0026]
    erwartet = 1133.00 | ist = 1133
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0026]
    erwartet = 1313.00 | ist = 1313
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0026]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:54.957 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-26-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:04:55.941 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0026)  [Bild: tf-26-schritt-02.png] -> OK — Vorgang SWEET-W-0026 (Web, Willi 26) mit Startbudget 1313.00 EUR angelegt
2026-10-15 10:04:56.843 sb-web-02 | [S3] SozialFall erfassen (RBS 1, KdU 570.00 EUR)  [Bild: tf-26-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 570.00 EUR) gespeichert
2026-10-15 10:04:57.525 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-26-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:57.801 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-26-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:04:58.591 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-26-schritt-06.png] -> OK — Vorgang SWEET-W-0026 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:59.593 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-26-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:05:01.612 sb-web-02 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-26-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 27 WEB-MEHRBEDARF SWEET-W-0027
status = VERIFIZIERT
hauptperson = Web, Willi 27
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5453
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1051.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=true, kdu_miete=250.00, kdu_betrieb=55.00, kdu_heizung=135.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=440.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=891.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=891.00
bg_gesamtbedarf=891.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=891.00
budget_rest_hypothetisch=160.00
budget_rest_erwartet=160.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0027]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0027, sb-web-03, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0027]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0027]
    erwartet = 891.00 | ist = 891
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0027]
    erwartet = 160.00 | ist = 160
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0027]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:57.388 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-27-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:04:58.591 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0027)  [Bild: tf-27-schritt-02.png] -> OK — Vorgang SWEET-W-0027 (Web, Willi 27) mit Startbudget 1051.00 EUR angelegt
2026-10-15 10:04:59.661 sb-web-03 | [S3] SozialFall erfassen (RBS 3, KdU 440.00 EUR)  [Bild: tf-27-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 440.00 EUR) gespeichert
2026-10-15 10:05:00.371 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-27-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:00.677 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-27-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:05:01.362 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-27-schritt-06.png] -> OK — Vorgang SWEET-W-0027 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:02.060 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-27-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 28 WEB-STORNO SWEET-W-0028
status = VERIFIZIERT
hauptperson = Web, Willi 28
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 6512
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1011.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=260.00, kdu_betrieb=55.00, kdu_heizung=115.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=430.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=881.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=881.00
bg_gesamtbedarf=881.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=881.00
budget_rest_hypothetisch=130.00
budget_rest_erwartet=1011.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0028]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0028, sb-web-01, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0028]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0028]
    erwartet = 881.00 | ist = 881
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0028]
    erwartet = 1011.00 | ist = 1011
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0028]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:59.254 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-28-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:05:00.548 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0028)  [Bild: tf-28-schritt-02.png] -> OK — Vorgang SWEET-W-0028 (Web, Willi 28) mit Startbudget 1011.00 EUR angelegt
2026-10-15 10:05:01.509 sb-web-01 | [S3] SozialFall erfassen (RBS 3, KdU 430.00 EUR)  [Bild: tf-28-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 430.00 EUR) gespeichert
2026-10-15 10:05:02.220 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-28-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:02.492 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-28-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:05:03.205 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-28-schritt-06.png] -> OK — Vorgang SWEET-W-0028 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:03.887 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-28-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:05:05.423 sb-web-01 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-28-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 29 WEB-MEHRBEDARF SWEET-W-0029
status = VERIFIZIERT
hauptperson = Web, Willi 29
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4441
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1321.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=450.00, kdu_betrieb=60.00, kdu_heizung=70.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=580.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1031.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1031.00
bg_gesamtbedarf=1031.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1031.00
budget_rest_hypothetisch=290.00
budget_rest_erwartet=290.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0029]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0029, sb-web-02, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0029]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0029]
    erwartet = 1031.00 | ist = 1031
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0029]
    erwartet = 290.00 | ist = 290
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0029]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:01.923 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-29-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:05:02.886 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0029)  [Bild: tf-29-schritt-02.png] -> OK — Vorgang SWEET-W-0029 (Web, Willi 29) mit Startbudget 1321.00 EUR angelegt
2026-10-15 10:05:03.801 sb-web-02 | [S3] SozialFall erfassen (RBS 3, KdU 580.00 EUR)  [Bild: tf-29-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 580.00 EUR) gespeichert
2026-10-15 10:05:04.487 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-29-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:04.715 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-29-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:05:05.377 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-29-schritt-06.png] -> OK — Vorgang SWEET-W-0029 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:06.054 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-29-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 30 WEB-MEHRBEDARF SWEET-W-0030
status = VERIFIZIERT
hauptperson = Web, Willi 30
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 4594
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1455.95
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=true, kdu_miete=430.00, kdu_betrieb=85.00, kdu_heizung=105.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=12.95
p1_kdu=620.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1195.95
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1195.95
bg_gesamtbedarf=1195.95
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1195.95
budget_rest_hypothetisch=260.00
budget_rest_erwartet=260.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0030]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0030, sb-web-03, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0030]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0030]
    erwartet = 1195.95 | ist = 1195.95
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0030]
    erwartet = 260.00 | ist = 260
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0030]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:02.387 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-30-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:05:03.370 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0030)  [Bild: tf-30-schritt-02.png] -> OK — Vorgang SWEET-W-0030 (Web, Willi 30) mit Startbudget 1455.95 EUR angelegt
2026-10-15 10:05:04.372 sb-web-03 | [S3] SozialFall erfassen (RBS 1, KdU 620.00 EUR)  [Bild: tf-30-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 620.00 EUR) gespeichert
2026-10-15 10:05:05.055 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-30-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:05.290 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-30-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:05:05.975 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-30-schritt-06.png] -> OK — Vorgang SWEET-W-0030 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:06.654 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-30-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 31 WEB-STORNO SWEET-W-0031
status = VERIFIZIERT
hauptperson = Web, Willi 31
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 6684
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1091.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=260.00, kdu_betrieb=75.00, kdu_heizung=140.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=475.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=981.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=981.00
bg_gesamtbedarf=981.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=981.00
budget_rest_hypothetisch=110.00
budget_rest_erwartet=1091.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0031]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0031, sb-web-01, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0031]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0031]
    erwartet = 981.00 | ist = 981
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0031]
    erwartet = 1091.00 | ist = 1091
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0031]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:06.241 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-31-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:05:07.156 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0031)  [Bild: tf-31-schritt-02.png] -> OK — Vorgang SWEET-W-0031 (Web, Willi 31) mit Startbudget 1091.00 EUR angelegt
2026-10-15 10:05:08.094 sb-web-01 | [S3] SozialFall erfassen (RBS 2, KdU 475.00 EUR)  [Bild: tf-31-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 475.00 EUR) gespeichert
2026-10-15 10:05:08.952 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-31-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:09.196 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-31-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:05:09.942 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-31-schritt-06.png] -> OK — Vorgang SWEET-W-0031 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:10.624 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-31-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:05:12.109 sb-web-01 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-31-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 32 WEB-STANDARDRENTE SWEET-W-0032
status = VERIFIZIERT
hauptperson = Web, Willi 32
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 5852
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1538.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=530.00, kdu_betrieb=70.00, kdu_heizung=105.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=705.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1268.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1268.00
bg_gesamtbedarf=1268.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1268.00
budget_rest_hypothetisch=270.00
budget_rest_erwartet=270.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0032]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0032, sb-web-02, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0032]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0032]
    erwartet = 1268.00 | ist = 1268
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0032]
    erwartet = 270.00 | ist = 270
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0032]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:07.371 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-32-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:05:08.289 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0032)  [Bild: tf-32-schritt-02.png] -> OK — Vorgang SWEET-W-0032 (Web, Willi 32) mit Startbudget 1538.00 EUR angelegt
2026-10-15 10:05:09.376 sb-web-02 | [S3] SozialFall erfassen (RBS 1, KdU 705.00 EUR)  [Bild: tf-32-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 705.00 EUR) gespeichert
2026-10-15 10:05:10.058 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-32-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:10.360 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-32-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:05:11.041 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-32-schritt-06.png] -> OK — Vorgang SWEET-W-0032 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:11.906 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-32-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 33 WEB-STANDARDRENTE SWEET-W-0033
status = VERIFIZIERT
hauptperson = Web, Willi 33
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5417
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1061.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=250.00, kdu_betrieb=45.00, kdu_heizung=85.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=380.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=831.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=831.00
bg_gesamtbedarf=831.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=831.00
budget_rest_hypothetisch=230.00
budget_rest_erwartet=230.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0033]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0033, sb-web-03, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0033]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0033]
    erwartet = 831.00 | ist = 831
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0033]
    erwartet = 230.00 | ist = 230
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0033]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:06.961 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-33-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:05:07.921 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0033)  [Bild: tf-33-schritt-02.png] -> OK — Vorgang SWEET-W-0033 (Web, Willi 33) mit Startbudget 1061.00 EUR angelegt
2026-10-15 10:05:08.970 sb-web-03 | [S3] SozialFall erfassen (RBS 3, KdU 380.00 EUR)  [Bild: tf-33-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 380.00 EUR) gespeichert
2026-10-15 10:05:09.957 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-33-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:10.687 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-33-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:05:11.393 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-33-schritt-06.png] -> OK — Vorgang SWEET-W-0033 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:12.073 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-33-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 34 WEB-STORNO SWEET-W-0034
status = VERIFIZIERT
hauptperson = Web, Willi 34
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 8612
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1196.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=270.00, kdu_betrieb=95.00, kdu_heizung=120.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=485.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=936.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=936.00
bg_gesamtbedarf=936.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=936.00
budget_rest_hypothetisch=260.00
budget_rest_erwartet=1196.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0034]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0034, sb-web-02, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0034]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0034]
    erwartet = 936.00 | ist = 936
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0034]
    erwartet = 1196.00 | ist = 1196
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0034]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:12.727 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-34-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:05:13.681 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0034)  [Bild: tf-34-schritt-02.png] -> OK — Vorgang SWEET-W-0034 (Web, Willi 34) mit Startbudget 1196.00 EUR angelegt
2026-10-15 10:05:14.590 sb-web-02 | [S3] SozialFall erfassen (RBS 3, KdU 485.00 EUR)  [Bild: tf-34-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 485.00 EUR) gespeichert
2026-10-15 10:05:15.258 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-34-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:15.892 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-34-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:05:16.698 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-34-schritt-06.png] -> OK — Vorgang SWEET-W-0034 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:17.707 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-34-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:05:20.520 sb-web-02 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-34-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 35 WEB-MEHRBEDARF SWEET-W-0035
status = VERIFIZIERT
hauptperson = Web, Willi 35
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5640
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1302.64
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=true, kdu_miete=360.00, kdu_betrieb=35.00, kdu_heizung=130.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=11.64
p1_kdu=525.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1042.64
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1042.64
bg_gesamtbedarf=1042.64
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1042.64
budget_rest_hypothetisch=260.00
budget_rest_erwartet=260.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0035]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0035, sb-web-03, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0035]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0035]
    erwartet = 1042.64 | ist = 1042.64
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0035]
    erwartet = 260.00 | ist = 260
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0035]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:12.867 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-35-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:05:13.821 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0035)  [Bild: tf-35-schritt-02.png] -> OK — Vorgang SWEET-W-0035 (Web, Willi 35) mit Startbudget 1302.64 EUR angelegt
2026-10-15 10:05:14.795 sb-web-03 | [S3] SozialFall erfassen (RBS 2, KdU 525.00 EUR)  [Bild: tf-35-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 525.00 EUR) gespeichert
2026-10-15 10:05:15.731 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-35-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:16.009 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-35-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:05:16.698 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-35-schritt-06.png] -> OK — Vorgang SWEET-W-0035 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:17.707 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-35-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 36 WEB-STORNO SWEET-W-0036
status = VERIFIZIERT
hauptperson = Web, Willi 36
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 8411
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1186.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=410.00, kdu_betrieb=65.00, kdu_heizung=90.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=565.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1016.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1016.00
bg_gesamtbedarf=1016.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1016.00
budget_rest_hypothetisch=170.00
budget_rest_erwartet=1186.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0036]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0036, sb-web-01, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0036]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0036]
    erwartet = 1016.00 | ist = 1016
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0036]
    erwartet = 1186.00 | ist = 1186
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0036]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:12.924 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-36-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:05:13.870 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0036)  [Bild: tf-36-schritt-02.png] -> OK — Vorgang SWEET-W-0036 (Web, Willi 36) mit Startbudget 1186.00 EUR angelegt
2026-10-15 10:05:14.795 sb-web-01 | [S3] SozialFall erfassen (RBS 3, KdU 565.00 EUR)  [Bild: tf-36-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 565.00 EUR) gespeichert
2026-10-15 10:05:15.732 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-36-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:16.027 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-36-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:05:16.746 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-36-schritt-06.png] -> OK — Vorgang SWEET-W-0036 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:17.707 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-36-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:05:20.520 sb-web-01 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-36-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 37 WEB-MEHRBEDARF SWEET-W-0037
status = VERIFIZIERT
hauptperson = Web, Willi 37
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 6242
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1261.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=310.00, kdu_betrieb=100.00, kdu_heizung=100.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=510.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=961.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=961.00
bg_gesamtbedarf=961.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=961.00
budget_rest_hypothetisch=300.00
budget_rest_erwartet=300.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0037]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0037, sb-web-03, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0037]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0037]
    erwartet = 961.00 | ist = 961
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0037]
    erwartet = 300.00 | ist = 300
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0037]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:18.710 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-37-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:05:19.911 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0037)  [Bild: tf-37-schritt-02.png] -> OK — Vorgang SWEET-W-0037 (Web, Willi 37) mit Startbudget 1261.00 EUR angelegt
2026-10-15 10:05:20.790 sb-web-03 | [S3] SozialFall erfassen (RBS 3, KdU 510.00 EUR)  [Bild: tf-37-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 510.00 EUR) gespeichert
2026-10-15 10:05:21.771 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-37-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:22.074 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-37-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:05:22.951 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-37-schritt-06.png] -> OK — Vorgang SWEET-W-0037 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:23.957 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-37-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 38 WEB-STORNO SWEET-W-0038
status = VERIFIZIERT
hauptperson = Web, Willi 38
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 7886
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1186.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=430.00, kdu_betrieb=80.00, kdu_heizung=65.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=575.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1026.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1026.00
bg_gesamtbedarf=1026.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1026.00
budget_rest_hypothetisch=160.00
budget_rest_erwartet=1186.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0038]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0038, sb-web-01, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0038]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0038]
    erwartet = 1026.00 | ist = 1026
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0038]
    erwartet = 1186.00 | ist = 1186
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0038]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:21.317 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-38-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:05:22.638 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0038)  [Bild: tf-38-schritt-02.png] -> OK — Vorgang SWEET-W-0038 (Web, Willi 38) mit Startbudget 1186.00 EUR angelegt
2026-10-15 10:05:23.976 sb-web-01 | [S3] SozialFall erfassen (RBS 3, KdU 575.00 EUR)  [Bild: tf-38-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 575.00 EUR) gespeichert
2026-10-15 10:05:24.676 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-38-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:24.960 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-38-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:05:25.911 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-38-schritt-06.png] -> OK — Vorgang SWEET-W-0038 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:26.818 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-38-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:05:28.409 sb-web-01 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-38-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 39 WEB-STANDARDRENTE SWEET-W-0039
status = VERIFIZIERT
hauptperson = Web, Willi 39
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 6283
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1156.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=300.00, kdu_betrieb=95.00, kdu_heizung=125.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=520.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1026.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1026.00
bg_gesamtbedarf=1026.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1026.00
budget_rest_hypothetisch=130.00
budget_rest_erwartet=130.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0039]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0039, sb-web-02, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0039]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0039]
    erwartet = 1026.00 | ist = 1026
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0039]
    erwartet = 130.00 | ist = 130
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0039]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:21.805 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-39-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:05:22.935 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0039)  [Bild: tf-39-schritt-02.png] -> OK — Vorgang SWEET-W-0039 (Web, Willi 39) mit Startbudget 1156.00 EUR angelegt
2026-10-15 10:05:23.961 sb-web-02 | [S3] SozialFall erfassen (RBS 2, KdU 520.00 EUR)  [Bild: tf-39-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 520.00 EUR) gespeichert
2026-10-15 10:05:24.658 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-39-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:24.926 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-39-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:05:25.911 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-39-schritt-06.png] -> OK — Vorgang SWEET-W-0039 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:26.805 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-39-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 40 WEB-STANDARDRENTE SWEET-W-0040
status = VERIFIZIERT
hauptperson = Web, Willi 40
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5862
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1493.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=460.00, kdu_betrieb=95.00, kdu_heizung=95.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=650.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1213.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1213.00
bg_gesamtbedarf=1213.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1213.00
budget_rest_hypothetisch=280.00
budget_rest_erwartet=280.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0040]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0040, sb-web-03, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0040]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0040]
    erwartet = 1213.00 | ist = 1213
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0040]
    erwartet = 280.00 | ist = 280
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0040]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:24.739 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-40-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:05:25.902 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0040)  [Bild: tf-40-schritt-02.png] -> OK — Vorgang SWEET-W-0040 (Web, Willi 40) mit Startbudget 1493.00 EUR angelegt
2026-10-15 10:05:26.806 sb-web-03 | [S3] SozialFall erfassen (RBS 1, KdU 650.00 EUR)  [Bild: tf-40-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 650.00 EUR) gespeichert
2026-10-15 10:05:27.842 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-40-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:28.065 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-40-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:05:28.925 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-40-schritt-06.png] -> OK — Vorgang SWEET-W-0040 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:29.821 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-40-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 41 WEB-MEHRBEDARF SWEET-W-0041
status = VERIFIZIERT
hauptperson = Web, Willi 41
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 5686
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1077.02
p1_eingaben: rbs=2, merkzeichen_g=true, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=260.00, kdu_betrieb=55.00, kdu_heizung=50.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=86.02
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=365.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=957.02
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=957.02
bg_gesamtbedarf=957.02
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=957.02
budget_rest_hypothetisch=120.00
budget_rest_erwartet=120.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0041]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0041, sb-web-02, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0041]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0041]
    erwartet = 957.02 | ist = 957.02
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0041]
    erwartet = 120.00 | ist = 120
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0041]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:27.942 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-41-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:05:28.942 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0041)  [Bild: tf-41-schritt-02.png] -> OK — Vorgang SWEET-W-0041 (Web, Willi 41) mit Startbudget 1077.02 EUR angelegt
2026-10-15 10:05:29.869 sb-web-02 | [S3] SozialFall erfassen (RBS 2, KdU 365.00 EUR)  [Bild: tf-41-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 365.00 EUR) gespeichert
2026-10-15 10:05:30.874 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-41-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:31.122 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-41-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:05:31.808 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-41-schritt-06.png] -> OK — Vorgang SWEET-W-0041 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:32.493 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-41-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 42 WEB-MEHRBEDARF SWEET-W-0042
status = VERIFIZIERT
hauptperson = Web, Willi 42
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 5571
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1475.95
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=true, kdu_miete=540.00, kdu_betrieb=85.00, kdu_heizung=135.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=12.95
p1_kdu=760.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1335.95
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1335.95
bg_gesamtbedarf=1335.95
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1335.95
budget_rest_hypothetisch=140.00
budget_rest_erwartet=140.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0042]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0042, sb-web-01, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0042]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0042]
    erwartet = 1335.95 | ist = 1335.95
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0042]
    erwartet = 140.00 | ist = 140
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0042]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:29.087 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-42-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:05:30.339 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0042)  [Bild: tf-42-schritt-02.png] -> OK — Vorgang SWEET-W-0042 (Web, Willi 42) mit Startbudget 1475.95 EUR angelegt
2026-10-15 10:05:31.624 sb-web-01 | [S3] SozialFall erfassen (RBS 1, KdU 760.00 EUR)  [Bild: tf-42-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 760.00 EUR) gespeichert
2026-10-15 10:05:32.324 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-42-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:32.577 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-42-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:05:33.308 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-42-schritt-06.png] -> OK — Vorgang SWEET-W-0042 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:33.981 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-42-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 43 WEB-STORNO SWEET-W-0043
status = VERIFIZIERT
hauptperson = Web, Willi 43
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 6702
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1126.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=260.00, kdu_betrieb=50.00, kdu_heizung=125.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=435.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=886.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=886.00
bg_gesamtbedarf=886.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=886.00
budget_rest_hypothetisch=240.00
budget_rest_erwartet=1126.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0043]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0043, sb-web-03, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0043]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0043]
    erwartet = 886.00 | ist = 886
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0043]
    erwartet = 1126.00 | ist = 1126
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0043]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:30.123 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-43-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:05:31.426 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0043)  [Bild: tf-43-schritt-02.png] -> OK — Vorgang SWEET-W-0043 (Web, Willi 43) mit Startbudget 1126.00 EUR angelegt
2026-10-15 10:05:32.325 sb-web-03 | [S3] SozialFall erfassen (RBS 3, KdU 435.00 EUR)  [Bild: tf-43-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 435.00 EUR) gespeichert
2026-10-15 10:05:33.024 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-43-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:33.251 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-43-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:05:33.949 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-43-schritt-06.png] -> OK — Vorgang SWEET-W-0043 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:34.619 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-43-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:05:36.525 sb-web-03 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-43-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 44 WEB-STANDARDRENTE SWEET-W-0044
status = VERIFIZIERT
hauptperson = Web, Willi 44
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 5409
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1161.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=460.00, kdu_betrieb=70.00, kdu_heizung=70.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=600.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1051.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1051.00
bg_gesamtbedarf=1051.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1051.00
budget_rest_hypothetisch=110.00
budget_rest_erwartet=110.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0044]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0044, sb-web-02, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0044]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0044]
    erwartet = 1051.00 | ist = 1051
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0044]
    erwartet = 110.00 | ist = 110
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0044]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:33.305 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-44-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:05:34.470 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0044)  [Bild: tf-44-schritt-02.png] -> OK — Vorgang SWEET-W-0044 (Web, Willi 44) mit Startbudget 1161.00 EUR angelegt
2026-10-15 10:05:35.435 sb-web-02 | [S3] SozialFall erfassen (RBS 3, KdU 600.00 EUR)  [Bild: tf-44-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 600.00 EUR) gespeichert
2026-10-15 10:05:36.042 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-44-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:36.273 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-44-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:05:36.961 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-44-schritt-06.png] -> OK — Vorgang SWEET-W-0044 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:37.903 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-44-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 45 WEB-STANDARDRENTE SWEET-W-0045
status = VERIFIZIERT
hauptperson = Web, Willi 45
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 5993
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1426.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=500.00, kdu_betrieb=90.00, kdu_heizung=110.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=700.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1206.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1206.00
bg_gesamtbedarf=1206.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1206.00
budget_rest_hypothetisch=220.00
budget_rest_erwartet=220.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0045]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0045, sb-web-01, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0045]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0045]
    erwartet = 1206.00 | ist = 1206
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0045]
    erwartet = 220.00 | ist = 220
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0045]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:34.241 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-45-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:05:35.208 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0045)  [Bild: tf-45-schritt-02.png] -> OK — Vorgang SWEET-W-0045 (Web, Willi 45) mit Startbudget 1426.00 EUR angelegt
2026-10-15 10:05:36.087 sb-web-01 | [S3] SozialFall erfassen (RBS 2, KdU 700.00 EUR)  [Bild: tf-45-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 700.00 EUR) gespeichert
2026-10-15 10:05:36.788 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-45-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:37.848 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-45-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:05:38.919 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-45-schritt-06.png] -> OK — Vorgang SWEET-W-0045 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:39.977 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-45-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 46 WEB-STORNO SWEET-W-0046
status = VERIFIZIERT
hauptperson = Web, Willi 46
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 6628
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1281.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=430.00, kdu_betrieb=30.00, kdu_heizung=110.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=570.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1021.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1021.00
bg_gesamtbedarf=1021.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1021.00
budget_rest_hypothetisch=260.00
budget_rest_erwartet=1281.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0046]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0046, sb-web-03, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0046]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0046]
    erwartet = 1021.00 | ist = 1021
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0046]
    erwartet = 1281.00 | ist = 1281
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0046]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:36.840 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-46-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:05:37.887 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0046)  [Bild: tf-46-schritt-02.png] -> OK — Vorgang SWEET-W-0046 (Web, Willi 46) mit Startbudget 1281.00 EUR angelegt
2026-10-15 10:05:38.950 sb-web-03 | [S3] SozialFall erfassen (RBS 3, KdU 570.00 EUR)  [Bild: tf-46-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 570.00 EUR) gespeichert
2026-10-15 10:05:39.977 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-46-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:40.224 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-46-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:05:40.921 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-46-schritt-06.png] -> OK — Vorgang SWEET-W-0046 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:41.606 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-46-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:05:43.155 sb-web-03 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-46-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 47 WEB-MEHRBEDARF SWEET-W-0047
status = VERIFIZIERT
hauptperson = Web, Willi 47
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4417
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1361.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=390.00, kdu_betrieb=95.00, kdu_heizung=110.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=595.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1101.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1101.00
bg_gesamtbedarf=1101.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1101.00
budget_rest_hypothetisch=260.00
budget_rest_erwartet=260.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0047]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0047, sb-web-02, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0047]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0047]
    erwartet = 1101.00 | ist = 1101
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0047]
    erwartet = 260.00 | ist = 260
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0047]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:38.224 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-47-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:05:39.113 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0047)  [Bild: tf-47-schritt-02.png] -> OK — Vorgang SWEET-W-0047 (Web, Willi 47) mit Startbudget 1361.00 EUR angelegt
2026-10-15 10:05:39.978 sb-web-02 | [S3] SozialFall erfassen (RBS 2, KdU 595.00 EUR)  [Bild: tf-47-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 595.00 EUR) gespeichert
2026-10-15 10:05:40.660 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-47-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:40.921 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-47-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:05:41.642 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-47-schritt-06.png] -> OK — Vorgang SWEET-W-0047 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:42.321 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-47-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 48 WEB-MEHRBEDARF SWEET-W-0048
status = VERIFIZIERT
hauptperson = Web, Willi 48
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 5206
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1365.95
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=true, kdu_miete=330.00, kdu_betrieb=30.00, kdu_heizung=140.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=12.95
p1_kdu=500.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1075.95
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1075.95
bg_gesamtbedarf=1075.95
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1075.95
budget_rest_hypothetisch=290.00
budget_rest_erwartet=290.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0048]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0048, sb-web-01, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0048]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0048]
    erwartet = 1075.95 | ist = 1075.95
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0048]
    erwartet = 290.00 | ist = 290
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0048]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:40.773 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-48-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:05:41.785 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0048)  [Bild: tf-48-schritt-02.png] -> OK — Vorgang SWEET-W-0048 (Web, Willi 48) mit Startbudget 1365.95 EUR angelegt
2026-10-15 10:05:42.728 sb-web-01 | [S3] SozialFall erfassen (RBS 1, KdU 500.00 EUR)  [Bild: tf-48-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 500.00 EUR) gespeichert
2026-10-15 10:05:43.441 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-48-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:43.741 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-48-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:05:44.492 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-48-schritt-06.png] -> OK — Vorgang SWEET-W-0048 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:45.184 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-48-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 49 WEB-MEHRBEDARF SWEET-W-0049
status = VERIFIZIERT
hauptperson = Web, Willi 49
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4651
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1331.66
p1_eingaben: rbs=1, merkzeichen_g=true, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=true, kdu_miete=250.00, kdu_betrieb=40.00, kdu_heizung=90.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=95.71
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=12.95
p1_kdu=380.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1051.66
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1051.66
bg_gesamtbedarf=1051.66
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1051.66
budget_rest_hypothetisch=280.00
budget_rest_erwartet=280.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0049]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0049, sb-web-02, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0049]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0049]
    erwartet = 1051.66 | ist = 1051.66
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0049]
    erwartet = 280.00 | ist = 280
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0049]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:42.597 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-49-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:05:43.544 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0049)  [Bild: tf-49-schritt-02.png] -> OK — Vorgang SWEET-W-0049 (Web, Willi 49) mit Startbudget 1331.66 EUR angelegt
2026-10-15 10:05:44.576 sb-web-02 | [S3] SozialFall erfassen (RBS 1, KdU 380.00 EUR)  [Bild: tf-49-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 380.00 EUR) gespeichert
2026-10-15 10:05:45.268 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-49-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:45.549 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-49-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:05:46.293 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-49-schritt-06.png] -> OK — Vorgang SWEET-W-0049 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:46.974 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-49-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 50 WEB-STORNO SWEET-W-0050
status = VERIFIZIERT
hauptperson = Web, Willi 50
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 6168
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1196.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=410.00, kdu_betrieb=40.00, kdu_heizung=135.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=585.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1036.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1036.00
bg_gesamtbedarf=1036.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1036.00
budget_rest_hypothetisch=160.00
budget_rest_erwartet=1196.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0050]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0050, sb-web-03, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0050]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0050]
    erwartet = 1036.00 | ist = 1036
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0050]
    erwartet = 1196.00 | ist = 1196
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0050]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:43.528 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-50-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:05:44.574 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0050)  [Bild: tf-50-schritt-02.png] -> OK — Vorgang SWEET-W-0050 (Web, Willi 50) mit Startbudget 1196.00 EUR angelegt
2026-10-15 10:05:45.491 sb-web-03 | [S3] SozialFall erfassen (RBS 3, KdU 585.00 EUR)  [Bild: tf-50-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 585.00 EUR) gespeichert
2026-10-15 10:05:46.176 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-50-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:46.421 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-50-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:05:47.143 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-50-schritt-06.png] -> OK — Vorgang SWEET-W-0050 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:47.810 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-50-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:05:49.323 sb-web-03 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-50-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 51 WEB-MEHRBEDARF SWEET-W-0051
status = VERIFIZIERT
hauptperson = Web, Willi 51
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 4971
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1016.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=true, kdu_miete=270.00, kdu_betrieb=30.00, kdu_heizung=75.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=375.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=826.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=826.00
bg_gesamtbedarf=826.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=826.00
budget_rest_hypothetisch=190.00
budget_rest_erwartet=190.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0051]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0051, sb-web-01, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0051]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0051]
    erwartet = 826.00 | ist = 826
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0051]
    erwartet = 190.00 | ist = 190
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0051]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:45.491 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-51-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:05:46.442 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0051)  [Bild: tf-51-schritt-02.png] -> OK — Vorgang SWEET-W-0051 (Web, Willi 51) mit Startbudget 1016.00 EUR angelegt
2026-10-15 10:05:47.361 sb-web-01 | [S3] SozialFall erfassen (RBS 3, KdU 375.00 EUR)  [Bild: tf-51-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 375.00 EUR) gespeichert
2026-10-15 10:05:48.053 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-51-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:48.788 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-51-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:05:49.477 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-51-schritt-06.png] -> OK — Vorgang SWEET-W-0051 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:50.156 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-51-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 52 WEB-STORNO SWEET-W-0052
status = VERIFIZIERT
hauptperson = Web, Willi 52
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 6529
ids = kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1428.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=410.00, kdu_betrieb=50.00, kdu_heizung=105.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=565.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1128.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1128.00
bg_gesamtbedarf=1128.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1128.00
budget_rest_hypothetisch=300.00
budget_rest_erwartet=1428.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0052]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0052, sb-web-02, sb-web-03]
    erwartet = 1 | ist = 1
V3: OK | Zahlung nach Storno über die Oberfläche (STORNIERT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0052]
    erwartet = STORNIERT | ist = STORNIERT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0052]
    erwartet = 1128.00 | ist = 1128
V5: OK | Restbudget nach Storno vollständig zurückgebucht
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0052]
    erwartet = 1428.00 | ist = 1428
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0052]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:47.240 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-52-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:05:48.177 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0052)  [Bild: tf-52-schritt-02.png] -> OK — Vorgang SWEET-W-0052 (Web, Willi 52) mit Startbudget 1428.00 EUR angelegt
2026-10-15 10:05:49.025 sb-web-02 | [S3] SozialFall erfassen (RBS 1, KdU 565.00 EUR)  [Bild: tf-52-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 565.00 EUR) gespeichert
2026-10-15 10:05:49.710 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-52-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:50.440 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-52-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:05:51.150 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-52-schritt-06.png] -> OK — Vorgang SWEET-W-0052 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:51.958 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-52-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:05:53.505 sb-web-02 | [S8] Als Administration wechseln und Storno buchen  [Bild: tf-52-schritt-08.png] -> OK — Als web-admin (Admin-Rolle) Storno gebucht (Status STORNIERT, Restbudget zurückgebucht)

## TF 53 WEB-MEHRBEDARF SWEET-W-0053
status = VERIFIZIERT
hauptperson = Web, Willi 53
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5250
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1392.02
p1_eingaben: rbs=2, merkzeichen_g=true, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=420.00, kdu_betrieb=35.00, kdu_heizung=95.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=86.02
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=550.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1142.02
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1142.02
bg_gesamtbedarf=1142.02
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1142.02
budget_rest_hypothetisch=250.00
budget_rest_erwartet=250.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0053]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0053, sb-web-03, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0053]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0053]
    erwartet = 1142.02 | ist = 1142.02
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0053]
    erwartet = 250.00 | ist = 250
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2, SWEET-W-0053]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:49.594 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-53-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:05:50.542 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0053)  [Bild: tf-53-schritt-02.png] -> OK — Vorgang SWEET-W-0053 (Web, Willi 53) mit Startbudget 1392.02 EUR angelegt
2026-10-15 10:05:51.944 sb-web-03 | [S3] SozialFall erfassen (RBS 2, KdU 550.00 EUR)  [Bild: tf-53-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 550.00 EUR) gespeichert
2026-10-15 10:05:52.941 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-53-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:53.190 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-53-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:05:53.891 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-53-schritt-06.png] -> OK — Vorgang SWEET-W-0053 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:54.574 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-53-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 54 WEB-STANDARDRENTE SWEET-W-0054
status = VERIFIZIERT
hauptperson = Web, Willi 54
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 5131
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1448.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=530.00, kdu_betrieb=105.00, kdu_heizung=140.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=775.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1338.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1338.00
bg_gesamtbedarf=1338.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1338.00
budget_rest_hypothetisch=110.00
budget_rest_erwartet=110.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0054]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0054, sb-web-01, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0054]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0054]
    erwartet = 1338.00 | ist = 1338
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0054]
    erwartet = 110.00 | ist = 110
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [1, SWEET-W-0054]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:50.440 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-54-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:05:51.376 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0054)  [Bild: tf-54-schritt-02.png] -> OK — Vorgang SWEET-W-0054 (Web, Willi 54) mit Startbudget 1448.00 EUR angelegt
2026-10-15 10:05:52.942 sb-web-01 | [S3] SozialFall erfassen (RBS 1, KdU 775.00 EUR)  [Bild: tf-54-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 775.00 EUR) gespeichert
2026-10-15 10:05:53.654 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-54-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:53.892 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-54-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:05:54.605 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-54-schritt-06.png] -> OK — Vorgang SWEET-W-0054 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:55.289 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-54-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 55 WEB-STANDARDRENTE SWEET-W-0055
status = VERIFIZIERT
hauptperson = Web, Willi 55
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 5691
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1171.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=330.00, kdu_betrieb=30.00, kdu_heizung=100.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=460.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=911.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=911.00
bg_gesamtbedarf=911.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=911.00
budget_rest_hypothetisch=260.00
budget_rest_erwartet=260.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0055]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0055, sb-web-02, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0055]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0055]
    erwartet = 911.00 | ist = 911
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0055]
    erwartet = 260.00 | ist = 260
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0055]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:54.305 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-55-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:05:55.227 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0055)  [Bild: tf-55-schritt-02.png] -> OK — Vorgang SWEET-W-0055 (Web, Willi 55) mit Startbudget 1171.00 EUR angelegt
2026-10-15 10:05:56.920 sb-web-02 | [S3] SozialFall erfassen (RBS 3, KdU 460.00 EUR)  [Bild: tf-55-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 460.00 EUR) gespeichert
2026-10-15 10:05:57.607 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-55-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:57.852 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-55-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:05:58.545 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-55-schritt-06.png] -> OK — Vorgang SWEET-W-0055 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:59.198 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-55-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 56 WEB-MEHRBEDARF SWEET-W-0056
status = VERIFIZIERT
hauptperson = Web, Willi 56
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 4731
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1062.67
p1_eingaben: rbs=3, merkzeichen_g=true, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=true, kdu_miete=300.00, kdu_betrieb=50.00, kdu_heizung=85.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=76.67
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=435.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=962.67
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=962.67
bg_gesamtbedarf=962.67
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=962.67
budget_rest_hypothetisch=100.00
budget_rest_erwartet=100.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0056]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0056, sb-web-03, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0056]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0056]
    erwartet = 962.67 | ist = 962.67
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0056]
    erwartet = 100.00 | ist = 100
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0056]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:54.890 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-56-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:05:55.960 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0056)  [Bild: tf-56-schritt-02.png] -> OK — Vorgang SWEET-W-0056 (Web, Willi 56) mit Startbudget 1062.67 EUR angelegt
2026-10-15 10:05:56.975 sb-web-03 | [S3] SozialFall erfassen (RBS 3, KdU 435.00 EUR)  [Bild: tf-56-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 435.00 EUR) gespeichert
2026-10-15 10:05:57.658 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-56-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:57.932 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-56-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:05:58.638 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-56-schritt-06.png] -> OK — Vorgang SWEET-W-0056 über Suchfeld ermittelt und geöffnet
2026-10-15 10:05:59.316 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-56-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 57 WEB-MEHRBEDARF SWEET-W-0057
status = VERIFIZIERT
hauptperson = Web, Willi 57
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 5719
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1371.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=500.00, kdu_betrieb=80.00, kdu_heizung=130.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=710.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1161.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1161.00
bg_gesamtbedarf=1161.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1161.00
budget_rest_hypothetisch=210.00
budget_rest_erwartet=210.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0057]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0057, sb-web-01, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0057]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0057]
    erwartet = 1161.00 | ist = 1161
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0057]
    erwartet = 210.00 | ist = 210
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0057]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:56.036 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-57-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:05:57.177 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0057)  [Bild: tf-57-schritt-02.png] -> OK — Vorgang SWEET-W-0057 (Web, Willi 57) mit Startbudget 1371.00 EUR angelegt
2026-10-15 10:05:58.042 sb-web-01 | [S3] SozialFall erfassen (RBS 3, KdU 710.00 EUR)  [Bild: tf-57-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 710.00 EUR) gespeichert
2026-10-15 10:05:58.733 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-57-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:05:59.492 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-57-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:06:00.211 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-57-schritt-06.png] -> OK — Vorgang SWEET-W-0057 über Suchfeld ermittelt und geöffnet
2026-10-15 10:06:01.008 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-57-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 58 WEB-STANDARDRENTE SWEET-W-0058
status = VERIFIZIERT
hauptperson = Web, Willi 58
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 5507
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-02, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1061.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=360.00, kdu_betrieb=35.00, kdu_heizung=65.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=460.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=911.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=911.00
bg_gesamtbedarf=911.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=911.00
budget_rest_hypothetisch=150.00
budget_rest_erwartet=150.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0058]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0058, sb-web-02, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0058]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0058]
    erwartet = 911.00 | ist = 911
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0058]
    erwartet = 150.00 | ist = 150
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0058]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:59.524 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-58-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:06:00.937 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0058)  [Bild: tf-58-schritt-02.png] -> OK — Vorgang SWEET-W-0058 (Web, Willi 58) mit Startbudget 1061.00 EUR angelegt
2026-10-15 10:06:02.074 sb-web-02 | [S3] SozialFall erfassen (RBS 3, KdU 460.00 EUR)  [Bild: tf-58-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 460.00 EUR) gespeichert
2026-10-15 10:06:03.008 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-58-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:06:03.277 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-58-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:06:04.021 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-58-schritt-06.png] -> OK — Vorgang SWEET-W-0058 über Suchfeld ermittelt und geöffnet
2026-10-15 10:06:04.708 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-58-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 59 WEB-MEHRBEDARF SWEET-W-0059
status = VERIFIZIERT
hauptperson = Web, Willi 59
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5391
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1122.67
p1_eingaben: rbs=3, merkzeichen_g=true, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=300.00, kdu_betrieb=120.00, kdu_heizung=75.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=76.67
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=495.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1022.67
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1022.67
bg_gesamtbedarf=1022.67
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1022.67
budget_rest_hypothetisch=100.00
budget_rest_erwartet=100.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0059]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0059, sb-web-03, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0059]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0059]
    erwartet = 1022.67 | ist = 1022.67
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0059]
    erwartet = 100.00 | ist = 100
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0059]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:05:59.631 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-59-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:06:00.954 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0059)  [Bild: tf-59-schritt-02.png] -> OK — Vorgang SWEET-W-0059 (Web, Willi 59) mit Startbudget 1122.67 EUR angelegt
2026-10-15 10:06:02.057 sb-web-03 | [S3] SozialFall erfassen (RBS 3, KdU 495.00 EUR)  [Bild: tf-59-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 495.00 EUR) gespeichert
2026-10-15 10:06:03.006 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-59-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:06:03.277 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-59-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:06:04.021 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-59-schritt-06.png] -> OK — Vorgang SWEET-W-0059 über Suchfeld ermittelt und geöffnet
2026-10-15 10:06:04.708 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-59-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)

## TF 60 WEB-STANDARDRENTE SWEET-W-0060
status = VERIFIZIERT
hauptperson = Web, Willi 60
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 5281
ids = kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true, mitarbeiter=sb-web-01, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1281.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=450.00, kdu_betrieb=45.00, kdu_heizung=95.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=590.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1041.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1041.00
bg_gesamtbedarf=1041.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1041.00
budget_rest_hypothetisch=240.00
budget_rest_erwartet=240.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0060]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0060, sb-web-01, sb-web-02]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0060]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0060]
    erwartet = 1041.00 | ist = 1041
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0060]
    erwartet = 240.00 | ist = 240
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0060]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:02.149 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-60-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:06:03.093 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0060)  [Bild: tf-60-schritt-02.png] -> OK — Vorgang SWEET-W-0060 (Web, Willi 60) mit Startbudget 1281.00 EUR angelegt
2026-10-15 10:06:04.004 sb-web-01 | [S3] SozialFall erfassen (RBS 3, KdU 590.00 EUR)  [Bild: tf-60-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 590.00 EUR) gespeichert
2026-10-15 10:06:04.708 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-60-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:06:04.940 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-60-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:06:05.625 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-60-schritt-06.png] -> OK — Vorgang SWEET-W-0060 über Suchfeld ermittelt und geöffnet
2026-10-15 10:06:06.291 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-60-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)


## ki_pruefung_dateiuebergabe

dateiuebergabe_geprueft = false
fachpruefung_bestanden = false
Noch keine KI-Prüfung: Dateiübergabe und Fachprüfung sind ausstehend.

