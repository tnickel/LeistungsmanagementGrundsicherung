# Prüfmenge: vollständige ausgewählte Fälle

Auswahl: 3 Fälle; keine Kürzung innerhalb eines Falls.

# Vollständiger Laufkopf POSITIV / run-20261015-100353-13234168534251085179
Quelle: testsweet/logs/run-20261015-100353-13234168534251085179/testdokumentation.md

# testsweet Lauf

gesamtergebnis = UNVERIFIED
lauf_erfolgreich = false
automatik_bestanden = true
ki_fachstatus = UNVERIFIED
gesamtfehler = KI-Prüfung ist ausstehend.
globale_pruefung = Pruefung[beschreibung=Global: Anzahl SWEET-Vorgänge, erwartet=60, ist=60, ok=true, hinweis=null, sql=null, parameter=[]]
globale_pruefung = Pruefung[beschreibung=Global: keine Übergabe ohne Freigabevermerk, erwartet=0, ist=0, ok=true, hinweis=null, sql=null, parameter=[]]
produkt = SDN.Leistung LMG
modus = 2-web (Weboberfläche/Selenium)
kategorie = POSITIV
start = 2026-10-15T10:03:53.520434700
ende = 2026-10-15T10:06:06.598713500
dauer_s = 133
db = jdbc:oracle:thin:@//localhost:1521/FREEPDB1
db_user = REVIEW_20261015
mitarbeiter = 3
auftraege = 60
seed = 20261015
denkzeit_ms = 0
ergebnis.verifiziert = 60
ergebnis.verifikation_nio = 0
ergebnis.fehlgeschlagen = 0
ergebnis.gesamt = 60
hinweis: Soll-Beträge werden mit der Produktionsberechnung (Leistungsberechnung) ermittelt und jeder erzeugte Rechenblock vor dem Laufurteil unabhängig nachgerechnet (dokumentierter Rechenstand 2026). Zusätzliche Goldwerte-Absicherung: GoldWerteTest im Hauptprojekt (Werte aus doc/regressionstests.md).

## pruefanleitung_fur_ki

Diese Datei ist das maschinenlesbare Protokoll eines testsweet-Laufs der Fachanwendung SDN.Leistung (Grundsicherung im Alter/bei Erwerbsminderung, SGB XII). Bitte unabhängig überprüfen:

1. BETRÄGE NACHRECHNEN (Positivfälle): Je Testfall stehen unter '### rechenwege' die Eingaben je Person (p1_eingaben, p2_eingaben, ...) und JEDE Zwischengröße (regelbedarf, mehrbedarfe, kdu, anrechenbar, bg_zahlbetrag, budget_rest_hypothetisch). Das hypothetische Restbudget beschreibt nur Startbudget minus Anspruch, keine tatsächliche Buchung. Ein explizites budget_rest_erwartet bzw. die SQL-Erwartung beschreibt den Buchungsendzustand; bei Abweisung bleibt das Budget unverändert, Storno gibt den Betrag zurück. Rechne mit den Formeln aus '## rechengrundlagen_2026' jeden Zwischenwert und den Zahlbetrag selbst nach und melde jede Abweichung.
2. ERWARTET/GEGEN IST HALTEN: Unter '### verifikation' steht je Prüfung V1..Vn das prüfende SQL mit konkreten Parametern sowie 'erwartet' und 'ist'. Prüfe, ob die erwarteten Werte fachlich aus den Eingaben folgen und ob ist = erwartet ist (NIO-Zeilen sind Fehler).
3. NEGATIVFÄLLE PLAUSIBILISIEREN: Schritte mit 'ERWARTETER FEHLER (CODE)' müssen fachlich zwingend abgewehrt werden (z. B. KEIN_ANSPRUCH wenn Einkommen/Vermögen den Bedarf übersteigt, VALIDATION bei Doppelanordnung je Monat oder Zahlungsmonat außerhalb des Bewilligungszeitraums, BERECHTIGUNG bei Selbstfreigabe, KONKURRENZ bei veraltetem Maskenstand, BUDGET_ERSCHOEPFT bei zu kleinem Startbudget). Prüfe, dass der Datenbank-Endzustand unverändert geblieben ist (keine Zahlung, Budget unangetastet).
4. GRENZEN: Last-/Stresstests erzeugen nur Aggregate (kein Einzelfall-Nachrechnen); Web-Läufe (modus 2-web) nutzen dieselbe Datenstruktur, dokumentieren aber UI-Schritte. Globale Prüfungen stehen im Kopf als globale_pruefung-Zeilen.
Das verbindliche Antwortschema steht im übergeordneten Prüfauftrag. Dieser Datenanhang legt kein abweichendes Antwortformat fest.

## rechengrundlagen_2026

rbs_eur = {1: 563.00, 2: 506.00, 3: 451.00, 4: 471.00, 5: 390.00, 6: 357.00}  (Anlage zu § 28 SGB XII)
mehrbedarf_g = 0.17 * regelbedarf  (§ 30 Abs. 1)
mehrbedarf_schwanger = 0.17 * regelbedarf  (§ 30 Abs. 2, ab 13. SSW; entfaellt automatisch, wenn entbindungsmonat gesetzt und zahlungsmonat > entbindungsmonat)
mehrbedarf_alleinerziehend = 0.36 * rbs1 bei kind_u7>=1 oder 2<=kinder_u16<=3, sonst 0.12 * rbs1 je minderjaehrigem kind; deckel 0.60 * rbs1 = 337.80  (§ 30 Abs. 3)
mehrbedarf_obergrenze = summe(abs1..5) <= regelbedarf  (§ 30 Abs. 6)
mehrbedarf_warmwasser_anteil = {1: 0.023, 2: 0.023, 3: 0.0, 4: 0.014, 5: 0.012, 6: 0.008}  (§ 30 Abs. 7, zusaetzlich zu Abs. 6)
kdu = kaltmiete + betriebskosten + heizung - zentraler warmwasserabzug; gekappt auf verbleibende BG-Grenze, sofern > 0. Parameter stehen je Block.
erwerbsfreibetrag = min(0.30 * erwerb_brutto, 0.50 * rbs1 = 281.50)  (§ 82 Abs. 3)
anrechenbar = rente + erwerb - freibetrag - absetzbetaetrag >= 0  (absetzbetraege: steuern, sv, versicherungen, erwerbsaufwendungen; § 82 Abs. 2)
schonvermoegen = 10000.00 je volljaehriger person (rbs 1-3) + 500.00 je weiterer person; Produktvertrag ohne Erwachsene: Grundbetrag einmal 10000.00. Referenz des implementierten Vertrags, keine eigenständige Rechtsverifikation.
zahlbetrag = gesamtbedarf - anrechenbares_einkommen - max(vermoegen - schonvermoegen, 0)  (<= 0 => KEIN_ANSPRUCH, § 43 Abs. 1)
rundung = HALF_UP auf 2 nachkommastellen; waehrung EUR
zahlstatus = ANGELEGT (wartet auf freigabe) -> BEREIT -> UEBERGEBEN; STORNIERT gibt monat frei
sepa_iban = ISO 13616: laenderspezifische Gesamtlaenge (Deutschland genau 22 Zeichen); Pruefziffer-Validierung: die verschobene Ziffernfolge (BBAN, dann Laendercode-Verdraengung 1314, dann Pruefziffer) ergibt Modulo 97 genau 1. Abweichung von Laenge oder Pruefziffer => VALIDATION 'Ungueltige IBAN'.
sepa_bic = ISO 9362: genau 8 oder 11 Zeichen (4 Buchstaben Bankcode, 2 Buchstaben Laendercode, 2 alphanumerische Ortskennung, optional 3 alphanumerische Zweigstelle). Andere Laenge/Struktur => VALIDATION 'Ungueltiger BIC'.


# Vollständiger Laufkopf NEGATIV / run-20261015-100608-12296938910290168033
Quelle: testsweet/logs/run-20261015-100608-12296938910290168033/testdokumentation.md

# testsweet Lauf

gesamtergebnis = UNVERIFIED
lauf_erfolgreich = false
automatik_bestanden = true
ki_fachstatus = UNVERIFIED
gesamtfehler = KI-Prüfung ist ausstehend.
globale_pruefung = Pruefung[beschreibung=Global: Anzahl SWEET-Vorgänge, erwartet=49, ist=49, ok=true, hinweis=null, sql=null, parameter=[]]
globale_pruefung = Pruefung[beschreibung=Global: keine Übergabe ohne Freigabevermerk, erwartet=0, ist=0, ok=true, hinweis=null, sql=null, parameter=[]]
produkt = SDN.Leistung LMG
modus = 2-web (Weboberfläche/Selenium)
kategorie = NEGATIV
start = 2026-10-15T10:06:08.343774200
ende = 2026-10-15T10:07:39.794754300
dauer_s = 91
db = jdbc:oracle:thin:@//localhost:1521/FREEPDB1
db_user = REVIEW_20261015
mitarbeiter = 3
auftraege = 60
seed = 20261015
denkzeit_ms = 0
ergebnis.verifiziert = 60
ergebnis.verifikation_nio = 0
ergebnis.fehlgeschlagen = 0
ergebnis.gesamt = 60
hinweis: Soll-Beträge werden mit der Produktionsberechnung (Leistungsberechnung) ermittelt und jeder erzeugte Rechenblock vor dem Laufurteil unabhängig nachgerechnet (dokumentierter Rechenstand 2026). Zusätzliche Goldwerte-Absicherung: GoldWerteTest im Hauptprojekt (Werte aus doc/regressionstests.md).

## pruefanleitung_fur_ki

Diese Datei ist das maschinenlesbare Protokoll eines testsweet-Laufs der Fachanwendung SDN.Leistung (Grundsicherung im Alter/bei Erwerbsminderung, SGB XII). Bitte unabhängig überprüfen:

1. BETRÄGE NACHRECHNEN (Positivfälle): Je Testfall stehen unter '### rechenwege' die Eingaben je Person (p1_eingaben, p2_eingaben, ...) und JEDE Zwischengröße (regelbedarf, mehrbedarfe, kdu, anrechenbar, bg_zahlbetrag, budget_rest_hypothetisch). Das hypothetische Restbudget beschreibt nur Startbudget minus Anspruch, keine tatsächliche Buchung. Ein explizites budget_rest_erwartet bzw. die SQL-Erwartung beschreibt den Buchungsendzustand; bei Abweisung bleibt das Budget unverändert, Storno gibt den Betrag zurück. Rechne mit den Formeln aus '## rechengrundlagen_2026' jeden Zwischenwert und den Zahlbetrag selbst nach und melde jede Abweichung.
2. ERWARTET/GEGEN IST HALTEN: Unter '### verifikation' steht je Prüfung V1..Vn das prüfende SQL mit konkreten Parametern sowie 'erwartet' und 'ist'. Prüfe, ob die erwarteten Werte fachlich aus den Eingaben folgen und ob ist = erwartet ist (NIO-Zeilen sind Fehler).
3. NEGATIVFÄLLE PLAUSIBILISIEREN: Schritte mit 'ERWARTETER FEHLER (CODE)' müssen fachlich zwingend abgewehrt werden (z. B. KEIN_ANSPRUCH wenn Einkommen/Vermögen den Bedarf übersteigt, VALIDATION bei Doppelanordnung je Monat oder Zahlungsmonat außerhalb des Bewilligungszeitraums, BERECHTIGUNG bei Selbstfreigabe, KONKURRENZ bei veraltetem Maskenstand, BUDGET_ERSCHOEPFT bei zu kleinem Startbudget). Prüfe, dass der Datenbank-Endzustand unverändert geblieben ist (keine Zahlung, Budget unangetastet).
4. GRENZEN: Last-/Stresstests erzeugen nur Aggregate (kein Einzelfall-Nachrechnen); Web-Läufe (modus 2-web) nutzen dieselbe Datenstruktur, dokumentieren aber UI-Schritte. Globale Prüfungen stehen im Kopf als globale_pruefung-Zeilen.
Das verbindliche Antwortschema steht im übergeordneten Prüfauftrag. Dieser Datenanhang legt kein abweichendes Antwortformat fest.

## rechengrundlagen_2026

rbs_eur = {1: 563.00, 2: 506.00, 3: 451.00, 4: 471.00, 5: 390.00, 6: 357.00}  (Anlage zu § 28 SGB XII)
mehrbedarf_g = 0.17 * regelbedarf  (§ 30 Abs. 1)
mehrbedarf_schwanger = 0.17 * regelbedarf  (§ 30 Abs. 2, ab 13. SSW; entfaellt automatisch, wenn entbindungsmonat gesetzt und zahlungsmonat > entbindungsmonat)
mehrbedarf_alleinerziehend = 0.36 * rbs1 bei kind_u7>=1 oder 2<=kinder_u16<=3, sonst 0.12 * rbs1 je minderjaehrigem kind; deckel 0.60 * rbs1 = 337.80  (§ 30 Abs. 3)
mehrbedarf_obergrenze = summe(abs1..5) <= regelbedarf  (§ 30 Abs. 6)
mehrbedarf_warmwasser_anteil = {1: 0.023, 2: 0.023, 3: 0.0, 4: 0.014, 5: 0.012, 6: 0.008}  (§ 30 Abs. 7, zusaetzlich zu Abs. 6)
kdu = kaltmiete + betriebskosten + heizung - zentraler warmwasserabzug; gekappt auf verbleibende BG-Grenze, sofern > 0. Parameter stehen je Block.
erwerbsfreibetrag = min(0.30 * erwerb_brutto, 0.50 * rbs1 = 281.50)  (§ 82 Abs. 3)
anrechenbar = rente + erwerb - freibetrag - absetzbetaetrag >= 0  (absetzbetraege: steuern, sv, versicherungen, erwerbsaufwendungen; § 82 Abs. 2)
schonvermoegen = 10000.00 je volljaehriger person (rbs 1-3) + 500.00 je weiterer person; Produktvertrag ohne Erwachsene: Grundbetrag einmal 10000.00. Referenz des implementierten Vertrags, keine eigenständige Rechtsverifikation.
zahlbetrag = gesamtbedarf - anrechenbares_einkommen - max(vermoegen - schonvermoegen, 0)  (<= 0 => KEIN_ANSPRUCH, § 43 Abs. 1)
rundung = HALF_UP auf 2 nachkommastellen; waehrung EUR
zahlstatus = ANGELEGT (wartet auf freigabe) -> BEREIT -> UEBERGEBEN; STORNIERT gibt monat frei
sepa_iban = ISO 13616: laenderspezifische Gesamtlaenge (Deutschland genau 22 Zeichen); Pruefziffer-Validierung: die verschobene Ziffernfolge (BBAN, dann Laendercode-Verdraengung 1314, dann Pruefziffer) ergibt Modulo 97 genau 1. Abweichung von Laenge oder Pruefziffer => VALIDATION 'Ungueltige IBAN'.
sepa_bic = ISO 9362: genau 8 oder 11 Zeichen (4 Buchstaben Bankcode, 2 Buchstaben Laendercode, 2 alphanumerische Ortskennung, optional 3 alphanumerische Zweigstelle). Andere Laenge/Struktur => VALIDATION 'Ungueltiger BIC'.


# Fall-ID: NEGATIV:run-20261015-100608-12296938910290168033:TF02
geforderte_pruefpunkte = V1, V2, V3, V4, V5, S1, S2, S3, S4

## TF 02 WEB-NEG-BUDGET SWEET-NW-0002
status = VERIFIZIERT
hauptperson = Web, Negativ 2
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5479
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

block: Bedarf (Budget bewusst zu klein)
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 941.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=370.00, kdu_betrieb=95.00, kdu_heizung=105.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=570.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1021.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1021.00
bg_gesamtbedarf=1021.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1021.00
budget_rest_hypothetisch=-80.00
budget_rest_erwartet=941.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 9ef5203910387f3d, Nachher-Prüfsumme 9ef5203910387f3d (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0002]
    erwartet = 0 | ist = 0
V3: OK | Budget unverändert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0002]
    erwartet = 941.00 | ist = 941
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:23.593 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-02-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:06:24.762 sb-web-03 | [S2] Neuen Vorgang mit Startbudget 941.00 EUR anlegen (bewusst zu klein)  [Bild: tf-02-schritt-02.png] -> OK — Vorgang SWEET-NW-0002 (Web, Negativ 2) mit Startbudget 941.00 EUR angelegt
2026-10-15 10:06:25.984 sb-web-03 | [S3] SozialFall erfassen (Bedarf 1021.00 EUR)  [Bild: tf-02-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 570.00 EUR) gespeichert
2026-10-15 10:06:28.243 sb-web-03 | [S4] Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet  [Bild: tf-02-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Der Zahlbetrag 1.021,00 EUR übersteigt das verfügbare Restbudget von 941,00 EUR


# Fall-ID: POSITIV:run-20261015-100353-13234168534251085179:TF03
geforderte_pruefpunkte = V1, V2, V3, V4, V5, V6, V7, V8, S1, S2, S3, S4, S5, S6, S7

## TF 03 WEB-STANDARDRENTE SWEET-W-0003
status = VERIFIZIERT
hauptperson = Web, Willi 3
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5044
ids = kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true, mitarbeiter=sb-web-03, adminKonto=web-admin

### rechenwege

block: Anordnung über die Weboberfläche
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1186.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=390.00, kdu_betrieb=55.00, kdu_heizung=90.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=535.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=986.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=986.00
bg_gesamtbedarf=986.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=986.00
budget_rest_hypothetisch=200.00
budget_rest_erwartet=200.00

### verifikation

V1: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-W-0003]
    erwartet = 1 | ist = 1
V2: OK | Erfasser und legitimer Freigebender bleiben exakt zugeordnet
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID=(SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN=?) AND SACHBEARBEITER_ID=? AND FREIGEGEBEN_VON=?
    params = [SWEET-W-0003, sb-web-03, sb-web-01]
    erwartet = 1 | ist = 1
V3: OK | Zahlung über die Oberfläche freigegeben (BEREIT)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0003]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Auszahlungsbetrag entspricht der Berechnung
    sql    = SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-W-0003]
    erwartet = 986.00 | ist = 986
V5: OK | Restbudget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-W-0003]
    erwartet = 200.00 | ist = 200
V6: OK | SozialFall mit Stufe persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE REGELBEDARFSSTUFE = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [3, SWEET-W-0003]
    erwartet = 1 | ist = 1
V7: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V8: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:04:08.414 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-03-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:04:09.376 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-W-0003)  [Bild: tf-03-schritt-02.png] -> OK — Vorgang SWEET-W-0003 (Web, Willi 3) mit Startbudget 1186.00 EUR angelegt
2026-10-15 10:04:10.344 sb-web-03 | [S3] SozialFall erfassen (RBS 3, KdU 535.00 EUR)  [Bild: tf-03-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 535.00 EUR) gespeichert
2026-10-15 10:04:11.272 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-03-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:04:11.641 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-03-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:04:12.365 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-03-schritt-06.png] -> OK — Vorgang SWEET-W-0003 über Suchfeld ermittelt und geöffnet
2026-10-15 10:04:13.073 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-03-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)


# Fall-ID: NEGATIV:run-20261015-100608-12296938910290168033:TF03
geforderte_pruefpunkte = V1, V2, V3, V4, V5, S1, S2, S3, S4

## TF 03 WEB-NEG-BUDGET SWEET-NW-0003
status = VERIFIZIERT
hauptperson = Web, Negativ 3
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 5357
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

block: Bedarf (Budget bewusst zu klein)
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 976.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=460.00, kdu_betrieb=40.00, kdu_heizung=65.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=565.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1016.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1016.00
bg_gesamtbedarf=1016.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1016.00
budget_rest_hypothetisch=-40.00
budget_rest_erwartet=976.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 84d32dd7fe0d3bef, Nachher-Prüfsumme 84d32dd7fe0d3bef (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0003]
    erwartet = 0 | ist = 0
V3: OK | Budget unverändert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0003]
    erwartet = 976.00 | ist = 976
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:23.678 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-03-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:06:24.762 sb-web-02 | [S2] Neuen Vorgang mit Startbudget 976.00 EUR anlegen (bewusst zu klein)  [Bild: tf-03-schritt-02.png] -> OK — Vorgang SWEET-NW-0003 (Web, Negativ 3) mit Startbudget 976.00 EUR angelegt
2026-10-15 10:06:25.984 sb-web-02 | [S3] SozialFall erfassen (Bedarf 1016.00 EUR)  [Bild: tf-03-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 565.00 EUR) gespeichert
2026-10-15 10:06:28.242 sb-web-02 | [S4] Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet  [Bild: tf-03-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Der Zahlbetrag 1.016,00 EUR übersteigt das verfügbare Restbudget von 976,00 EUR

