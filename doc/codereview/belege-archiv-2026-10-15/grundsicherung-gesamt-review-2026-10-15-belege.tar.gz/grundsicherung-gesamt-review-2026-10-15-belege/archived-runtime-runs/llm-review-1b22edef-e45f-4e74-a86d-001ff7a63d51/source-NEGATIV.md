# testsweet Lauf

gesamtergebnis = UNVERIFIED
lauf_erfolgreich = false
automatik_bestanden = true
ki_fachstatus = UNVERIFIED
gesamtfehler = KI-Prüfung ist ausstehend.
globale_pruefung = Pruefung[beschreibung=Global: Anzahl SWEET-Vorgänge, erwartet=49, ist=49, ok=true, hinweis=null, sql=null, parameter=[]]
globale_pruefung = Pruefung[beschreibung=Global: keine Übergabe ohne Freigabevermerk, erwartet=0, ist=0, ok=true, hinweis=null, sql=null, parameter=[]]
produkt = SDN.Leistung LMG
modus = 2-web (Weboberfläche/Selenium)
kategorie = NEGATIV
start = 2026-10-15T10:06:08.343774200
ende = 2026-10-15T10:07:39.794754300
dauer_s = 91
db = jdbc:oracle:thin:@//localhost:1521/FREEPDB1
db_user = REVIEW_20261015
mitarbeiter = 3
auftraege = 60
seed = 20261015
denkzeit_ms = 0
ergebnis.verifiziert = 60
ergebnis.verifikation_nio = 0
ergebnis.fehlgeschlagen = 0
ergebnis.gesamt = 60
hinweis: Soll-Beträge werden mit der Produktionsberechnung (Leistungsberechnung) ermittelt und jeder erzeugte Rechenblock vor dem Laufurteil unabhängig nachgerechnet (dokumentierter Rechenstand 2026). Zusätzliche Goldwerte-Absicherung: GoldWerteTest im Hauptprojekt (Werte aus doc/regressionstests.md).

## pruefanleitung_fur_ki

Diese Datei ist das maschinenlesbare Protokoll eines testsweet-Laufs der Fachanwendung SDN.Leistung (Grundsicherung im Alter/bei Erwerbsminderung, SGB XII). Bitte unabhängig überprüfen:

1. BETRÄGE NACHRECHNEN (Positivfälle): Je Testfall stehen unter '### rechenwege' die Eingaben je Person (p1_eingaben, p2_eingaben, ...) und JEDE Zwischengröße (regelbedarf, mehrbedarfe, kdu, anrechenbar, bg_zahlbetrag, budget_rest_hypothetisch). Das hypothetische Restbudget beschreibt nur Startbudget minus Anspruch, keine tatsächliche Buchung. Ein explizites budget_rest_erwartet bzw. die SQL-Erwartung beschreibt den Buchungsendzustand; bei Abweisung bleibt das Budget unverändert, Storno gibt den Betrag zurück. Rechne mit den Formeln aus '## rechengrundlagen_2026' jeden Zwischenwert und den Zahlbetrag selbst nach und melde jede Abweichung.
2. ERWARTET/GEGEN IST HALTEN: Unter '### verifikation' steht je Prüfung V1..Vn das prüfende SQL mit konkreten Parametern sowie 'erwartet' und 'ist'. Prüfe, ob die erwarteten Werte fachlich aus den Eingaben folgen und ob ist = erwartet ist (NIO-Zeilen sind Fehler).
3. NEGATIVFÄLLE PLAUSIBILISIEREN: Schritte mit 'ERWARTETER FEHLER (CODE)' müssen fachlich zwingend abgewehrt werden (z. B. KEIN_ANSPRUCH wenn Einkommen/Vermögen den Bedarf übersteigt, VALIDATION bei Doppelanordnung je Monat oder Zahlungsmonat außerhalb des Bewilligungszeitraums, BERECHTIGUNG bei Selbstfreigabe, KONKURRENZ bei veraltetem Maskenstand, BUDGET_ERSCHOEPFT bei zu kleinem Startbudget). Prüfe, dass der Datenbank-Endzustand unverändert geblieben ist (keine Zahlung, Budget unangetastet).
4. GRENZEN: Last-/Stresstests erzeugen nur Aggregate (kein Einzelfall-Nachrechnen); Web-Läufe (modus 2-web) nutzen dieselbe Datenstruktur, dokumentieren aber UI-Schritte. Globale Prüfungen stehen im Kopf als globale_pruefung-Zeilen.
Das verbindliche Antwortschema steht im übergeordneten Prüfauftrag. Dieser Datenanhang legt kein abweichendes Antwortformat fest.

## rechengrundlagen_2026

rbs_eur = {1: 563.00, 2: 506.00, 3: 451.00, 4: 471.00, 5: 390.00, 6: 357.00}  (Anlage zu § 28 SGB XII)
mehrbedarf_g = 0.17 * regelbedarf  (§ 30 Abs. 1)
mehrbedarf_schwanger = 0.17 * regelbedarf  (§ 30 Abs. 2, ab 13. SSW; entfaellt automatisch, wenn entbindungsmonat gesetzt und zahlungsmonat > entbindungsmonat)
mehrbedarf_alleinerziehend = 0.36 * rbs1 bei kind_u7>=1 oder 2<=kinder_u16<=3, sonst 0.12 * rbs1 je minderjaehrigem kind; deckel 0.60 * rbs1 = 337.80  (§ 30 Abs. 3)
mehrbedarf_obergrenze = summe(abs1..5) <= regelbedarf  (§ 30 Abs. 6)
mehrbedarf_warmwasser_anteil = {1: 0.023, 2: 0.023, 3: 0.0, 4: 0.014, 5: 0.012, 6: 0.008}  (§ 30 Abs. 7, zusaetzlich zu Abs. 6)
kdu = kaltmiete + betriebskosten + heizung - zentraler warmwasserabzug; gekappt auf verbleibende BG-Grenze, sofern > 0. Parameter stehen je Block.
erwerbsfreibetrag = min(0.30 * erwerb_brutto, 0.50 * rbs1 = 281.50)  (§ 82 Abs. 3)
anrechenbar = rente + erwerb - freibetrag - absetzbetaetrag >= 0  (absetzbetraege: steuern, sv, versicherungen, erwerbsaufwendungen; § 82 Abs. 2)
schonvermoegen = 10000.00 je volljaehriger person (rbs 1-3) + 500.00 je weiterer person; Produktvertrag ohne Erwachsene: Grundbetrag einmal 10000.00. Referenz des implementierten Vertrags, keine eigenständige Rechtsverifikation.
zahlbetrag = gesamtbedarf - anrechenbares_einkommen - max(vermoegen - schonvermoegen, 0)  (<= 0 => KEIN_ANSPRUCH, § 43 Abs. 1)
rundung = HALF_UP auf 2 nachkommastellen; waehrung EUR
zahlstatus = ANGELEGT (wartet auf freigabe) -> BEREIT -> UEBERGEBEN; STORNIERT gibt monat frei
sepa_iban = ISO 13616: laenderspezifische Gesamtlaenge (Deutschland genau 22 Zeichen); Pruefziffer-Validierung: die verschobene Ziffernfolge (BBAN, dann Laendercode-Verdraengung 1314, dann Pruefziffer) ergibt Modulo 97 genau 1. Abweichung von Laenge oder Pruefziffer => VALIDATION 'Ungueltige IBAN'.
sepa_bic = ISO 9362: genau 8 oder 11 Zeichen (4 Buchstaben Bankcode, 2 Buchstaben Laendercode, 2 alphanumerische Ortskennung, optional 3 alphanumerische Zweigstelle). Andere Laenge/Struktur => VALIDATION 'Ungueltiger BIC'.

## TF 01 WEB-NEG-BANKVERBINDUNG SWEET-NW-0001
status = VERIFIZIERT
hauptperson = —
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 3586
ids = adminKonto=web-admin, kollege=sb-web-02, sitzungKennung=sb-web-01, mitarbeiter=sb-web-01

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Vorgang mit IBAN mit falscher Prüfziffer anlegen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | UI-Fehlversuch ohne Fachänderung: Vorgang mit zu kurzem BIC (7 Zeichen) anlegen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V3: OK | kein Vorgang mit dem Aktenzeichen angelegt
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0001]
    erwartet = 0 | ist = 0
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:23.562 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-01-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:06:24.755 sb-web-01 | [S2] Vorgang mit IBAN mit falscher Prüfziffer anlegen  [Bild: tf-01-schritt-02.png] -> OK — Neuanlage abgewehrt — Fehlerdialog: Ungültige IBAN
2026-10-15 10:06:26.078 sb-web-01 | [S3] Vorgang mit zu kurzem BIC (7 Zeichen) anlegen  [Bild: tf-01-schritt-03.png] -> OK — Neuanlage abgewehrt — Fehlerdialog: Ungültiger BIC

## TF 02 WEB-NEG-BUDGET SWEET-NW-0002
status = VERIFIZIERT
hauptperson = Web, Negativ 2
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5479
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

block: Bedarf (Budget bewusst zu klein)
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 941.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=370.00, kdu_betrieb=95.00, kdu_heizung=105.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=570.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1021.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1021.00
bg_gesamtbedarf=1021.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1021.00
budget_rest_hypothetisch=-80.00
budget_rest_erwartet=941.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 9ef5203910387f3d, Nachher-Prüfsumme 9ef5203910387f3d (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0002]
    erwartet = 0 | ist = 0
V3: OK | Budget unverändert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0002]
    erwartet = 941.00 | ist = 941
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:23.593 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-02-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:06:24.762 sb-web-03 | [S2] Neuen Vorgang mit Startbudget 941.00 EUR anlegen (bewusst zu klein)  [Bild: tf-02-schritt-02.png] -> OK — Vorgang SWEET-NW-0002 (Web, Negativ 2) mit Startbudget 941.00 EUR angelegt
2026-10-15 10:06:25.984 sb-web-03 | [S3] SozialFall erfassen (Bedarf 1021.00 EUR)  [Bild: tf-02-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 570.00 EUR) gespeichert
2026-10-15 10:06:28.243 sb-web-03 | [S4] Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet  [Bild: tf-02-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Der Zahlbetrag 1.021,00 EUR übersteigt das verfügbare Restbudget von 941,00 EUR

## TF 03 WEB-NEG-BUDGET SWEET-NW-0003
status = VERIFIZIERT
hauptperson = Web, Negativ 3
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 5357
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

block: Bedarf (Budget bewusst zu klein)
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 976.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=460.00, kdu_betrieb=40.00, kdu_heizung=65.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=565.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1016.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1016.00
bg_gesamtbedarf=1016.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1016.00
budget_rest_hypothetisch=-40.00
budget_rest_erwartet=976.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 84d32dd7fe0d3bef, Nachher-Prüfsumme 84d32dd7fe0d3bef (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0003]
    erwartet = 0 | ist = 0
V3: OK | Budget unverändert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0003]
    erwartet = 976.00 | ist = 976
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:23.678 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-03-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:06:24.762 sb-web-02 | [S2] Neuen Vorgang mit Startbudget 976.00 EUR anlegen (bewusst zu klein)  [Bild: tf-03-schritt-02.png] -> OK — Vorgang SWEET-NW-0003 (Web, Negativ 3) mit Startbudget 976.00 EUR angelegt
2026-10-15 10:06:25.984 sb-web-02 | [S3] SozialFall erfassen (Bedarf 1016.00 EUR)  [Bild: tf-03-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 565.00 EUR) gespeichert
2026-10-15 10:06:28.242 sb-web-02 | [S4] Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet  [Bild: tf-03-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Der Zahlbetrag 1.016,00 EUR übersteigt das verfügbare Restbudget von 976,00 EUR

## TF 04 WEB-NEG-STORNO-SB SWEET-NW-0004
status = VERIFIZIERT
hauptperson = Web, Negativ 4
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 6062
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

block: Anordnung + Freigabe
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1146.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=350.00, kdu_betrieb=35.00, kdu_heizung=85.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=470.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=976.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=976.00
bg_gesamtbedarf=976.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=976.00
budget_rest_hypothetisch=170.00
budget_rest_erwartet=170.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 4af43d91ca604517, Nachher-Prüfsumme 4af43d91ca604517 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0004]
    erwartet = 1 | ist = 1
V3: OK | Zahlung bleibt freigegeben (kein Storno durch SB)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-NW-0004]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Budget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0004]
    erwartet = 170.00 | ist = 170
V5: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V6: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:27.124 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-04-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:06:28.233 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0004)  [Bild: tf-04-schritt-02.png] -> OK — Vorgang SWEET-NW-0004 (Web, Negativ 4) mit Startbudget 1146.00 EUR angelegt
2026-10-15 10:06:29.234 sb-web-01 | [S3] SozialFall erfassen  [Bild: tf-04-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 470.00 EUR) gespeichert
2026-10-15 10:06:29.960 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-04-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:06:30.708 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-04-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:06:31.371 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-04-schritt-06.png] -> OK — Vorgang SWEET-NW-0004 über Suchfeld ermittelt und geöffnet
2026-10-15 10:06:32.058 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-04-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:06:32.142 sb-web-01 | [S8] Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten  [Bild: tf-04-schritt-08.png] -> OK — Storno-Knopf für Sachbearbeiter korrekt ausgeblendet (nur Admin-Rolle)

## TF 05 WEB-NEG-DOPPELMONAT SWEET-NW-0005
status = VERIFIZIERT
hauptperson = Web, Negativ 5
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4035
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

block: Erste Anordnung
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1166.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=300.00, kdu_betrieb=45.00, kdu_heizung=65.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=410.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=916.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=916.00
bg_gesamtbedarf=916.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=916.00
budget_rest_hypothetisch=250.00
budget_rest_erwartet=250.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme c25e1d7a8b2d23f9, Nachher-Prüfsumme c25e1d7a8b2d23f9 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | genau eine Zahlung je Vorgang und Monat
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0005]
    erwartet = 1 | ist = 1
V3: OK | Budget nur einmal gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0005]
    erwartet = 250.00 | ist = 250
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:29.077 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-05-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:06:30.053 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0005)  [Bild: tf-05-schritt-02.png] -> OK — Vorgang SWEET-NW-0005 (Web, Negativ 5) mit Startbudget 1166.00 EUR angelegt
2026-10-15 10:06:30.956 sb-web-02 | [S3] SozialFall erfassen  [Bild: tf-05-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 410.00 EUR) gespeichert
2026-10-15 10:06:31.625 sb-web-02 | [S4] Erste Auszahlung für 2026-10 anordnen  [Bild: tf-05-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:06:32.270 sb-web-02 | [S5] ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet  [Bild: tf-05-schritt-05.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Für 2026-10 existiert bereits eine nicht stornierte Zahlung dieser Bedarfsgemeinschaft; ggf. zuerst stornieren

## TF 06 WEB-NEG-KEINANSPRUCH SWEET-NW-0006
status = VERIFIZIERT
hauptperson = Web, Negativ 6
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5312
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — KEIN_ANSPRUCH erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme de0d085dd72f6577, Nachher-Prüfsumme de0d085dd72f6577 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden (KEIN_ANSPRUCH abgewehrt)
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0006]
    erwartet = 0 | ist = 0
V3: OK | SozialFall mit Rente persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?) AND EINKOMMEN_RENTE = ?
    params = [SWEET-NW-0006, 5000.00]
    erwartet = 1 | ist = 1
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:29.059 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-06-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:06:30.427 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0006)  [Bild: tf-06-schritt-02.png] -> OK — Vorgang SWEET-NW-0006 (Web, Negativ 6) mit Startbudget 1200 EUR angelegt
2026-10-15 10:06:31.339 sb-web-03 | [S3] SozialFall mit hoher Rente erfassen  [Bild: tf-06-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 420 EUR, Rente 5000.00 EUR) gespeichert
2026-10-15 10:06:33.556 sb-web-03 | [S4] Auszahlung anordnen — KEIN_ANSPRUCH erwartet  [Bild: tf-06-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Einkommen/Vermögen übersteigen den Gesamtbedarf — kein Anspruch (Zahlbetrag -4.017,00 EUR)

## TF 07 WEB-NEG-BUDGET SWEET-NW-0007
status = VERIFIZIERT
hauptperson = Web, Negativ 7
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 4943
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

block: Bedarf (Budget bewusst zu klein)
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 993.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=300.00, kdu_betrieb=80.00, kdu_heizung=80.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=460.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1023.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1023.00
bg_gesamtbedarf=1023.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1023.00
budget_rest_hypothetisch=-30.00
budget_rest_erwartet=993.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 1213243b120163fe, Nachher-Prüfsumme 1213243b120163fe (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0007]
    erwartet = 0 | ist = 0
V3: OK | Budget unverändert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0007]
    erwartet = 993.00 | ist = 993
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:32.990 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-07-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:06:33.959 sb-web-01 | [S2] Neuen Vorgang mit Startbudget 993.00 EUR anlegen (bewusst zu klein)  [Bild: tf-07-schritt-02.png] -> OK — Vorgang SWEET-NW-0007 (Web, Negativ 7) mit Startbudget 993.00 EUR angelegt
2026-10-15 10:06:34.879 sb-web-01 | [S3] SozialFall erfassen (Bedarf 1023.00 EUR)  [Bild: tf-07-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 460.00 EUR) gespeichert
2026-10-15 10:06:37.086 sb-web-01 | [S4] Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet  [Bild: tf-07-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Der Zahlbetrag 1.023,00 EUR übersteigt das verfügbare Restbudget von 993,00 EUR

## TF 08 WEB-NEG-LOGIN SWEET-NW-0008
status = VERIFIZIERT
hauptperson = —
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 311
ids = kollege=sb-web-01, adminKonto=web-admin, mitarbeiter=sb-web-02

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Anmeldung mit FALSCHEM Passwort versuchen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | kein Vorgang durch die abgewehrte Anmeldung entstanden
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0008]
    erwartet = 0 | ist = 0
V3: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:32.588 sb-web-02 | [S1] Anmeldung mit FALSCHEM Passwort versuchen  [Bild: tf-08-schritt-01.png] -> OK — Anmeldung abgewehrt — Oberfläche meldet: Kennung oder Passwort ist falsch

## TF 09 WEB-NEG-OHNE-MONAT SWEET-NW-0009
status = VERIFIZIERT
hauptperson = Web, Negativ 9
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4268
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung OHNE Zahlungsmonat anordnen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 3e57db9974e6b5fa, Nachher-Prüfsumme 3e57db9974e6b5fa (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Vorgang angelegt
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0009]
    erwartet = 1 | ist = 1
V3: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0009]
    erwartet = 0 | ist = 0
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:33.305 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-09-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:06:34.275 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0009)  [Bild: tf-09-schritt-02.png] -> OK — Vorgang SWEET-NW-0009 (Web, Negativ 9) mit Startbudget 1200 EUR angelegt
2026-10-15 10:06:35.162 sb-web-02 | [S3] SozialFall erfassen (RBS 1)  [Bild: tf-09-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 540 EUR) gespeichert
2026-10-15 10:06:36.858 sb-web-02 | [S4] Auszahlung OHNE Zahlungsmonat anordnen  [Bild: tf-09-schritt-04.png] -> OK — Anordnung ohne Zahlungsmonat abgewehrt — Fehlerdialog: Bitte den Zahlungsmonat wählen.

## TF 10 WEB-NEG-DOPPELMONAT SWEET-NW-0010
status = VERIFIZIERT
hauptperson = Web, Negativ 10
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 3673
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-02, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

block: Erste Anordnung
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1358.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=340.00, kdu_betrieb=75.00, kdu_heizung=100.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=515.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1078.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1078.00
bg_gesamtbedarf=1078.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1078.00
budget_rest_hypothetisch=280.00
budget_rest_erwartet=280.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme a07b84d1f98e285c, Nachher-Prüfsumme a07b84d1f98e285c (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | genau eine Zahlung je Vorgang und Monat
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0010]
    erwartet = 1 | ist = 1
V3: OK | Budget nur einmal gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0010]
    erwartet = 280.00 | ist = 280
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:33.942 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-10-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:06:34.944 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0010)  [Bild: tf-10-schritt-02.png] -> OK — Vorgang SWEET-NW-0010 (Web, Negativ 10) mit Startbudget 1358.00 EUR angelegt
2026-10-15 10:06:35.878 sb-web-03 | [S3] SozialFall erfassen  [Bild: tf-10-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 515.00 EUR) gespeichert
2026-10-15 10:06:36.559 sb-web-03 | [S4] Erste Auszahlung für 2026-10 anordnen  [Bild: tf-10-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:06:37.231 sb-web-03 | [S5] ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet  [Bild: tf-10-schritt-05.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Für 2026-10 existiert bereits eine nicht stornierte Zahlung dieser Bedarfsgemeinschaft; ggf. zuerst stornieren

## TF 11 WEB-NEG-BUDGET SWEET-NW-0011
status = VERIFIZIERT
hauptperson = Web, Negativ 11
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4232
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

block: Bedarf (Budget bewusst zu klein)
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1123.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=420.00, kdu_betrieb=85.00, kdu_heizung=85.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=590.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1153.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1153.00
bg_gesamtbedarf=1153.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1153.00
budget_rest_hypothetisch=-30.00
budget_rest_erwartet=1123.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme f94909b2623cef79, Nachher-Prüfsumme f94909b2623cef79 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0011]
    erwartet = 0 | ist = 0
V3: OK | Budget unverändert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0011]
    erwartet = 1123.00 | ist = 1123
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:37.117 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-11-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:06:38.026 sb-web-02 | [S2] Neuen Vorgang mit Startbudget 1123.00 EUR anlegen (bewusst zu klein)  [Bild: tf-11-schritt-02.png] -> OK — Vorgang SWEET-NW-0011 (Web, Negativ 11) mit Startbudget 1123.00 EUR angelegt
2026-10-15 10:06:38.858 sb-web-02 | [S3] SozialFall erfassen (Bedarf 1153.00 EUR)  [Bild: tf-11-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 590.00 EUR) gespeichert
2026-10-15 10:06:41.092 sb-web-02 | [S4] Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet  [Bild: tf-11-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Der Zahlbetrag 1.153,00 EUR übersteigt das verfügbare Restbudget von 1.123,00 EUR

## TF 12 WEB-NEG-BUDGET SWEET-NW-0012
status = VERIFIZIERT
hauptperson = Web, Negativ 12
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 5440
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-02, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

block: Bedarf (Budget bewusst zu klein)
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1166.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=490.00, kdu_betrieb=110.00, kdu_heizung=100.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=700.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1206.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1206.00
bg_gesamtbedarf=1206.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1206.00
budget_rest_hypothetisch=-40.00
budget_rest_erwartet=1166.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme d62a24bc17fb9ce8, Nachher-Prüfsumme d62a24bc17fb9ce8 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0012]
    erwartet = 0 | ist = 0
V3: OK | Budget unverändert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0012]
    erwartet = 1166.00 | ist = 1166
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:38.391 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-12-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:06:39.361 sb-web-01 | [S2] Neuen Vorgang mit Startbudget 1166.00 EUR anlegen (bewusst zu klein)  [Bild: tf-12-schritt-02.png] -> OK — Vorgang SWEET-NW-0012 (Web, Negativ 12) mit Startbudget 1166.00 EUR angelegt
2026-10-15 10:06:40.311 sb-web-01 | [S3] SozialFall erfassen (Bedarf 1206.00 EUR)  [Bild: tf-12-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 700.00 EUR) gespeichert
2026-10-15 10:06:42.526 sb-web-01 | [S4] Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet  [Bild: tf-12-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Der Zahlbetrag 1.206,00 EUR übersteigt das verfügbare Restbudget von 1.166,00 EUR

## TF 13 WEB-NEG-BUDGET SWEET-NW-0013
status = VERIFIZIERT
hauptperson = Web, Negativ 13
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5447
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

block: Bedarf (Budget bewusst zu klein)
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 983.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=310.00, kdu_betrieb=105.00, kdu_heizung=65.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=480.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1043.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1043.00
bg_gesamtbedarf=1043.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1043.00
budget_rest_hypothetisch=-60.00
budget_rest_erwartet=983.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 0a8f635ae50a29e0, Nachher-Prüfsumme 0a8f635ae50a29e0 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0013]
    erwartet = 0 | ist = 0
V3: OK | Budget unverändert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0013]
    erwartet = 983.00 | ist = 983
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:38.542 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-13-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:06:39.562 sb-web-03 | [S2] Neuen Vorgang mit Startbudget 983.00 EUR anlegen (bewusst zu klein)  [Bild: tf-13-schritt-02.png] -> OK — Vorgang SWEET-NW-0013 (Web, Negativ 13) mit Startbudget 983.00 EUR angelegt
2026-10-15 10:06:40.476 sb-web-03 | [S3] SozialFall erfassen (Bedarf 1043.00 EUR)  [Bild: tf-13-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 480.00 EUR) gespeichert
2026-10-15 10:06:42.679 sb-web-03 | [S4] Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet  [Bild: tf-13-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Der Zahlbetrag 1.043,00 EUR übersteigt das verfügbare Restbudget von 983,00 EUR

## TF 14 WEB-NEG-OHNE-MONAT SWEET-NW-0014
status = VERIFIZIERT
hauptperson = Web, Negativ 14
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4320
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung OHNE Zahlungsmonat anordnen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 34af96b49dfa74d2, Nachher-Prüfsumme 34af96b49dfa74d2 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Vorgang angelegt
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0014]
    erwartet = 1 | ist = 1
V3: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0014]
    erwartet = 0 | ist = 0
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:41.857 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-14-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:06:42.727 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0014)  [Bild: tf-14-schritt-02.png] -> OK — Vorgang SWEET-NW-0014 (Web, Negativ 14) mit Startbudget 1200 EUR angelegt
2026-10-15 10:06:43.729 sb-web-02 | [S3] SozialFall erfassen (RBS 3)  [Bild: tf-14-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 540 EUR) gespeichert
2026-10-15 10:06:45.414 sb-web-02 | [S4] Auszahlung OHNE Zahlungsmonat anordnen  [Bild: tf-14-schritt-04.png] -> OK — Anordnung ohne Zahlungsmonat abgewehrt — Fehlerdialog: Bitte den Zahlungsmonat wählen.

## TF 15 WEB-NEG-DOPPELMONAT SWEET-NW-0015
status = VERIFIZIERT
hauptperson = Web, Negativ 15
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 4190
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

block: Erste Anordnung
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1248.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=390.00, kdu_betrieb=65.00, kdu_heizung=110.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=565.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1128.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1128.00
bg_gesamtbedarf=1128.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1128.00
budget_rest_hypothetisch=120.00
budget_rest_erwartet=120.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme d0aa07374cf5db08, Nachher-Prüfsumme d0aa07374cf5db08 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | genau eine Zahlung je Vorgang und Monat
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0015]
    erwartet = 1 | ist = 1
V3: OK | Budget nur einmal gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0015]
    erwartet = 120.00 | ist = 120
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:43.010 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-15-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:06:44.295 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0015)  [Bild: tf-15-schritt-02.png] -> OK — Vorgang SWEET-NW-0015 (Web, Negativ 15) mit Startbudget 1248.00 EUR angelegt
2026-10-15 10:06:45.361 sb-web-01 | [S3] SozialFall erfassen  [Bild: tf-15-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 565.00 EUR) gespeichert
2026-10-15 10:06:46.044 sb-web-01 | [S4] Erste Auszahlung für 2026-10 anordnen  [Bild: tf-15-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:06:46.718 sb-web-01 | [S5] ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet  [Bild: tf-15-schritt-05.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Für 2026-10 existiert bereits eine nicht stornierte Zahlung dieser Bedarfsgemeinschaft; ggf. zuerst stornieren

## TF 16 WEB-NEG-STORNO-SB SWEET-NW-0016
status = VERIFIZIERT
hauptperson = Web, Negativ 16
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 5126
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

block: Anordnung + Freigabe
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1373.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=320.00, kdu_betrieb=80.00, kdu_heizung=110.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=510.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1073.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1073.00
bg_gesamtbedarf=1073.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1073.00
budget_rest_hypothetisch=300.00
budget_rest_erwartet=300.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 26130175c572889d, Nachher-Prüfsumme 26130175c572889d (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0016]
    erwartet = 1 | ist = 1
V3: OK | Zahlung bleibt freigegeben (kein Storno durch SB)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-NW-0016]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Budget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0016]
    erwartet = 300.00 | ist = 300
V5: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V6: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:43.498 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-16-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:06:44.462 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0016)  [Bild: tf-16-schritt-02.png] -> OK — Vorgang SWEET-NW-0016 (Web, Negativ 16) mit Startbudget 1373.00 EUR angelegt
2026-10-15 10:06:45.378 sb-web-03 | [S3] SozialFall erfassen  [Bild: tf-16-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 510.00 EUR) gespeichert
2026-10-15 10:06:46.074 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-16-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:06:46.365 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-16-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:06:47.050 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-16-schritt-06.png] -> OK — Vorgang SWEET-NW-0016 über Suchfeld ermittelt und geöffnet
2026-10-15 10:06:47.727 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-16-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:06:47.805 sb-web-03 | [S8] Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten  [Bild: tf-16-schritt-08.png] -> OK — Storno-Knopf für Sachbearbeiter korrekt ausgeblendet (nur Admin-Rolle)

## TF 17 WEB-NEG-KEINANSPRUCH SWEET-NW-0017
status = VERIFIZIERT
hauptperson = Web, Negativ 17
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4795
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — KEIN_ANSPRUCH erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 859f85decb61a593, Nachher-Prüfsumme 859f85decb61a593 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden (KEIN_ANSPRUCH abgewehrt)
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0017]
    erwartet = 0 | ist = 0
V3: OK | SozialFall mit Rente persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?) AND EINKOMMEN_RENTE = ?
    params = [SWEET-NW-0017, 5500.00]
    erwartet = 1 | ist = 1
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:46.182 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-17-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:06:47.120 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0017)  [Bild: tf-17-schritt-02.png] -> OK — Vorgang SWEET-NW-0017 (Web, Negativ 17) mit Startbudget 1200 EUR angelegt
2026-10-15 10:06:48.022 sb-web-02 | [S3] SozialFall mit hoher Rente erfassen  [Bild: tf-17-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 420 EUR, Rente 5500.00 EUR) gespeichert
2026-10-15 10:06:50.210 sb-web-02 | [S4] Auszahlung anordnen — KEIN_ANSPRUCH erwartet  [Bild: tf-17-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Einkommen/Vermögen übersteigen den Gesamtbedarf — kein Anspruch (Zahlbetrag -4.629,00 EUR)

## TF 18 WEB-NEG-STORNO-SB SWEET-NW-0018
status = VERIFIZIERT
hauptperson = Web, Negativ 18
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 4984
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

block: Anordnung + Freigabe
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1236.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=450.00, kdu_betrieb=55.00, kdu_heizung=85.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=590.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1096.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1096.00
bg_gesamtbedarf=1096.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1096.00
budget_rest_hypothetisch=140.00
budget_rest_erwartet=140.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme e57697a0fc581517, Nachher-Prüfsumme e57697a0fc581517 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0018]
    erwartet = 1 | ist = 1
V3: OK | Zahlung bleibt freigegeben (kein Storno durch SB)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-NW-0018]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Budget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0018]
    erwartet = 140.00 | ist = 140
V5: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V6: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:47.511 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-18-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:06:48.404 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0018)  [Bild: tf-18-schritt-02.png] -> OK — Vorgang SWEET-NW-0018 (Web, Negativ 18) mit Startbudget 1236.00 EUR angelegt
2026-10-15 10:06:49.271 sb-web-01 | [S3] SozialFall erfassen  [Bild: tf-18-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 590.00 EUR) gespeichert
2026-10-15 10:06:49.936 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-18-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:06:50.249 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-18-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:06:50.956 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-18-schritt-06.png] -> OK — Vorgang SWEET-NW-0018 über Suchfeld ermittelt und geöffnet
2026-10-15 10:06:51.627 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-18-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:06:51.703 sb-web-01 | [S8] Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten  [Bild: tf-18-schritt-08.png] -> OK — Storno-Knopf für Sachbearbeiter korrekt ausgeblendet (nur Admin-Rolle)

## TF 19 WEB-NEG-DOPPELMONAT SWEET-NW-0019
status = VERIFIZIERT
hauptperson = Web, Negativ 19
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 3431
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

block: Erste Anordnung
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1186.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=280.00, kdu_betrieb=40.00, kdu_heizung=90.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=410.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=916.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=916.00
bg_gesamtbedarf=916.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=916.00
budget_rest_hypothetisch=270.00
budget_rest_erwartet=270.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 04403160a17f199d, Nachher-Prüfsumme 04403160a17f199d (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | genau eine Zahlung je Vorgang und Monat
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0019]
    erwartet = 1 | ist = 1
V3: OK | Budget nur einmal gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0019]
    erwartet = 270.00 | ist = 270
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:48.127 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-19-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:06:49.006 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0019)  [Bild: tf-19-schritt-02.png] -> OK — Vorgang SWEET-NW-0019 (Web, Negativ 19) mit Startbudget 1186.00 EUR angelegt
2026-10-15 10:06:49.883 sb-web-03 | [S3] SozialFall erfassen  [Bild: tf-19-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 410.00 EUR) gespeichert
2026-10-15 10:06:50.565 sb-web-03 | [S4] Erste Auszahlung für 2026-10 anordnen  [Bild: tf-19-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:06:51.236 sb-web-03 | [S5] ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet  [Bild: tf-19-schritt-05.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Für 2026-10 existiert bereits eine nicht stornierte Zahlung dieser Bedarfsgemeinschaft; ggf. zuerst stornieren

## TF 20 WEB-NEG-STORNO-SB SWEET-NW-0020
status = VERIFIZIERT
hauptperson = Web, Negativ 20
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4556
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

block: Anordnung + Freigabe
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1171.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=250.00, kdu_betrieb=40.00, kdu_heizung=105.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=395.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=901.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=901.00
bg_gesamtbedarf=901.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=901.00
budget_rest_hypothetisch=270.00
budget_rest_erwartet=270.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme bfb0ecea45fedc44, Nachher-Prüfsumme bfb0ecea45fedc44 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0020]
    erwartet = 1 | ist = 1
V3: OK | Zahlung bleibt freigegeben (kein Storno durch SB)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-NW-0020]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Budget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0020]
    erwartet = 270.00 | ist = 270
V5: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V6: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:50.549 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-20-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:06:51.481 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0020)  [Bild: tf-20-schritt-02.png] -> OK — Vorgang SWEET-NW-0020 (Web, Negativ 20) mit Startbudget 1171.00 EUR angelegt
2026-10-15 10:06:52.340 sb-web-02 | [S3] SozialFall erfassen  [Bild: tf-20-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 395.00 EUR) gespeichert
2026-10-15 10:06:53.022 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-20-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:06:53.333 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-20-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:06:54.030 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-20-schritt-06.png] -> OK — Vorgang SWEET-NW-0020 über Suchfeld ermittelt und geöffnet
2026-10-15 10:06:54.693 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-20-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:06:54.768 sb-web-02 | [S8] Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten  [Bild: tf-20-schritt-08.png] -> OK — Storno-Knopf für Sachbearbeiter korrekt ausgeblendet (nur Admin-Rolle)

## TF 21 WEB-NEG-KEINANSPRUCH SWEET-NW-0021
status = VERIFIZIERT
hauptperson = Web, Negativ 21
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 4735
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — KEIN_ANSPRUCH erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 02257bc8c71a7cbd, Nachher-Prüfsumme 02257bc8c71a7cbd (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden (KEIN_ANSPRUCH abgewehrt)
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0021]
    erwartet = 0 | ist = 0
V3: OK | SozialFall mit Rente persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?) AND EINKOMMEN_RENTE = ?
    params = [SWEET-NW-0021, 2500.00]
    erwartet = 1 | ist = 1
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:51.993 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-21-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:06:52.877 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0021)  [Bild: tf-21-schritt-02.png] -> OK — Vorgang SWEET-NW-0021 (Web, Negativ 21) mit Startbudget 1200 EUR angelegt
2026-10-15 10:06:53.806 sb-web-03 | [S3] SozialFall mit hoher Rente erfassen  [Bild: tf-21-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 420 EUR, Rente 2500.00 EUR) gespeichert
2026-10-15 10:06:55.973 sb-web-03 | [S4] Auszahlung anordnen — KEIN_ANSPRUCH erwartet  [Bild: tf-21-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Einkommen/Vermögen übersteigen den Gesamtbedarf — kein Anspruch (Zahlbetrag -1.517,00 EUR)

## TF 22 WEB-NEG-OHNE-MONAT SWEET-NW-0022
status = VERIFIZIERT
hauptperson = Web, Negativ 22
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 4904
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-02, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung OHNE Zahlungsmonat anordnen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme ca4e69707fce4cdb, Nachher-Prüfsumme ca4e69707fce4cdb (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Vorgang angelegt
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0022]
    erwartet = 1 | ist = 1
V3: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0022]
    erwartet = 0 | ist = 0
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:53.008 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-22-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:06:54.024 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0022)  [Bild: tf-22-schritt-02.png] -> OK — Vorgang SWEET-NW-0022 (Web, Negativ 22) mit Startbudget 1200 EUR angelegt
2026-10-15 10:06:54.907 sb-web-01 | [S3] SozialFall erfassen (RBS 1)  [Bild: tf-22-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 540 EUR) gespeichert
2026-10-15 10:06:56.608 sb-web-01 | [S4] Auszahlung OHNE Zahlungsmonat anordnen  [Bild: tf-22-schritt-04.png] -> OK — Anordnung ohne Zahlungsmonat abgewehrt — Fehlerdialog: Bitte den Zahlungsmonat wählen.

## TF 23 WEB-NEG-BUDGET SWEET-NW-0023
status = VERIFIZIERT
hauptperson = Web, Negativ 23
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4891
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

block: Bedarf (Budget bewusst zu klein)
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1066.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=400.00, kdu_betrieb=105.00, kdu_heizung=95.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=600.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1106.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1106.00
bg_gesamtbedarf=1106.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1106.00
budget_rest_hypothetisch=-40.00
budget_rest_erwartet=1066.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme c1e6abff65093175, Nachher-Prüfsumme c1e6abff65093175 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0023]
    erwartet = 0 | ist = 0
V3: OK | Budget unverändert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0023]
    erwartet = 1066.00 | ist = 1066
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:55.617 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-23-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:06:56.544 sb-web-02 | [S2] Neuen Vorgang mit Startbudget 1066.00 EUR anlegen (bewusst zu klein)  [Bild: tf-23-schritt-02.png] -> OK — Vorgang SWEET-NW-0023 (Web, Negativ 23) mit Startbudget 1066.00 EUR angelegt
2026-10-15 10:06:57.458 sb-web-02 | [S3] SozialFall erfassen (Bedarf 1106.00 EUR)  [Bild: tf-23-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 600.00 EUR) gespeichert
2026-10-15 10:06:59.660 sb-web-02 | [S4] Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet  [Bild: tf-23-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Der Zahlbetrag 1.106,00 EUR übersteigt das verfügbare Restbudget von 1.066,00 EUR

## TF 24 WEB-NEG-STORNO-SB SWEET-NW-0024
status = VERIFIZIERT
hauptperson = Web, Negativ 24
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 4461
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-02, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

block: Anordnung + Freigabe
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1156.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=280.00, kdu_betrieb=80.00, kdu_heizung=90.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=450.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=956.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=956.00
bg_gesamtbedarf=956.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=956.00
budget_rest_hypothetisch=200.00
budget_rest_erwartet=200.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 869c8c53e8b716b7, Nachher-Prüfsumme 869c8c53e8b716b7 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0024]
    erwartet = 1 | ist = 1
V3: OK | Zahlung bleibt freigegeben (kein Storno durch SB)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-NW-0024]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Budget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0024]
    erwartet = 200.00 | ist = 200
V5: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V6: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:56.279 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-24-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:06:57.227 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0024)  [Bild: tf-24-schritt-02.png] -> OK — Vorgang SWEET-NW-0024 (Web, Negativ 24) mit Startbudget 1156.00 EUR angelegt
2026-10-15 10:06:58.103 sb-web-03 | [S3] SozialFall erfassen  [Bild: tf-24-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 450.00 EUR) gespeichert
2026-10-15 10:06:58.774 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-24-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:06:59.008 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-24-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-02
2026-10-15 10:06:59.677 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-24-schritt-06.png] -> OK — Vorgang SWEET-NW-0024 über Suchfeld ermittelt und geöffnet
2026-10-15 10:07:00.352 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-24-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:07:00.435 sb-web-03 | [S8] Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten  [Bild: tf-24-schritt-08.png] -> OK — Storno-Knopf für Sachbearbeiter korrekt ausgeblendet (nur Admin-Rolle)

## TF 25 WEB-NEG-BUDGET SWEET-NW-0025
status = VERIFIZIERT
hauptperson = Web, Negativ 25
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 4251
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-02, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

block: Bedarf (Budget bewusst zu klein)
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1026.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=450.00, kdu_betrieb=70.00, kdu_heizung=60.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=580.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1086.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1086.00
bg_gesamtbedarf=1086.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1086.00
budget_rest_hypothetisch=-60.00
budget_rest_erwartet=1026.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 63b4d0a26c74f77c, Nachher-Prüfsumme 63b4d0a26c74f77c (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0025]
    erwartet = 0 | ist = 0
V3: OK | Budget unverändert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0025]
    erwartet = 1026.00 | ist = 1026
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:06:56.916 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-25-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:06:57.831 sb-web-01 | [S2] Neuen Vorgang mit Startbudget 1026.00 EUR anlegen (bewusst zu klein)  [Bild: tf-25-schritt-02.png] -> OK — Vorgang SWEET-NW-0025 (Web, Negativ 25) mit Startbudget 1026.00 EUR angelegt
2026-10-15 10:06:58.671 sb-web-01 | [S3] SozialFall erfassen (Bedarf 1086.00 EUR)  [Bild: tf-25-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 580.00 EUR) gespeichert
2026-10-15 10:07:00.859 sb-web-01 | [S4] Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet  [Bild: tf-25-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Der Zahlbetrag 1.086,00 EUR übersteigt das verfügbare Restbudget von 1.026,00 EUR

## TF 26 WEB-NEG-OHNE-MONAT SWEET-NW-0026
status = VERIFIZIERT
hauptperson = Web, Negativ 26
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4351
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung OHNE Zahlungsmonat anordnen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 3b943b2aee699c5e, Nachher-Prüfsumme 3b943b2aee699c5e (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Vorgang angelegt
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0026]
    erwartet = 1 | ist = 1
V3: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0026]
    erwartet = 0 | ist = 0
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:00.461 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-26-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:07:01.412 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0026)  [Bild: tf-26-schritt-02.png] -> OK — Vorgang SWEET-NW-0026 (Web, Negativ 26) mit Startbudget 1200 EUR angelegt
2026-10-15 10:07:02.338 sb-web-02 | [S3] SozialFall erfassen (RBS 3)  [Bild: tf-26-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 540 EUR) gespeichert
2026-10-15 10:07:04.012 sb-web-02 | [S4] Auszahlung OHNE Zahlungsmonat anordnen  [Bild: tf-26-schritt-04.png] -> OK — Anordnung ohne Zahlungsmonat abgewehrt — Fehlerdialog: Bitte den Zahlungsmonat wählen.

## TF 27 WEB-NEG-OHNE-MONAT SWEET-NW-0027
status = VERIFIZIERT
hauptperson = Web, Negativ 27
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 4391
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung OHNE Zahlungsmonat anordnen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme b589c63792a7bd0c, Nachher-Prüfsumme b589c63792a7bd0c (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Vorgang angelegt
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0027]
    erwartet = 1 | ist = 1
V3: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0027]
    erwartet = 0 | ist = 0
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:01.323 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-27-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:07:02.322 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0027)  [Bild: tf-27-schritt-02.png] -> OK — Vorgang SWEET-NW-0027 (Web, Negativ 27) mit Startbudget 1200 EUR angelegt
2026-10-15 10:07:03.170 sb-web-03 | [S3] SozialFall erfassen (RBS 3)  [Bild: tf-27-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 540 EUR) gespeichert
2026-10-15 10:07:04.827 sb-web-03 | [S4] Auszahlung OHNE Zahlungsmonat anordnen  [Bild: tf-27-schritt-04.png] -> OK — Anordnung ohne Zahlungsmonat abgewehrt — Fehlerdialog: Bitte den Zahlungsmonat wählen.

## TF 28 WEB-NEG-STORNO-SB SWEET-NW-0028
status = VERIFIZIERT
hauptperson = Web, Negativ 28
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 4493
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

block: Anordnung + Freigabe
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1236.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=380.00, kdu_betrieb=35.00, kdu_heizung=55.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=470.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=976.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=976.00
bg_gesamtbedarf=976.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=976.00
budget_rest_hypothetisch=260.00
budget_rest_erwartet=260.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 047ce3689336c24a, Nachher-Prüfsumme 047ce3689336c24a (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0028]
    erwartet = 1 | ist = 1
V3: OK | Zahlung bleibt freigegeben (kein Storno durch SB)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-NW-0028]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Budget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0028]
    erwartet = 260.00 | ist = 260
V5: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V6: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:01.200 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-28-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:07:02.182 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0028)  [Bild: tf-28-schritt-02.png] -> OK — Vorgang SWEET-NW-0028 (Web, Negativ 28) mit Startbudget 1236.00 EUR angelegt
2026-10-15 10:07:03.025 sb-web-01 | [S3] SozialFall erfassen  [Bild: tf-28-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 470.00 EUR) gespeichert
2026-10-15 10:07:03.673 sb-web-01 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-28-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:07:03.923 sb-web-01 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-28-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-03
2026-10-15 10:07:04.629 sb-web-01 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-28-schritt-06.png] -> OK — Vorgang SWEET-NW-0028 über Suchfeld ermittelt und geöffnet
2026-10-15 10:07:05.293 sb-web-01 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-28-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:07:05.354 sb-web-01 | [S8] Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten  [Bild: tf-28-schritt-08.png] -> OK — Storno-Knopf für Sachbearbeiter korrekt ausgeblendet (nur Admin-Rolle)

## TF 29 WEB-NEG-STORNO-SB SWEET-NW-0029
status = VERIFIZIERT
hauptperson = Web, Negativ 29
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4880
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

block: Anordnung + Freigabe
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1246.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=420.00, kdu_betrieb=70.00, kdu_heizung=105.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=595.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1046.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1046.00
bg_gesamtbedarf=1046.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1046.00
budget_rest_hypothetisch=200.00
budget_rest_erwartet=200.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme f46b234af74a0824, Nachher-Prüfsumme f46b234af74a0824 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0029]
    erwartet = 1 | ist = 1
V3: OK | Zahlung bleibt freigegeben (kein Storno durch SB)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-NW-0029]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Budget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0029]
    erwartet = 200.00 | ist = 200
V5: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V6: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:04.810 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-29-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:07:05.693 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0029)  [Bild: tf-29-schritt-02.png] -> OK — Vorgang SWEET-NW-0029 (Web, Negativ 29) mit Startbudget 1246.00 EUR angelegt
2026-10-15 10:07:06.570 sb-web-02 | [S3] SozialFall erfassen  [Bild: tf-29-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 595.00 EUR) gespeichert
2026-10-15 10:07:07.242 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-29-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:07:07.491 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-29-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:07:08.170 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-29-schritt-06.png] -> OK — Vorgang SWEET-NW-0029 über Suchfeld ermittelt und geöffnet
2026-10-15 10:07:08.814 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-29-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:07:08.894 sb-web-02 | [S8] Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten  [Bild: tf-29-schritt-08.png] -> OK — Storno-Knopf für Sachbearbeiter korrekt ausgeblendet (nur Admin-Rolle)

## TF 30 WEB-NEG-STORNO-SB SWEET-NW-0030
status = VERIFIZIERT
hauptperson = Web, Negativ 30
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 4916
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

block: Anordnung + Freigabe
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1183.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=280.00, kdu_betrieb=90.00, kdu_heizung=60.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=430.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=993.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=993.00
bg_gesamtbedarf=993.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=993.00
budget_rest_hypothetisch=190.00
budget_rest_erwartet=190.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 7b117b6b6c96880e, Nachher-Prüfsumme 7b117b6b6c96880e (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0030]
    erwartet = 1 | ist = 1
V3: OK | Zahlung bleibt freigegeben (kein Storno durch SB)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-NW-0030]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Budget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0030]
    erwartet = 190.00 | ist = 190
V5: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V6: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:05.609 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-30-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:07:06.508 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0030)  [Bild: tf-30-schritt-02.png] -> OK — Vorgang SWEET-NW-0030 (Web, Negativ 30) mit Startbudget 1183.00 EUR angelegt
2026-10-15 10:07:07.384 sb-web-03 | [S3] SozialFall erfassen  [Bild: tf-30-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 430.00 EUR) gespeichert
2026-10-15 10:07:08.060 sb-web-03 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-30-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:07:08.353 sb-web-03 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-30-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:07:09.017 sb-web-03 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-30-schritt-06.png] -> OK — Vorgang SWEET-NW-0030 über Suchfeld ermittelt und geöffnet
2026-10-15 10:07:09.670 sb-web-03 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-30-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:07:09.743 sb-web-03 | [S8] Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten  [Bild: tf-30-schritt-08.png] -> OK — Storno-Knopf für Sachbearbeiter korrekt ausgeblendet (nur Admin-Rolle)

## TF 31 WEB-NEG-LOGIN SWEET-NW-0031
status = VERIFIZIERT
hauptperson = —
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 855
ids = kollege=sb-web-03, adminKonto=web-admin, mitarbeiter=sb-web-01

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Anmeldung mit FALSCHEM Passwort versuchen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | kein Vorgang durch die abgewehrte Anmeldung entstanden
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0031]
    erwartet = 0 | ist = 0
V3: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:06.209 sb-web-01 | [S1] Anmeldung mit FALSCHEM Passwort versuchen  [Bild: tf-31-schritt-01.png] -> OK — Anmeldung abgewehrt — Oberfläche meldet: Kennung oder Passwort ist falsch

## TF 32 WEB-NEG-DOPPELMONAT SWEET-NW-0032
status = VERIFIZIERT
hauptperson = Web, Negativ 32
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 3411
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

block: Erste Anordnung
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1443.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=420.00, kdu_betrieb=90.00, kdu_heizung=70.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=580.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1143.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1143.00
bg_gesamtbedarf=1143.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1143.00
budget_rest_hypothetisch=300.00
budget_rest_erwartet=300.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 339b5de6908a7174, Nachher-Prüfsumme 339b5de6908a7174 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | genau eine Zahlung je Vorgang und Monat
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0032]
    erwartet = 1 | ist = 1
V3: OK | Budget nur einmal gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0032]
    erwartet = 300.00 | ist = 300
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:06.459 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-32-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:07:07.412 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0032)  [Bild: tf-32-schritt-02.png] -> OK — Vorgang SWEET-NW-0032 (Web, Negativ 32) mit Startbudget 1443.00 EUR angelegt
2026-10-15 10:07:08.279 sb-web-01 | [S3] SozialFall erfassen  [Bild: tf-32-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 580.00 EUR) gespeichert
2026-10-15 10:07:08.959 sb-web-01 | [S4] Erste Auszahlung für 2026-10 anordnen  [Bild: tf-32-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:07:09.622 sb-web-01 | [S5] ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet  [Bild: tf-32-schritt-05.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Für 2026-10 existiert bereits eine nicht stornierte Zahlung dieser Bedarfsgemeinschaft; ggf. zuerst stornieren

## TF 33 WEB-NEG-DOPPELMONAT SWEET-NW-0033
status = VERIFIZIERT
hauptperson = Web, Negativ 33
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 3862
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

block: Erste Anordnung
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1358.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=400.00, kdu_betrieb=55.00, kdu_heizung=110.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=565.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1128.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1128.00
bg_gesamtbedarf=1128.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1128.00
budget_rest_hypothetisch=230.00
budget_rest_erwartet=230.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 04789d78736d850f, Nachher-Prüfsumme 04789d78736d850f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | genau eine Zahlung je Vorgang und Monat
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0033]
    erwartet = 1 | ist = 1
V3: OK | Budget nur einmal gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0033]
    erwartet = 230.00 | ist = 230
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:09.694 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-33-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:07:10.595 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0033)  [Bild: tf-33-schritt-02.png] -> OK — Vorgang SWEET-NW-0033 (Web, Negativ 33) mit Startbudget 1358.00 EUR angelegt
2026-10-15 10:07:11.447 sb-web-02 | [S3] SozialFall erfassen  [Bild: tf-33-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 565.00 EUR) gespeichert
2026-10-15 10:07:12.098 sb-web-02 | [S4] Erste Auszahlung für 2026-10 anordnen  [Bild: tf-33-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:07:12.757 sb-web-02 | [S5] ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet  [Bild: tf-33-schritt-05.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Für 2026-10 existiert bereits eine nicht stornierte Zahlung dieser Bedarfsgemeinschaft; ggf. zuerst stornieren

## TF 34 WEB-NEG-LOGIN SWEET-NW-0034
status = VERIFIZIERT
hauptperson = —
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 786
ids = kollege=sb-web-03, adminKonto=web-admin, mitarbeiter=sb-web-01

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Anmeldung mit FALSCHEM Passwort versuchen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | kein Vorgang durch die abgewehrte Anmeldung entstanden
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0034]
    erwartet = 0 | ist = 0
V3: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:10.408 sb-web-01 | [S1] Anmeldung mit FALSCHEM Passwort versuchen  [Bild: tf-34-schritt-01.png] -> OK — Anmeldung abgewehrt — Oberfläche meldet: Kennung oder Passwort ist falsch

## TF 35 WEB-NEG-DOPPELMONAT SWEET-NW-0035
status = VERIFIZIERT
hauptperson = Web, Negativ 35
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 3874
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-02, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

block: Erste Anordnung
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1191.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=360.00, kdu_betrieb=75.00, kdu_heizung=105.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=540.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=991.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=991.00
bg_gesamtbedarf=991.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=991.00
budget_rest_hypothetisch=200.00
budget_rest_erwartet=200.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme b058f5b3bc8a3c4a, Nachher-Prüfsumme b058f5b3bc8a3c4a (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | genau eine Zahlung je Vorgang und Monat
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0035]
    erwartet = 1 | ist = 1
V3: OK | Budget nur einmal gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0035]
    erwartet = 200.00 | ist = 200
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:10.545 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-35-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:07:11.461 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0035)  [Bild: tf-35-schritt-02.png] -> OK — Vorgang SWEET-NW-0035 (Web, Negativ 35) mit Startbudget 1191.00 EUR angelegt
2026-10-15 10:07:12.297 sb-web-03 | [S3] SozialFall erfassen  [Bild: tf-35-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 540.00 EUR) gespeichert
2026-10-15 10:07:12.958 sb-web-03 | [S4] Erste Auszahlung für 2026-10 anordnen  [Bild: tf-35-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:07:13.618 sb-web-03 | [S5] ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet  [Bild: tf-35-schritt-05.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Für 2026-10 existiert bereits eine nicht stornierte Zahlung dieser Bedarfsgemeinschaft; ggf. zuerst stornieren

## TF 36 WEB-NEG-KEINANSPRUCH SWEET-NW-0036
status = VERIFIZIERT
hauptperson = Web, Negativ 36
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 4201
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — KEIN_ANSPRUCH erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme dc0cb56f2f5cfb00, Nachher-Prüfsumme dc0cb56f2f5cfb00 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden (KEIN_ANSPRUCH abgewehrt)
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0036]
    erwartet = 0 | ist = 0
V3: OK | SozialFall mit Rente persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?) AND EINKOMMEN_RENTE = ?
    params = [SWEET-NW-0036, 4500.00]
    erwartet = 1 | ist = 1
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:10.655 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-36-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:07:11.553 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0036)  [Bild: tf-36-schritt-02.png] -> OK — Vorgang SWEET-NW-0036 (Web, Negativ 36) mit Startbudget 1200 EUR angelegt
2026-10-15 10:07:12.419 sb-web-01 | [S3] SozialFall mit hoher Rente erfassen  [Bild: tf-36-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 420 EUR, Rente 4500.00 EUR) gespeichert
2026-10-15 10:07:14.610 sb-web-01 | [S4] Auszahlung anordnen — KEIN_ANSPRUCH erwartet  [Bild: tf-36-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Einkommen/Vermögen übersteigen den Gesamtbedarf — kein Anspruch (Zahlbetrag -3.629,00 EUR)

## TF 37 WEB-NEG-BANKVERBINDUNG SWEET-NW-0037
status = VERIFIZIERT
hauptperson = —
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 1586
ids = adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-02, mitarbeiter=sb-web-02

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Vorgang mit IBAN mit falscher Prüfziffer anlegen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | UI-Fehlversuch ohne Fachänderung: Vorgang mit zu kurzem BIC (7 Zeichen) anlegen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V3: OK | kein Vorgang mit dem Aktenzeichen angelegt
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0037]
    erwartet = 0 | ist = 0
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:13.033 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-37-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:07:13.957 sb-web-02 | [S2] Vorgang mit IBAN mit falscher Prüfziffer anlegen  [Bild: tf-37-schritt-02.png] -> OK — Neuanlage abgewehrt — Fehlerdialog: Ungültige IBAN
2026-10-15 10:07:14.345 sb-web-02 | [S3] Vorgang mit zu kurzem BIC (7 Zeichen) anlegen  [Bild: tf-37-schritt-03.png] -> OK — Neuanlage abgewehrt — Fehlerdialog: Ungültiger BIC

## TF 38 WEB-NEG-LOGIN SWEET-NW-0038
status = VERIFIZIERT
hauptperson = —
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 259
ids = kollege=sb-web-02, adminKonto=web-admin, mitarbeiter=sb-web-03

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Anmeldung mit FALSCHEM Passwort versuchen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | kein Vorgang durch die abgewehrte Anmeldung entstanden
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0038]
    erwartet = 0 | ist = 0
V3: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:13.877 sb-web-03 | [S1] Anmeldung mit FALSCHEM Passwort versuchen  [Bild: tf-38-schritt-01.png] -> OK — Anmeldung abgewehrt — Oberfläche meldet: Kennung oder Passwort ist falsch

## TF 39 WEB-NEG-BUDGET SWEET-NW-0039
status = VERIFIZIERT
hauptperson = Web, Negativ 39
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 4071
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-02, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

block: Bedarf (Budget bewusst zu klein)
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 926.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=330.00, kdu_betrieb=65.00, kdu_heizung=100.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=495.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=946.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=946.00
bg_gesamtbedarf=946.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=946.00
budget_rest_hypothetisch=-20.00
budget_rest_erwartet=926.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 8190be3845db037c, Nachher-Prüfsumme 8190be3845db037c (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0039]
    erwartet = 0 | ist = 0
V3: OK | Budget unverändert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0039]
    erwartet = 926.00 | ist = 926
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:14.091 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-39-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:07:14.967 sb-web-03 | [S2] Neuen Vorgang mit Startbudget 926.00 EUR anlegen (bewusst zu klein)  [Bild: tf-39-schritt-02.png] -> OK — Vorgang SWEET-NW-0039 (Web, Negativ 39) mit Startbudget 926.00 EUR angelegt
2026-10-15 10:07:15.800 sb-web-03 | [S3] SozialFall erfassen (Bedarf 946.00 EUR)  [Bild: tf-39-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 495.00 EUR) gespeichert
2026-10-15 10:07:17.949 sb-web-03 | [S4] Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet  [Bild: tf-39-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Der Zahlbetrag 946,00 EUR übersteigt das verfügbare Restbudget von 926,00 EUR

## TF 40 WEB-NEG-DOPPELMONAT SWEET-NW-0040
status = VERIFIZIERT
hauptperson = Web, Negativ 40
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 3236
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

block: Erste Anordnung
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1218.00
p1_eingaben: rbs=1, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=280.00, kdu_betrieb=70.00, kdu_heizung=55.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=563.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=405.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=968.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=968.00
bg_gesamtbedarf=968.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=968.00
budget_rest_hypothetisch=250.00
budget_rest_erwartet=250.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 44b2ad9f6b29f3b8, Nachher-Prüfsumme 44b2ad9f6b29f3b8 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | genau eine Zahlung je Vorgang und Monat
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0040]
    erwartet = 1 | ist = 1
V3: OK | Budget nur einmal gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0040]
    erwartet = 250.00 | ist = 250
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:14.579 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-40-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:07:15.475 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0040)  [Bild: tf-40-schritt-02.png] -> OK — Vorgang SWEET-NW-0040 (Web, Negativ 40) mit Startbudget 1218.00 EUR angelegt
2026-10-15 10:07:16.295 sb-web-02 | [S3] SozialFall erfassen  [Bild: tf-40-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 405.00 EUR) gespeichert
2026-10-15 10:07:16.942 sb-web-02 | [S4] Erste Auszahlung für 2026-10 anordnen  [Bild: tf-40-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:07:17.581 sb-web-02 | [S5] ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet  [Bild: tf-40-schritt-05.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Für 2026-10 existiert bereits eine nicht stornierte Zahlung dieser Bedarfsgemeinschaft; ggf. zuerst stornieren

## TF 41 WEB-NEG-OHNE-MONAT SWEET-NW-0041
status = VERIFIZIERT
hauptperson = Web, Negativ 41
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 3631
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung OHNE Zahlungsmonat anordnen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 17abc47f9db379de, Nachher-Prüfsumme 17abc47f9db379de (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Vorgang angelegt
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0041]
    erwartet = 1 | ist = 1
V3: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0041]
    erwartet = 0 | ist = 0
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:14.905 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-41-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:07:15.770 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0041)  [Bild: tf-41-schritt-02.png] -> OK — Vorgang SWEET-NW-0041 (Web, Negativ 41) mit Startbudget 1200 EUR angelegt
2026-10-15 10:07:16.587 sb-web-01 | [S3] SozialFall erfassen (RBS 1)  [Bild: tf-41-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 540 EUR) gespeichert
2026-10-15 10:07:18.242 sb-web-01 | [S4] Auszahlung OHNE Zahlungsmonat anordnen  [Bild: tf-41-schritt-04.png] -> OK — Anordnung ohne Zahlungsmonat abgewehrt — Fehlerdialog: Bitte den Zahlungsmonat wählen.

## TF 42 WEB-NEG-KEINANSPRUCH SWEET-NW-0042
status = VERIFIZIERT
hauptperson = Web, Negativ 42
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4660
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — KEIN_ANSPRUCH erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme bfb478869d49ef0b, Nachher-Prüfsumme bfb478869d49ef0b (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden (KEIN_ANSPRUCH abgewehrt)
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0042]
    erwartet = 0 | ist = 0
V3: OK | SozialFall mit Rente persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?) AND EINKOMMEN_RENTE = ?
    params = [SWEET-NW-0042, 3500.00]
    erwartet = 1 | ist = 1
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:18.317 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-42-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:07:19.221 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0042)  [Bild: tf-42-schritt-02.png] -> OK — Vorgang SWEET-NW-0042 (Web, Negativ 42) mit Startbudget 1200 EUR angelegt
2026-10-15 10:07:20.087 sb-web-02 | [S3] SozialFall mit hoher Rente erfassen  [Bild: tf-42-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 420 EUR, Rente 3500.00 EUR) gespeichert
2026-10-15 10:07:22.242 sb-web-02 | [S4] Auszahlung anordnen — KEIN_ANSPRUCH erwartet  [Bild: tf-42-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Einkommen/Vermögen übersteigen den Gesamtbedarf — kein Anspruch (Zahlbetrag -2.574,00 EUR)

## TF 43 WEB-NEG-KEINANSPRUCH SWEET-NW-0043
status = VERIFIZIERT
hauptperson = Web, Negativ 43
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 4185
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-02, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — KEIN_ANSPRUCH erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5a7c01dbbb6877c8, Nachher-Prüfsumme 5a7c01dbbb6877c8 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden (KEIN_ANSPRUCH abgewehrt)
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0043]
    erwartet = 0 | ist = 0
V3: OK | SozialFall mit Rente persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?) AND EINKOMMEN_RENTE = ?
    params = [SWEET-NW-0043, 5000.00]
    erwartet = 1 | ist = 1
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:18.194 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-43-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:07:19.109 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0043)  [Bild: tf-43-schritt-02.png] -> OK — Vorgang SWEET-NW-0043 (Web, Negativ 43) mit Startbudget 1200 EUR angelegt
2026-10-15 10:07:19.979 sb-web-03 | [S3] SozialFall mit hoher Rente erfassen  [Bild: tf-43-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 420 EUR, Rente 5000.00 EUR) gespeichert
2026-10-15 10:07:22.135 sb-web-03 | [S4] Auszahlung anordnen — KEIN_ANSPRUCH erwartet  [Bild: tf-43-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Einkommen/Vermögen übersteigen den Gesamtbedarf — kein Anspruch (Zahlbetrag -4.129,00 EUR)

## TF 44 WEB-NEG-DOPPELMONAT SWEET-NW-0044
status = VERIFIZIERT
hauptperson = Web, Negativ 44
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 3292
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-02, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

block: Erste Anordnung
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1031.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=270.00, kdu_betrieb=45.00, kdu_heizung=50.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=365.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=871.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=871.00
bg_gesamtbedarf=871.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=871.00
budget_rest_hypothetisch=160.00
budget_rest_erwartet=160.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 74935fa40b9573ef, Nachher-Prüfsumme 74935fa40b9573ef (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | genau eine Zahlung je Vorgang und Monat
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0044]
    erwartet = 1 | ist = 1
V3: OK | Budget nur einmal gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0044]
    erwartet = 160.00 | ist = 160
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:18.502 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-44-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:07:19.393 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0044)  [Bild: tf-44-schritt-02.png] -> OK — Vorgang SWEET-NW-0044 (Web, Negativ 44) mit Startbudget 1031.00 EUR angelegt
2026-10-15 10:07:20.224 sb-web-01 | [S3] SozialFall erfassen  [Bild: tf-44-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 365.00 EUR) gespeichert
2026-10-15 10:07:20.880 sb-web-01 | [S4] Erste Auszahlung für 2026-10 anordnen  [Bild: tf-44-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:07:21.533 sb-web-01 | [S5] ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet  [Bild: tf-44-schritt-05.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Für 2026-10 existiert bereits eine nicht stornierte Zahlung dieser Bedarfsgemeinschaft; ggf. zuerst stornieren

## TF 45 WEB-NEG-KEINANSPRUCH SWEET-NW-0045
status = VERIFIZIERT
hauptperson = Web, Negativ 45
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 4732
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — KEIN_ANSPRUCH erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 481b550558dfb35b, Nachher-Prüfsumme 481b550558dfb35b (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden (KEIN_ANSPRUCH abgewehrt)
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0045]
    erwartet = 0 | ist = 0
V3: OK | SozialFall mit Rente persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?) AND EINKOMMEN_RENTE = ?
    params = [SWEET-NW-0045, 4500.00]
    erwartet = 1 | ist = 1
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:22.302 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-45-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:07:23.209 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0045)  [Bild: tf-45-schritt-02.png] -> OK — Vorgang SWEET-NW-0045 (Web, Negativ 45) mit Startbudget 1200 EUR angelegt
2026-10-15 10:07:24.107 sb-web-01 | [S3] SozialFall mit hoher Rente erfassen  [Bild: tf-45-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 420 EUR, Rente 4500.00 EUR) gespeichert
2026-10-15 10:07:26.267 sb-web-01 | [S4] Auszahlung anordnen — KEIN_ANSPRUCH erwartet  [Bild: tf-45-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Einkommen/Vermögen übersteigen den Gesamtbedarf — kein Anspruch (Zahlbetrag -3.517,00 EUR)

## TF 46 WEB-NEG-DOPPELMONAT SWEET-NW-0046
status = VERIFIZIERT
hauptperson = Web, Negativ 46
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 3808
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

block: Erste Anordnung
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1091.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=320.00, kdu_betrieb=85.00, kdu_heizung=95.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=500.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=951.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=951.00
bg_gesamtbedarf=951.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=951.00
budget_rest_hypothetisch=140.00
budget_rest_erwartet=140.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 9894ae66edac21de, Nachher-Prüfsumme 9894ae66edac21de (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | genau eine Zahlung je Vorgang und Monat
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0046]
    erwartet = 1 | ist = 1
V3: OK | Budget nur einmal gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0046]
    erwartet = 140.00 | ist = 140
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:22.901 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-46-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:07:23.785 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0046)  [Bild: tf-46-schritt-02.png] -> OK — Vorgang SWEET-NW-0046 (Web, Negativ 46) mit Startbudget 1091.00 EUR angelegt
2026-10-15 10:07:24.626 sb-web-03 | [S3] SozialFall erfassen  [Bild: tf-46-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 500.00 EUR) gespeichert
2026-10-15 10:07:25.290 sb-web-03 | [S4] Erste Auszahlung für 2026-10 anordnen  [Bild: tf-46-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:07:25.943 sb-web-03 | [S5] ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet  [Bild: tf-46-schritt-05.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Für 2026-10 existiert bereits eine nicht stornierte Zahlung dieser Bedarfsgemeinschaft; ggf. zuerst stornieren

## TF 47 WEB-NEG-KEINANSPRUCH SWEET-NW-0047
status = VERIFIZIERT
hauptperson = Web, Negativ 47
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4209
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — KEIN_ANSPRUCH erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 8bf2a9e47a18f310, Nachher-Prüfsumme 8bf2a9e47a18f310 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden (KEIN_ANSPRUCH abgewehrt)
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0047]
    erwartet = 0 | ist = 0
V3: OK | SozialFall mit Rente persistiert
    sql    = SELECT COUNT(*) FROM SOZIAL_FALL WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?) AND EINKOMMEN_RENTE = ?
    params = [SWEET-NW-0047, 2500.00]
    erwartet = 1 | ist = 1
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:22.501 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-47-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:07:23.405 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0047)  [Bild: tf-47-schritt-02.png] -> OK — Vorgang SWEET-NW-0047 (Web, Negativ 47) mit Startbudget 1200 EUR angelegt
2026-10-15 10:07:24.308 sb-web-02 | [S3] SozialFall mit hoher Rente erfassen  [Bild: tf-47-schritt-03.png] -> OK — SozialFall (RBS 1, KdU 420 EUR, Rente 2500.00 EUR) gespeichert
2026-10-15 10:07:26.452 sb-web-02 | [S4] Auszahlung anordnen — KEIN_ANSPRUCH erwartet  [Bild: tf-47-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Einkommen/Vermögen übersteigen den Gesamtbedarf — kein Anspruch (Zahlbetrag -1.517,00 EUR)

## TF 48 WEB-NEG-LOGIN SWEET-NW-0048
status = VERIFIZIERT
hauptperson = —
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 755
ids = kollege=sb-web-01, adminKonto=web-admin, mitarbeiter=sb-web-03

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Anmeldung mit FALSCHEM Passwort versuchen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | kein Vorgang durch die abgewehrte Anmeldung entstanden
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0048]
    erwartet = 0 | ist = 0
V3: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:26.699 sb-web-03 | [S1] Anmeldung mit FALSCHEM Passwort versuchen  [Bild: tf-48-schritt-01.png] -> OK — Anmeldung abgewehrt — Oberfläche meldet: Kennung oder Passwort ist falsch

## TF 49 WEB-NEG-BANKVERBINDUNG SWEET-NW-0049
status = VERIFIZIERT
hauptperson = —
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 1615
ids = adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-01, mitarbeiter=sb-web-01

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Vorgang mit IBAN mit falscher Prüfziffer anlegen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | UI-Fehlversuch ohne Fachänderung: Vorgang mit zu kurzem BIC (7 Zeichen) anlegen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V3: OK | kein Vorgang mit dem Aktenzeichen angelegt
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0049]
    erwartet = 0 | ist = 0
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:27.023 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-49-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:07:27.482 sb-web-01 | [S2] Vorgang mit IBAN mit falscher Prüfziffer anlegen  [Bild: tf-49-schritt-02.png] -> OK — Neuanlage abgewehrt — Fehlerdialog: Ungültige IBAN
2026-10-15 10:07:27.883 sb-web-01 | [S3] Vorgang mit zu kurzem BIC (7 Zeichen) anlegen  [Bild: tf-49-schritt-03.png] -> OK — Neuanlage abgewehrt — Fehlerdialog: Ungültiger BIC

## TF 50 WEB-NEG-OHNE-MONAT SWEET-NW-0050
status = VERIFIZIERT
hauptperson = Web, Negativ 50
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4185
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung OHNE Zahlungsmonat anordnen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 686a9ad206d0d35f, Nachher-Prüfsumme 686a9ad206d0d35f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Vorgang angelegt
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0050]
    erwartet = 1 | ist = 1
V3: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0050]
    erwartet = 0 | ist = 0
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:27.236 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-50-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:07:28.128 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0050)  [Bild: tf-50-schritt-02.png] -> OK — Vorgang SWEET-NW-0050 (Web, Negativ 50) mit Startbudget 1200 EUR angelegt
2026-10-15 10:07:28.986 sb-web-02 | [S3] SozialFall erfassen (RBS 3)  [Bild: tf-50-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 540 EUR) gespeichert
2026-10-15 10:07:30.638 sb-web-02 | [S4] Auszahlung OHNE Zahlungsmonat anordnen  [Bild: tf-50-schritt-04.png] -> OK — Anordnung ohne Zahlungsmonat abgewehrt — Fehlerdialog: Bitte den Zahlungsmonat wählen.

## TF 51 WEB-NEG-LOGIN SWEET-NW-0051
status = VERIFIZIERT
hauptperson = —
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 243
ids = kollege=sb-web-02, adminKonto=web-admin, mitarbeiter=sb-web-03

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Anmeldung mit FALSCHEM Passwort versuchen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | kein Vorgang durch die abgewehrte Anmeldung entstanden
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0051]
    erwartet = 0 | ist = 0
V3: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:26.942 sb-web-03 | [S1] Anmeldung mit FALSCHEM Passwort versuchen  [Bild: tf-51-schritt-01.png] -> OK — Anmeldung abgewehrt — Oberfläche meldet: Kennung oder Passwort ist falsch

## TF 52 WEB-NEG-BANKVERBINDUNG SWEET-NW-0052
status = VERIFIZIERT
hauptperson = —
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 1080
ids = adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-03, mitarbeiter=sb-web-03

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Vorgang mit IBAN mit falscher Prüfziffer anlegen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | UI-Fehlversuch ohne Fachänderung: Vorgang mit zu kurzem BIC (7 Zeichen) anlegen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V3: OK | kein Vorgang mit dem Aktenzeichen angelegt
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0052]
    erwartet = 0 | ist = 0
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:27.176 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-52-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:07:27.619 sb-web-03 | [S2] Vorgang mit IBAN mit falscher Prüfziffer anlegen  [Bild: tf-52-schritt-02.png] -> OK — Neuanlage abgewehrt — Fehlerdialog: Ungültige IBAN
2026-10-15 10:07:28.022 sb-web-03 | [S3] Vorgang mit zu kurzem BIC (7 Zeichen) anlegen  [Bild: tf-52-schritt-03.png] -> OK — Neuanlage abgewehrt — Fehlerdialog: Ungültiger BIC

## TF 53 WEB-NEG-DOPPELMONAT SWEET-NW-0053
status = VERIFIZIERT
hauptperson = Web, Negativ 53
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 3304
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-02, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

block: Erste Anordnung
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1171.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=420.00, kdu_betrieb=55.00, kdu_heizung=65.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=540.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=991.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=991.00
bg_gesamtbedarf=991.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=991.00
budget_rest_hypothetisch=180.00
budget_rest_erwartet=180.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 6a989cc23db57cf6, Nachher-Prüfsumme 6a989cc23db57cf6 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | genau eine Zahlung je Vorgang und Monat
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0053]
    erwartet = 1 | ist = 1
V3: OK | Budget nur einmal gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0053]
    erwartet = 180.00 | ist = 180
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:28.189 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-53-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:07:29.080 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0053)  [Bild: tf-53-schritt-02.png] -> OK — Vorgang SWEET-NW-0053 (Web, Negativ 53) mit Startbudget 1171.00 EUR angelegt
2026-10-15 10:07:29.898 sb-web-01 | [S3] SozialFall erfassen  [Bild: tf-53-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 540.00 EUR) gespeichert
2026-10-15 10:07:30.560 sb-web-01 | [S4] Erste Auszahlung für 2026-10 anordnen  [Bild: tf-53-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:07:31.197 sb-web-01 | [S5] ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet  [Bild: tf-53-schritt-05.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Für 2026-10 existiert bereits eine nicht stornierte Zahlung dieser Bedarfsgemeinschaft; ggf. zuerst stornieren

## TF 54 WEB-NEG-OHNE-MONAT SWEET-NW-0054
status = VERIFIZIERT
hauptperson = Web, Negativ 54
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 3667
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-02, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung OHNE Zahlungsmonat anordnen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme eac6c67f83f3d710, Nachher-Prüfsumme eac6c67f83f3d710 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Vorgang angelegt
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0054]
    erwartet = 1 | ist = 1
V3: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0054]
    erwartet = 0 | ist = 0
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:28.309 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-54-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:07:29.207 sb-web-03 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0054)  [Bild: tf-54-schritt-02.png] -> OK — Vorgang SWEET-NW-0054 (Web, Negativ 54) mit Startbudget 1200 EUR angelegt
2026-10-15 10:07:30.037 sb-web-03 | [S3] SozialFall erfassen (RBS 2)  [Bild: tf-54-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 540 EUR) gespeichert
2026-10-15 10:07:31.691 sb-web-03 | [S4] Auszahlung OHNE Zahlungsmonat anordnen  [Bild: tf-54-schritt-04.png] -> OK — Anordnung ohne Zahlungsmonat abgewehrt — Fehlerdialog: Bitte den Zahlungsmonat wählen.

## TF 55 WEB-NEG-STORNO-SB SWEET-NW-0055
status = VERIFIZIERT
hauptperson = Web, Negativ 55
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4274
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

block: Anordnung + Freigabe
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1226.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=420.00, kdu_betrieb=80.00, kdu_heizung=80.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=580.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1086.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1086.00
bg_gesamtbedarf=1086.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1086.00
budget_rest_hypothetisch=140.00
budget_rest_erwartet=140.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 2e48d794b14d5bcb, Nachher-Prüfsumme 2e48d794b14d5bcb (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Genau eine Zahlungszeile einschließlich stornierter Zahlungen
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0055]
    erwartet = 1 | ist = 1
V3: OK | Zahlung bleibt freigegeben (kein Storno durch SB)
    sql    = SELECT ZAHLUNGSSTATUS FROM ZAHLUNG WHERE ZAHLUNGSMONAT = ? AND BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [2026-10, SWEET-NW-0055]
    erwartet = BEREIT | ist = BEREIT
V4: OK | Budget korrekt gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0055]
    erwartet = 140.00 | ist = 140
V5: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V6: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:30.883 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-55-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:07:31.738 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0055)  [Bild: tf-55-schritt-02.png] -> OK — Vorgang SWEET-NW-0055 (Web, Negativ 55) mit Startbudget 1226.00 EUR angelegt
2026-10-15 10:07:32.585 sb-web-02 | [S3] SozialFall erfassen  [Bild: tf-55-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 580.00 EUR) gespeichert
2026-10-15 10:07:33.234 sb-web-02 | [S4] Auszahlung für 2026-10 anordnen  [Bild: tf-55-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:07:33.513 sb-web-02 | [S5] Abmelden und als Kollegin/Kollege anmelden (Vier-Augen)  [Bild: tf-55-schritt-05.png] -> OK — Vier-Augen-Wechsel: angemeldet als Kollege sb-web-01
2026-10-15 10:07:34.213 sb-web-02 | [S6] Vorgang über die Suche finden und öffnen  [Bild: tf-55-schritt-06.png] -> OK — Vorgang SWEET-NW-0055 über Suchfeld ermittelt und geöffnet
2026-10-15 10:07:34.855 sb-web-02 | [S7] Zahlung freigeben (rechnerisch feststellen)  [Bild: tf-55-schritt-07.png] -> OK — Zahlung rechnerisch festgestellt und freigegeben (Status BEREIT)
2026-10-15 10:07:34.913 sb-web-02 | [S8] Storno-Knopf wird der Sachbearbeiter-Rolle korrekt vorenthalten  [Bild: tf-55-schritt-08.png] -> OK — Storno-Knopf für Sachbearbeiter korrekt ausgeblendet (nur Admin-Rolle)

## TF 56 WEB-NEG-BUDGET SWEET-NW-0056
status = VERIFIZIERT
hauptperson = Web, Negativ 56
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 4641
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

block: Bedarf (Budget bewusst zu klein)
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 951.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=450.00, kdu_betrieb=75.00, kdu_heizung=75.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=600.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1051.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1051.00
bg_gesamtbedarf=1051.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1051.00
budget_rest_hypothetisch=-100.00
budget_rest_erwartet=951.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 7348b5a0240fe71b, Nachher-Prüfsumme 7348b5a0240fe71b (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0056]
    erwartet = 0 | ist = 0
V3: OK | Budget unverändert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0056]
    erwartet = 951.00 | ist = 951
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:31.955 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-56-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:07:32.832 sb-web-01 | [S2] Neuen Vorgang mit Startbudget 951.00 EUR anlegen (bewusst zu klein)  [Bild: tf-56-schritt-02.png] -> OK — Vorgang SWEET-NW-0056 (Web, Negativ 56) mit Startbudget 951.00 EUR angelegt
2026-10-15 10:07:33.684 sb-web-01 | [S3] SozialFall erfassen (Bedarf 1051.00 EUR)  [Bild: tf-56-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 600.00 EUR) gespeichert
2026-10-15 10:07:35.837 sb-web-01 | [S4] Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet  [Bild: tf-56-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Der Zahlbetrag 1.051,00 EUR übersteigt das verfügbare Restbudget von 951,00 EUR

## TF 57 WEB-NEG-BUDGET SWEET-NW-0057
status = VERIFIZIERT
hauptperson = Web, Negativ 57
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 4163
ids = mitarbeiter=sb-web-03, adminKonto=web-admin, kollege=sb-web-01, sitzungKennung=sb-web-03, vorgangErstellt=true

### rechenwege

block: Bedarf (Budget bewusst zu klein)
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 971.00
p1_eingaben: rbs=2, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=370.00, kdu_betrieb=75.00, kdu_heizung=110.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=506.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=555.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=1061.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=1061.00
bg_gesamtbedarf=1061.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=1061.00
budget_rest_hypothetisch=-90.00
budget_rest_erwartet=971.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme be3f0b0b6043f781, Nachher-Prüfsumme be3f0b0b6043f781 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0057]
    erwartet = 0 | ist = 0
V3: OK | Budget unverändert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0057]
    erwartet = 971.00 | ist = 971
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:31.958 sb-web-03 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-57-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-03
2026-10-15 10:07:32.815 sb-web-03 | [S2] Neuen Vorgang mit Startbudget 971.00 EUR anlegen (bewusst zu klein)  [Bild: tf-57-schritt-02.png] -> OK — Vorgang SWEET-NW-0057 (Web, Negativ 57) mit Startbudget 971.00 EUR angelegt
2026-10-15 10:07:33.667 sb-web-03 | [S3] SozialFall erfassen (Bedarf 1061.00 EUR)  [Bild: tf-57-schritt-03.png] -> OK — SozialFall (RBS 2, KdU 555.00 EUR) gespeichert
2026-10-15 10:07:35.855 sb-web-03 | [S4] Auszahlung anordnen — BUDGET_ERSCHOEPFT erwartet  [Bild: tf-57-schritt-04.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Der Zahlbetrag 1.061,00 EUR übersteigt das verfügbare Restbudget von 971,00 EUR

## TF 58 WEB-NEG-OHNE-MONAT SWEET-NW-0058
status = VERIFIZIERT
hauptperson = Web, Negativ 58
bearbeiter = sb-web-02
bg_id = -
dauer_ms = 4126
ids = mitarbeiter=sb-web-02, adminKonto=web-admin, kollege=sb-web-03, sitzungKennung=sb-web-02, vorgangErstellt=true

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Auszahlung OHNE Zahlungsmonat anordnen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme f1d7dd4ef12ea641, Nachher-Prüfsumme f1d7dd4ef12ea641 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | Vorgang angelegt
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0058]
    erwartet = 1 | ist = 1
V3: OK | keine Zahlung entstanden
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0058]
    erwartet = 0 | ist = 0
V4: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:35.667 sb-web-02 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-58-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-02
2026-10-15 10:07:36.562 sb-web-02 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0058)  [Bild: tf-58-schritt-02.png] -> OK — Vorgang SWEET-NW-0058 (Web, Negativ 58) mit Startbudget 1200 EUR angelegt
2026-10-15 10:07:37.394 sb-web-02 | [S3] SozialFall erfassen (RBS 3)  [Bild: tf-58-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 540 EUR) gespeichert
2026-10-15 10:07:39.040 sb-web-02 | [S4] Auszahlung OHNE Zahlungsmonat anordnen  [Bild: tf-58-schritt-04.png] -> OK — Anordnung ohne Zahlungsmonat abgewehrt — Fehlerdialog: Bitte den Zahlungsmonat wählen.

## TF 59 WEB-NEG-DOPPELMONAT SWEET-NW-0059
status = VERIFIZIERT
hauptperson = Web, Negativ 59
bearbeiter = sb-web-01
bg_id = -
dauer_ms = 3788
ids = mitarbeiter=sb-web-01, adminKonto=web-admin, kollege=sb-web-02, sitzungKennung=sb-web-01, vorgangErstellt=true

### rechenwege

block: Erste Anordnung
zahlungsmonat = 2026-10
vermoegen = 0.00
kdu_warmwasser_abzug_anteil = 0
kdu_bg_grenze = 0.00
schonvermoegen = 10000.00
budget_start = 1076.00
p1_eingaben: rbs=3, merkzeichen_g=false, schwanger=false, entbindungsmonat=-, kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0, warmwasser=false, kdu_miete=320.00, kdu_betrieb=55.00, kdu_heizung=100.00, rente=0.00, erwerb=0.00, abz_steuern=0.00, abz_sv=0.00, abz_vers=0.00, abz_erwerb=0.00
p1_regelbedarf=451.00
p1_mehrbedarf_g=0.00
p1_mehrbedarf_schwanger=0.00
p1_mehrbedarf_alleinerziehend=0.00
p1_mehrbedarf_warmwasser=0.00
p1_kdu=475.00
p1_kdu_warmwasser_abzug=0.00
p1_gesamtbedarf=926.00
p1_freibetrag_erwerb=0.00
p1_absetzbetaetrag=0.00
p1_anrechenbar=0.00
p1_zahlbetrag=926.00
bg_gesamtbedarf=926.00
bg_anrechenbar=0.00
bg_verwertbares_vermoegen=0.00
bg_zahlbetrag=926.00
budget_rest_hypothetisch=150.00
budget_rest_erwartet=150.00

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 6cccd8793468ae27, Nachher-Prüfsumme 6cccd8793468ae27 (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | genau eine Zahlung je Vorgang und Monat
    sql    = SELECT COUNT(*) FROM ZAHLUNG WHERE BG_ID = (SELECT ID FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?)
    params = [SWEET-NW-0059]
    erwartet = 1 | ist = 1
V3: OK | Budget nur einmal gemindert
    sql    = SELECT BUDGET_REST FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0059]
    erwartet = 150.00 | ist = 150
V4: OK | Unabhängige Nachrechnung sämtlicher Rechenblöcke (Referenz 2026)
    sql    = -- INDEPENDENT_CALCULATION_2026: BigDecimal-Zweitimplementierung; sämtliche Personen und Zwischenwerte
    params = []
    erwartet = 0 Abweichungen | ist = 0 Abweichungen
    hinweis = 1 Rechenblöcke mit unabhängigen Konstanten und BigDecimal geprüft
V5: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:36.626 sb-web-01 | [S1] Anmeldung an der Weboberfläche  [Bild: tf-59-schritt-01.png] -> OK — Erfolgreich angemeldet als sb-web-01
2026-10-15 10:07:37.504 sb-web-01 | [S2] Neuen Vorgang anlegen (Aktenzeichen SWEET-NW-0059)  [Bild: tf-59-schritt-02.png] -> OK — Vorgang SWEET-NW-0059 (Web, Negativ 59) mit Startbudget 1076.00 EUR angelegt
2026-10-15 10:07:38.329 sb-web-01 | [S3] SozialFall erfassen  [Bild: tf-59-schritt-03.png] -> OK — SozialFall (RBS 3, KdU 475.00 EUR) gespeichert
2026-10-15 10:07:38.979 sb-web-01 | [S4] Erste Auszahlung für 2026-10 anordnen  [Bild: tf-59-schritt-04.png] -> OK — Monatliche Auszahlung für 2026-10 angeordnet (Vier-Augen-Warteschlange: ANGELEGT)
2026-10-15 10:07:39.626 sb-web-01 | [S5] ZWEITE Auszahlung für 2026-10 — VALIDATION erwartet  [Bild: tf-59-schritt-05.png] -> OK — Anordnung abgewehrt — Fehlerdialog: Für 2026-10 existiert bereits eine nicht stornierte Zahlung dieser Bedarfsgemeinschaft; ggf. zuerst stornieren

## TF 60 WEB-NEG-LOGIN SWEET-NW-0060
status = VERIFIZIERT
hauptperson = —
bearbeiter = sb-web-03
bg_id = -
dauer_ms = 781
ids = kollege=sb-web-01, adminKonto=web-admin, mitarbeiter=sb-web-03

### rechenwege

keine (testfall prueft ablauf-/sperrlogik, keine betragsberechnung)

### verifikation

V1: OK | UI-Fehlversuch ohne Fachänderung: Anmeldung mit FALSCHEM Passwort versuchen
    sql    = -- STATE_SNAPSHOT: SOZIAL_FALL, BEDARFSGEMEINSCHAFT, ZAHLUNG, BESCHEID, JOURNAL; vollständiger Vorher/Nachher-Vergleich
    params = []
    erwartet = unverändert | ist = unverändert
    hinweis = Vorher-Prüfsumme 5b91b99e37daf82f, Nachher-Prüfsumme 5b91b99e37daf82f (SHA-256 über alle Fachtabellen, erlaubte Einsichts-Audits ausgeklammert; gleiche Prüfsumme = unverändert)
V2: OK | kein Vorgang durch die abgewehrte Anmeldung entstanden
    sql    = SELECT COUNT(*) FROM BEDARFSGEMEINSCHAFT WHERE AKTENZEICHEN = ?
    params = [SWEET-NW-0060]
    erwartet = 0 | ist = 0
V3: OK | Globale Laufverifikation
    sql    = NICHT_SQL: Globale Laufverifikation
    params = []
    erwartet = 0 Fehler | ist = 0 Fehler
    hinweis = Einzelheiten stehen in den globalen Laufprüfungen

### protokoll

2026-10-15 10:07:36.637 sb-web-03 | [S1] Anmeldung mit FALSCHEM Passwort versuchen  [Bild: tf-60-schritt-01.png] -> OK — Anmeldung abgewehrt — Oberfläche meldet: Kennung oder Passwort ist falsch


## ki_pruefung_dateiuebergabe

dateiuebergabe_geprueft = false
fachpruefung_bestanden = false
Noch keine KI-Prüfung: Dateiübergabe und Fachprüfung sind ausstehend.

