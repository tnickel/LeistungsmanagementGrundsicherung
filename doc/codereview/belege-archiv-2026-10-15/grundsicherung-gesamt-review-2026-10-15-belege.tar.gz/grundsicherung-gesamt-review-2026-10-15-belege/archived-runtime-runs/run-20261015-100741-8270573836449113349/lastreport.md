# lasttest_gesamtreport

# lauf

automatik_bestanden = true
pruefumfang = Automatischer Last-/Stresslauf; KI-Stichprobe und Gesamtzertifikat werden separat bewertet
globale_pruefung = Pruefung[beschreibung=Global: Anzahl SWEET-Vorgänge, erwartet=30, ist=30, ok=true, hinweis=null, sql=null, parameter=[]]
globale_pruefung = Pruefung[beschreibung=Global: keine Übergabe ohne Freigabevermerk, erwartet=0, ist=0, ok=true, hinweis=null, sql=null, parameter=[]]
kategorie = LAST
modus = WEB
lauf_start = 2026-10-15T10:07:41.345810800
lauf_ende = 2026-10-15T10:08:29.381281800
dauer_s = 48
mitarbeiter = 3
auftraege = 30
seed = 20261015
denkzeit_ms = 0
db = jdbc:oracle:thin:@//localhost:1521/FREEPDB1

# ergebnis

gesamt = 30
verifiziert = 30
verifikation_nio = 0
fehlgeschlagen = 0
summe_verifizierter_auszahlungen_eur = 32814.00
dauer_ms_min = 2774
dauer_ms_avg = 3269
dauer_ms_max = 4347
durchsatz_auftraege_pro_min = 37.5

# je_szenario_typ

WEB-LAST-DURCHLAUF = anzahl 30 | verifiziert 30 | nio 0 | fehlgeschlagen 0 | avg_ms 3269

# je_mitarbeiter

sb-web-02 = erledigt 11 | avg_ms 3168
sb-web-03 = erledigt 10 | avg_ms 3193
sb-web-01 = erledigt 9 | avg_ms 3479

# hinweis

dokumentation = gekürzt (nur Aggregate); Einzelnachweise in den Protokolldateien des Lauf-Verzeichnisses (simulation.log, auftrag-*.log, db-verifikation.log, fehler.log)
