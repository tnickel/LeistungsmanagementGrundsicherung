# lasttest_gesamtreport

# lauf

automatik_bestanden = true
pruefumfang = Automatischer Last-/Stresslauf; KI-Stichprobe und Gesamtzertifikat werden separat bewertet
globale_pruefung = Pruefung[beschreibung=Global: Anzahl SWEET-Vorgänge, erwartet=120, ist=120, ok=true, hinweis=null, sql=null, parameter=[]]
globale_pruefung = Pruefung[beschreibung=Global: keine Übergabe ohne Freigabevermerk, erwartet=0, ist=0, ok=true, hinweis=null, sql=null, parameter=[]]
kategorie = LAST
modus = FACHSCHICHT
lauf_start = 2026-10-15T10:03:46.973094300
lauf_ende = 2026-10-15T10:03:49.997719100
dauer_s = 3
mitarbeiter = 8
auftraege = 120
seed = 20261015
denkzeit_ms = 0
db = jdbc:oracle:thin:@//localhost:1521/FREEPDB1

# ergebnis

gesamt = 120
verifiziert = 120
verifikation_nio = 0
fehlgeschlagen = 0
summe_verifizierter_auszahlungen_eur = 129659.00
dauer_ms_min = 35
dauer_ms_avg = 52
dauer_ms_max = 219
durchsatz_auftraege_pro_min = 2400.0

# je_szenario_typ

LAST-DURCHLAUF = anzahl 120 | verifiziert 120 | nio 0 | fehlgeschlagen 0 | avg_ms 52

# je_mitarbeiter

sb-sim-01 = erledigt 15 | avg_ms 53
sb-sim-02 = erledigt 15 | avg_ms 52
sb-sim-03 = erledigt 15 | avg_ms 52
sb-sim-04 = erledigt 15 | avg_ms 52
sb-sim-05 = erledigt 15 | avg_ms 52
sb-sim-06 = erledigt 15 | avg_ms 53
sb-sim-07 = erledigt 15 | avg_ms 53
sb-sim-08 = erledigt 15 | avg_ms 53

# hinweis

dokumentation = gekürzt (nur Aggregate); Einzelnachweise in den Protokolldateien des Lauf-Verzeichnisses (simulation.log, auftrag-*.log, db-verifikation.log, fehler.log)
