# stresstest_gesamtreport

# lauf

automatik_bestanden = true
pruefumfang = Automatischer Last-/Stresslauf; KI-Stichprobe und Gesamtzertifikat werden separat bewertet
globale_pruefung = Pruefung[beschreibung=Global: Anzahl SWEET-Vorgänge, erwartet=21, ist=21, ok=true, hinweis=null, sql=null, parameter=[]]
globale_pruefung = Pruefung[beschreibung=Global: keine Übergabe ohne Freigabevermerk, erwartet=0, ist=0, ok=true, hinweis=null, sql=null, parameter=[]]
globale_pruefung = Pruefung[beschreibung=Global Stress: exakt eine angelegte Zahlung je User, erwartet=21, ist=21, ok=true, hinweis=null, sql=null, parameter=[]]
globale_pruefung = Pruefung[beschreibung=Global Stress: keine zusätzlichen Zahlungen, erwartet=21, ist=21, ok=true, hinweis=null, sql=null, parameter=[]]
globale_pruefung = Pruefung[beschreibung=Global Stress: alle Fälle exakt Version 2, erwartet=21, ist=21, ok=true, hinweis=null, sql=null, parameter=[]]
globale_pruefung = Pruefung[beschreibung=Global Stress: vier Journalzeilen je User, erwartet=0, ist=0, ok=true, hinweis=null, sql=null, parameter=[]]
globale_pruefung = Pruefung[beschreibung=Global Stress: keine negativen Budgets, erwartet=0, ist=0, ok=true, hinweis=null, sql=null, parameter=[]]
globale_pruefung = Pruefung[beschreibung=Global Stress: Zahlungssumme entspricht allen erwarteten Anordnungen, erwartet=23133.00, ist=23133, ok=true, hinweis=null, sql=null, parameter=[]]
kategorie = STRESS
modus = FACHSCHICHT
lauf_start = 2026-10-15T10:03:50.491660600
lauf_ende = 2026-10-15T10:03:52.812044
dauer_s = 2
mitarbeiter = 4
auftraege = 21
seed = 20261015
denkzeit_ms = 0
db = jdbc:oracle:thin:@//localhost:1521/FREEPDB1

# ergebnis

gesamt = 42
verifiziert = 42
verifikation_nio = 0
fehlgeschlagen = 0
summe_verifizierter_auszahlungen_eur = 23133.00
dauer_ms_min = 15
dauer_ms_avg = 39
dauer_ms_max = 137
durchsatz_auftraege_pro_min = 1260.0

# je_szenario_typ

STRESS-ANLEGEN = anzahl 21 | verifiziert 21 | nio 0 | fehlgeschlagen 0 | avg_ms 41
STRESS-BEARBEITEN = anzahl 21 | verifiziert 21 | nio 0 | fehlgeschlagen 0 | avg_ms 37

# je_mitarbeiter

sb-sim-01 = erledigt 10 | avg_ms 40
sb-sim-02 = erledigt 10 | avg_ms 40
sb-sim-03 = erledigt 11 | avg_ms 38
sb-sim-04 = erledigt 11 | avg_ms 37

# hinweis

dokumentation = gekürzt (nur Aggregate); Einzelnachweise in den Protokolldateien des Lauf-Verzeichnisses (simulation.log, auftrag-*.log, db-verifikation.log, fehler.log)
