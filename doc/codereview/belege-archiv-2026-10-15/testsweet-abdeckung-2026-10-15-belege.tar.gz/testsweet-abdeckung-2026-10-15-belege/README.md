# Belege: testsweet-Abdeckung und Standard 100/100

Bericht: [testsweet-Abdeckung](../testsweet-abdeckung-2026-10-15.md).

`run-checks.ps1` baut und prüft beide Java-Module, führt die zusätzliche
Konfigurationsprüfung und Node aus und startet auf einem eigenen Oracle-Schema
100 positive sowie 100 negative Fachsimulatorfälle. `BuildDefaultReviewPackage.java`
erstellt daraus nur ein lokales Prüfpaket, ohne externen API-Aufruf.

`inspect-results.py` prüft die tatsächlichen XML-Dateien, ihre Hashes, Build- und
Quellenbindung, Berichtshashes, Simulatorzustände und die 100/100-Quote des Pakets.
`check-junit-reader.js` verwendet den produktiven JUnit-Zertifikatsleser.
`verification-summary.json` enthält die verdichteten Ergebnisse.

Laufskripte, kompakte JSON-Marker und Zusammenfassungen können versioniert werden.
Vollständige Logs, Surefire-XML, PDFs/Markdown-Berichte und das umfangreiche
Prüfpaket bleiben lokale Laufdaten. Die Verweise belegen den tatsächlich geprüften
lokalen Stand; sie behaupten keinen vollständigen Rohdatenexport in Git.
Der erste Fehlversuch bleibt separat erhalten. Zugangsdaten sind nicht enthalten;
die temporäre Oracle-Konfiguration wurde nach Entfernen des eigenen Schemas gelöscht.
Kein GLM-Urteil und kein Gesamtzertifikat wurden erzeugt.
