"""Prüft tatsächliche Laufmarker, XML, Quell-/Reporthashes und das lokale 100/100-Paket."""
from pathlib import Path
import hashlib
import json
import re
import xml.etree.ElementTree as ET

evidence = Path(__file__).resolve().parent
root = evidence.parents[2]

def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

steps = read_json(evidence / "check-results.json")
assert len(steps) == 8 and all(s["exitCode"] == 0 for s in steps), "Nicht alle Prüfschritte bestanden"
summary = {"java": [], "simulators": [], "glmVerdict": "NOT_RUN", "overallCertificate": "NOT_EXPORTED"}
fingerprints = set()
successful_main = set()
for name in ("main-db", "main-config", "testsweet-db"):
    marker = read_json(evidence / f"{name}-test-evidence.json")
    assert marker["state"] == "COMPLETED" and marker["buildEvidence"]["sourceArtifactsMatch"]
    fingerprints.add(marker["sourceSha256"])
    counts = dict.fromkeys(("tests", "failures", "errors", "skipped"), 0)
    for report in marker["reports"]:
        path = root / report["path"]
        assert sha(path) == report["sha256"], path
        suite = ET.parse(path).getroot()
        for key in counts:
            counts[key] += int(suite.attrib.get(key, 0))
        if name.startswith("main"):
            for case in suite.findall("testcase"):
                if not any(case.find(tag) is not None for tag in ("skipped", "failure", "error")):
                    successful_main.add((case.attrib["classname"], case.attrib["name"]))
    assert counts["failures"] == counts["errors"] == 0
    summary["java"].append({"name": name, "runId": marker["runId"], "counts": counts})
assert len(fingerprints) == 1
summary["sourceSha256"] = fingerprints.pop()
summary["sourceFiles"] = len(marker["sourceInventory"])
summary["sourceDrift"] = [item["path"] for item in marker["sourceInventory"]
                          if not (root / item["path"]).is_file() or sha(root / item["path"]) != item["sha256"]]
assert not summary["sourceDrift"]
summary["differentSuccessfulMainTests"] = len(successful_main)
node_log = (evidence / "node-tests.log").read_text(encoding="utf-8-sig")
summary["node"] = {key: int(re.search(rf"^# {key} (\d+)\r?$", node_log, re.M).group(1))
                   for key in ("tests", "pass", "fail", "skipped")}
assert summary["node"]["fail"] == summary["node"]["skipped"] == 0
for log_name, category in (("fach-default-positiv.log", "POSITIV"), ("fach-negativ-100.log", "NEGATIV")):
    text = (evidence / log_name).read_text(encoding="utf-8-sig")
    document = Path(re.search(r"^Markdown: (.+)\r?$", text, re.M).group(1).strip())
    if not document.is_absolute():
        document = root / document
    state = read_json(document.parent / "run-state.json")
    assert state["state"] == "PASS" and state["success"] and state["category"] == category
    assert state["totalCases"] == state["verifiedCases"] == state["completedCases"] == 100
    assert state["failedCases"] == state["verificationErrors"] == 0
    assert state["reportsComplete"] and state["logComplete"] and not state["evidenceErrors"]
    assert state["buildEvidence"]["sourceSha256"] == summary["sourceSha256"]
    assert state["buildEvidence"]["sourceArtifactsMatch"]
    for report in state["reports"]:
        assert sha(document.parent / report["path"]) == report["sha256"]
    summary["simulators"].append({key: state[key] for key in
        ("runId", "state", "category", "mode", "totalCases", "verifiedCases", "failedCases", "verificationErrors")})
package = read_json(evidence / "local-review-package.json")
assert package["positive"] == package["negative"] == 100 and package["uniqueCaseIds"] == 200
assert package["liveApiRequest"] is False and package["glmVerdict"] == "NOT_RUN"
manifest_path = Path(package["manifest"])
manifest = read_json(manifest_path)
assert manifest["selectedCases"] == {"POSITIV": 100, "NEGATIV": 100}
assert manifest["buildEvidence"]["sourceSha256"] == summary["sourceSha256"]
assert manifest["buildEvidence"]["sourceArtifactsMatch"]
summary["localPackage"] = {**package, "manifestSha256": sha(manifest_path)}
(evidence / "verification-summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(summary, indent=2, ensure_ascii=False))
