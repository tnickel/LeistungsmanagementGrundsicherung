param([Parameter(Mandatory=$true)][string]$EnvironmentFile)
$ErrorActionPreference = 'Stop'
$coverageRoot = (Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $coverageRoot
$coverageConnection = @{}
foreach ($coverageLine in Get-Content -LiteralPath $EnvironmentFile) {
    $coveragePair = $coverageLine.Split('=', 2)
    if ($coveragePair.Length -eq 2) { $coverageConnection[$coveragePair[0]] = $coveragePair[1] }
}
if ($coverageConnection['TX_USER'] -ne 'SWEET_COV_20261015') { throw 'Nur das eigene Abdeckungsschema verwenden.' }
foreach ($coverageKey in @('TX_URL','TX_USER','TX_PASS')) {
    [Environment]::SetEnvironmentVariable($coverageKey, $coverageConnection[$coverageKey], 'Process')
}
$coverageResults = @()
function Invoke-CoverageCheck([string]$Name, [scriptblock]$Action) {
    $coverageStart = [DateTimeOffset]::Now
    & $Action *> (Join-Path $PSScriptRoot "$Name.log")
    $coverageExit = $LASTEXITCODE
    $script:coverageResults += [ordered]@{name=$Name; startedAt=$coverageStart.ToString('o');
        finishedAt=[DateTimeOffset]::Now.ToString('o'); exitCode=$coverageExit; log="$Name.log"}
    $script:coverageResults | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $PSScriptRoot 'check-results.json')
    Write-Output "$Name exit=$coverageExit"
    if ($coverageExit -ne 0) { throw "Prüfung $Name fehlgeschlagen; vollständiges Log prüfen." }
}
Invoke-CoverageCheck 'main-install-db' { & mvn -B install '-Dstyle.color=never' }
Copy-Item -LiteralPath 'target/test-evidence.json' -Destination (Join-Path $PSScriptRoot 'main-db-test-evidence.json')
Remove-Item Env:TX_URL,Env:TX_USER,Env:TX_PASS
Invoke-CoverageCheck 'main-config-without-db' { & mvn -B '-Dtest=LmgConfigTest' test '-Dstyle.color=never' }
Copy-Item -LiteralPath 'target/test-evidence.json' -Destination (Join-Path $PSScriptRoot 'main-config-test-evidence.json')
foreach ($coverageKey in @('TX_URL','TX_USER','TX_PASS')) {
    [Environment]::SetEnvironmentVariable($coverageKey, $coverageConnection[$coverageKey], 'Process')
}
Invoke-CoverageCheck 'testsweet-db' { & mvn -B -f testsweet/pom.xml test '-Dstyle.color=never' }
Copy-Item -LiteralPath 'testsweet/target/test-evidence.json' -Destination (Join-Path $PSScriptRoot 'testsweet-db-test-evidence.json')
Invoke-CoverageCheck 'node-tests' {
    & node --test doc/testzertifikat-werkzeug/certificate-evidence.test.js doc/testzertifikat-werkzeug/llm-answer-parity.test.js doc/testzertifikat-werkzeug/llm-reference.test.js testsweet/src/test/js/llm-ui.test.js testsweet/src/test/js/produkt-ui-review.test.js
}
Invoke-CoverageCheck 'testsweet-classpath' {
    & mvn -B -f testsweet/pom.xml dependency:build-classpath "-Dmdep.outputFile=$PSScriptRoot/testsweet-classpath.txt" '-Dstyle.color=never'
}
$coverageCp = (Join-Path $coverageRoot 'testsweet/target/classes') + ';' + (Get-Content -Raw (Join-Path $PSScriptRoot 'testsweet-classpath.txt')).Trim()
Invoke-CoverageCheck 'fach-default-positiv' {
    & java -cp $coverageCp de.allgemein.testsweet.SweetMain run
}
Invoke-CoverageCheck 'fach-negativ-100' {
    & java -cp $coverageCp de.allgemein.testsweet.SweetMain run 10 100 42 0 NEGATIV
}
Invoke-CoverageCheck 'local-review-package-100-100' {
    & java -cp $coverageCp (Join-Path $PSScriptRoot 'BuildDefaultReviewPackage.java') $coverageRoot (Join-Path $PSScriptRoot 'local-review-package.json')
}
Write-Output 'Java-/Node-Prüfungen, 100 positive und 100 negative Simulatorfälle sowie lokales 100/100-Prüfpaket abgeschlossen.'
