import de.allgemein.testsweet.LlmReviewService;
import de.allgemein.lmg.web.Json;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Erstellt nur das lokale Prüfpaket aus frischen Simulatorberichten; kein API-Aufruf. */
public class BuildDefaultReviewPackage {
    public static void main(String[] args) throws Exception {
        Path root = Path.of(args[0]).toAbsolutePath().normalize();
        try (var service = new LlmReviewService(root)) {
            Map<String, Object> result = service.buildPackage(200);
            List<?> ids = (List<?>) result.get("selectedCaseIds");
            long positive = ids.stream().map(String::valueOf).filter(id -> id.startsWith("POSITIV:")).count();
            long negative = ids.stream().map(String::valueOf).filter(id -> id.startsWith("NEGATIV:")).count();
            if (positive != 100 || negative != 100 || new HashSet<>(ids).size() != 200) {
                throw new IllegalStateException("Prüfpaket enthält nicht genau 100 verschiedene Positiv- und 100 Negativfälle");
            }
            Map<String, Object> summary = new LinkedHashMap<>();
            summary.put("positive", positive); summary.put("negative", negative);
            summary.put("uniqueCaseIds", new HashSet<>(ids).size());
            summary.put("manifest", result.get("manifest"));
            summary.put("liveApiRequest", false);
            summary.put("glmVerdict", "NOT_RUN");
            Files.writeString(Path.of(args[1]), Json.write(summary), StandardCharsets.UTF_8);
            System.out.println(Json.write(summary));
        }
    }
}
