# Teilbericht Fachberechnung, Monatslogik, Bescheide, Geldfluss

Prüfer B. Produkt SDN.Leistung. Stand: Commit `37abfb6f3da841e440ab21a53fbffa7eadf7cd04`, Branch `main`. Bezugsmonate im Jahr 2026, soweit nichts anderes steht. Keine Produktänderung. Keine volle Maven-Suite. Keine Schreibtests auf der Entwicklerdatenbank. Keine Zugangsdaten.

Belegarten: **DYNAMISCH** heißt, der kompilierte Rechenkern (`Leistungsberechnung`, `Bewilligungsplan`) wurde in dieser Prüfung mit `jshell` ausgeführt. **STATISCH** heißt, der vollständige Codepfad ist gelesen. Ein Produkttest, der denselben Betrag erwartet, belegt nur Konsistenz mit dem Code. Historische Testzahlen und ältere Reviewberichte sind nicht verwendet.

## 1. Rechtsverifikation

Abgerufen am 2026-10-15 von gesetze-im-internet.de. Die Einzelnormen nennen im gelesenen Auszug meist kein eigenes Änderungsdatum. Wo die Übersichtsseite das letzte Änderungsgesetz nennt, ist es angegeben. Für Bezugsmonate 2026 gilt die jeweils abgerufene konsolidierte Fassung; die Regelbedarfsstufen zusätzlich die Tabellenzeile „1. Januar 2026“.

| Norm | Quelle | Für 2026 maßgeblicher Inhalt | Status |
|---|---|---|---|
| Anlage zu § 28 SGB XII | https://www.gesetze-im-internet.de/sgb_12/anlage.html | Ab 01.01.2026: Stufe 1 = 563, Stufe 2 = 506, Stufe 3 = 451, Stufe 4 = 471, Stufe 5 = 390, Stufe 6 = 357. Dieselben Beträge stehen schon in den Zeilen 01.01.2024 und 01.01.2025. Stufe 4: Beginn des 15. bis Vollendung des 18. Lebensjahres. Stufe 5: Beginn des 7. bis Vollendung des 14. Lebensjahres. Stufe 6: bis zur Vollendung des 6. Lebensjahres. Stufe 1 bis 3: erwachsene Personen. | verifiziert |
| § 30 Abs. 1 SGB XII | https://www.gesetze-im-internet.de/sgb_12/__30.html | 17 Prozent der maßgebenden Regelbedarfsstufe nur bei Altersgrenze nach § 41 Abs. 2 oder voller Erwerbsminderung und nachgewiesenem Merkzeichen G. | verifiziert |
| § 30 Abs. 2 SGB XII | dieselbe URL | Für werdende Mütter **nach der zwölften Schwangerschaftswoche** bis zum Ende des Monats, in welchen die Entbindung fällt: 17 Prozent. Das ist die 13. Schwangerschaftswoche, nicht der Beginn der 12. | verifiziert |
| § 30 Abs. 3 SGB XII | dieselbe URL | 36 Prozent der Regelbedarfsstufe 1 für ein Kind unter sieben Jahren oder für zwei oder drei Kinder unter sechzehn Jahren. 12 Prozent je Kind, **wenn die Voraussetzungen nach Nummer 1 nicht vorliegen**, höchstens 60 Prozent. | verifiziert |
| § 21 Abs. 3 SGB II | https://www.gesetze-im-internet.de/sgb_2/__21.html | Dort steht die Vergleichsklausel: 12 Prozent je Kind, **wenn sich dadurch ein höherer Prozentsatz als nach Nummer 1 ergibt**, höchstens 60 Prozent. Diese Klausel steht in § 30 Abs. 3 SGB XII nicht. | verifiziert, nur als Gegensatz |
| § 30 Abs. 6 und 7 SGB XII | §-30-URL | Abs. 6 deckelt die Summe der Absätze 1 bis 5 auf die maßgebende Regelbedarfsstufe. Abs. 7 liegt außerhalb: dezentral 2,3 / 2,3 / kein Satz / 1,4 / 1,2 / 0,8 Prozent der Stufen 1, 2, 3, 4, 5, 6. Höherer Messnachweis ist gesondert. | verifiziert |
| § 35 SGB XII | https://www.gesetze-im-internet.de/sgb_12/__35.html | Tatsächliche Aufwendungen, soweit angemessen. Karenzzeit ein Jahr für die Unterkunft, davon ausgenommen Beträge über dem Eineinhalbfachen. Absenkung in der Regel längstens sechs Monate. Abs. 5: Heizung umfasst zentrale Warmwasserversorgung; eine Absetzungsregel fehlt. Abs. 7 erlaubt eine Gesamtangemessenheitsgrenze. | verifiziert |
| § 42a SGB XII | https://www.gesetze-im-internet.de/sgb_12/__42a.html | KdU nach dem Vierten Abschnitt des Dritten Kapitels, mit eigenen Regeln für Wohnung, besonderen Wohnraum und sonstige Unterkunft sowie für die Aufteilung in Mehrpersonenhaushalten. | verifiziert |
| § 82 SGB XII | https://www.gesetze-im-internet.de/sgb_12/__82.html | Abs. 2: Steuern, Pflichtbeiträge, angemessene Versicherungen, notwendige Erwerbsausgaben. Abs. 3 Satz 1: ferner 30 Prozent des Einkommens aus selbständiger und nichtselbständiger Tätigkeit, höchstens 50 Prozent der Regelbedarfsstufe 1. Satz 2: abweichende Werkstattregel. Abs. 4: zusätzliche Altersvorsorge. | verifiziert |
| § 43 Abs. 1 SGB XII | https://www.gesetze-im-internet.de/sgb_12/__43.html | Einkommen nach §§ 82 bis 84, Vermögen nach §§ 90 und 91. Einkommen und Vermögen des nicht getrennt lebenden Partners sind zu berücksichtigen, soweit sie dessen notwendigen Lebensunterhalt übersteigen. | verifiziert |
| § 90 Abs. 2 Nr. 9 SGB XII | https://www.gesetze-im-internet.de/sgb_12/__90.html | Kleinere Barbeträge oder sonstige Geldwerte sind geschont; die Beträge setzt die Verordnung. | verifiziert |
| § 1 DVO zu § 90 Abs. 2 Nr. 9 | https://www.gesetze-im-internet.de/bshg_88abs2dv_1988/__1.html | 10.000 EUR je dort genannte volljährige Person und je alleinstehende minderjährige Person; 500 EUR je überwiegend unterhaltene Person. Alleinstehend ist eine minderjährige Person, wenn sie unverheiratet ist und ihr Anspruch nicht vom Vermögen der Eltern abhängt. Übersichtstext: zuletzt geändert durch Art. 9 des Gesetzes vom 16.12.2022, BGBl. I S. 2328. | Wortlaut verifiziert; Änderungsdatum aus der Übersichtsseite |
| § 44 SGB XII | https://www.gesetze-im-internet.de/sgb_12/__44.html | Antrag. Rückwirkung auf den Ersten des Monats der Antragstellung. Bewilligung in der Regel für zwölf Monate. Wiederkehrende Bedarfe monatlich im Voraus. | verifiziert |
| § 48 SGB X | https://www.gesetze-im-internet.de/sgb_10/__48.html | Verwaltungsakt mit Dauerwirkung ist bei wesentlicher Änderung aufzuheben, grundsätzlich für die Zukunft, in den genannten Fällen vom Änderungszeitpunkt an. | verifiziert |
| § 36 SGB X | https://www.gesetze-im-internet.de/sgb_10/__36.html | Schriftliche oder elektronische Belehrung über Rechtsbehelf, Stelle, Sitz, Frist und Form. | verifiziert |
| § 37 Abs. 2 SGB X | https://www.gesetze-im-internet.de/sgb_10/__37.html | Inlandspost: bekannt gegeben am vierten Tag nach Aufgabe zur Post. Satz 3: das gilt nicht, wenn der Zugang fehlt oder später liegt. | verifiziert |
| § 84 SGG | https://www.gesetze-im-internet.de/sgg/__84.html | Widerspruch binnen eines Monats, schriftlich, in elektronischer Form nach § 36a Abs. 2 SGB I, schriftformersetzend nach § 36a Abs. 2a SGB I und § 9a Abs. 5 OZG, oder zur Niederschrift. Abs. 2: Fristwahrung auch bei anderer inländischer Behörde, Versicherungsträger oder deutscher Konsularbehörde. | verifiziert |
| § 36a Abs. 2 und 2a SGB I | https://www.gesetze-im-internet.de/sgb_1/__36a.html | Elektronische Form mit qualifizierter Signatur; schriftformersetzende Wege, darunter § 9a Abs. 5 OZG. | verifiziert |
| § 9a Abs. 5 OZG | https://www.gesetze-im-internet.de/ozg/__9a.html | Online-Formular nach Identitätsnachweis über ein Nutzerkonto ersetzt die Schriftform. | verifiziert |
| § 65a SGG, § 73 Abs. 1 SGG, § 87 SGG | jeweilige Einzelnorm | Elektronische Klageeinreichung; Selbstführung des Rechtsstreits vor dem Sozialgericht; Monatsfrist, nach Vorverfahren ab Bekanntgabe des Widerspruchsbescheids. | verifiziert |
| Wissenschaftliche Dienste, WD 6-046/24 | im Code zitiert, hier nicht abgerufen | — | **UNVERIFIZIERT** |

`README.md` Zeile 137 sagt „17 % ab der 12. Schwangerschaftswoche“. Das ist gegenüber § 30 Abs. 2 und gegenüber der Maske falsch. Die Maske (`src/main/resources/webapp/index.html`, `app.js`) sagt „ab der 13. SSW (nach Vollendung der 12. Woche)“. Der Rechenkern prüft keine Schwangerschaftswoche; das gesetzte Merkmal gilt als bereits erfüllte Voraussetzung.

`README.md` Zeile 138 beschreibt den Alleinerziehendenmehrbedarf mit „sonst 12 % je minderjähriges Kind“. Das entspricht der Ausschlussstruktur des § 30 Abs. 3 Nr. 2. Der Code macht daraus einen Vergleich beider Sätze. `README.md` Zeile 141 sagt, ein Warmwasser-Abzug sei bei zentraler Erzeugung konfigurierbar. § 35 Abs. 5 enthält keine Absetzung, und der Code zieht nicht ab.

## 2. Unabhängige Sollwerte

Grundlagen, vor dem Blick auf Testerwartungen festgehalten: Regelbedarfe der Anlage ab 01.01.2026. Prozentsätze kaufmännisch auf den Cent (`HALF_UP`). Freibetragsdeckel = 50 Prozent von 563,00 = 281,50. Die 30-Prozent-Rechnung erreicht diesen Deckel zuerst bei 938,32 EUR Brutto: 938,31 EUR ergeben 281,49; 938,32 EUR und 938,33 EUR ergeben 281,50. Anrechenbar ohne Absetzbeträge: 938,31 − 281,49 = 656,82; 938,32 − 281,50 = 656,82; 938,33 − 281,50 = 656,83.

Alleinerziehendenmehrbedarf nach dem abgerufenen Wortlaut: Liegt Nummer 1 vor, bleibt es bei 36 Prozent = 202,68 EUR. Nummer 2 mit 12 Prozent je minderjährigem Kind und Deckel 60 Prozent = 337,80 EUR gilt dann nicht. Nummer 1 liegt vor bei einem Kind unter sieben Jahren oder bei zwei oder drei Kindern unter sechzehn Jahren. Ein weiteres minderjähriges Kind im 16. oder 17. Lebensjahr beseitigt die Tatsache nicht, dass zwei oder drei Kinder unter sechzehn im Haushalt leben.

### (a) Alleinerziehend, Erwerb an der Freibetragsgrenze

Elternteil Stufe 1, Bruttoerwerb 938,32 EUR, keine Absetzbeträge, keine KdU, kein Vermögen. Kinder sind eigene Mitglieder ohne Einkommen. Schonvermögen bleibt unberührt, weil das Vermögen 0 ist.

| Haushalt | Zähler unter 7 / unter 16 / minderjährig | Kinderstufen | Soll-Mehrbedarf | Soll-Zahlbetrag der BG | Ist des Rechenkerns |
|---|---|---|---|---|---|
| Vier Minderjährige, keines unter 7, alle unter 16 | 0 / 4 / 4 | 4 × Stufe 5 = 1.560,00 | 270,24 (Nr. 1 liegt nicht vor) | 1.736,42 | derselbe Mehrbedarf, statisch; BG-Summe rechnerisch |
| Vier Minderjährige, eines unter 6 und drei im Alter 7 bis 13 | 1 / 4 / 4 | 357,00 + 3 × 390,00 = 1.527,00 | 202,68, weil ein Kind unter 7 vorhanden ist | 1.635,86 | Mehrbedarf 270,24; Zahlbetrag **1.703,42** |
| Drei unter 16 und ein Jugendlicher Stufe 4 | 0 / 3 / 4 | 3 × 390,00 + 471,00 = 1.641,00 | 202,68, weil drei Kinder unter 16 vorhanden sind | 1.749,86 | Mehrbedarf 270,24; Zahlbetrag **1.817,42** |
| Sechs Kinder bis zur Vollendung des 6. Lebensjahres | 6 / 6 / 6 | 6 × 357,00 = 2.142,00 | 337,80 (sechs Kinder sind weder „ein Kind“ noch „zwei oder drei“) | 2.385,98 | **2.385,98** |
| Drei unter 16 und drei Jugendliche Stufe 4 | 0 / 3 / 6 | 3 × 390,00 + 3 × 471,00 = 2.583,00 | 202,68 | 2.691,86 | Mehrbedarf 337,80; Zahlbetrag **2.826,98** |

Die ausgeführten Ist-Zahlbeträge stammen aus `jshell` gegen `target/classes`. Differenz in den fehlerhaften Zeilen: 67,56 EUR oder 135,12 EUR je Monat, identisch mit der Differenz der Mehrbedarfe, weil Einkommen und KdU gleich bleiben.

### (b) Schwangerschaft, Entbindungsmonat 2026-06

Stufe 1, sonst keine Merkmale, kein Einkommen, keine KdU. Soll: 17 Prozent = 95,71. Juni 2026, der Entbindungsmonat, bleibt 658,71. Juli 2026 ist 563,00. Ist, dynamisch über `Bewilligungsplan.faelleFuerMonat`: Juni-Merkmal bleibt gesetzt, Zahlbetrag 658,71; Juli-Merkmal entfällt, Zahlbetrag 563,00.

### (c) Vermögen einen Cent über dem Schonvermögen

Eine erwachsene Person Stufe 1, Bedarf 563,00, Schonvermögen 10.000,00. Vermögen 10.000,01. Soll verwertbar 0,01. Erste Zahlung 562,99, Bestand danach 10.000,00. Folgemonat verwertbar 0,00 und Zahlung 563,00. Storno bucht den dokumentierten Einsatz 0,01 zurück, Bestand wieder 10.000,01. Dynamisch bestätigt sind Betrag und Monatsplan. Die Rückbuchung ist statisch: Storno addiert `ZAHLUNG.VERMOEGENSEINSATZ`, keine Neuberechnung.

Grenze genau 10.000,00: verwertbar 0,00, Zahlung 563,00, kein Verbrauch. Grenze genau deckend, Vermögen 10.563,00: verwertbar 563,00, Zahlbetrag 0,00. Der Monatsplan lässt den Bestand in beiden Monaten bei 10.563,00. Der Verbrauch beginnt in diesem Zweig nicht.

### (d) Obergrenze § 30 Abs. 6

Saubere Konstellation, in der Nummer 1 nicht vorliegt: Stufe 6, Merkzeichen G, schwanger, acht Kinder unter 16, keines unter 7, dezentrales Warmwasser. 17 Prozent von 357,00 = 60,69. Alleinerziehend über Nummer 2: 96 Prozent, gedeckelt auf 337,80. Summe der Absätze 1 bis 5 = 459,18, gekappt auf 357,00. Warmwasser 2,86 kommt hinzu. Mehrbedarf 359,86. Ein weiterer Cent in der ungedeckelten Summe bleibt nach der Kappung bei 357,00 plus 2,86. Dieser Sollwert trifft den Code. Der vorhandene Test erwartet 359,86 und belegt damit nur die Übereinstimmung.

Dieselbe Kappung auf Stufe 2 mit drei Kindern unter 16 und drei älteren Minderjährigen mischt den Alleinerziehendenfehler ein. Gesetzlich bleiben 86,02 + 86,02 + 202,68 = 374,72 unter 506,00; mit Warmwasser 11,64 sind es 386,36. Der Kern rechnet 337,80 statt 202,68, kappt 509,84 auf 506,00 und addiert 11,64. Dynamisches Ist: **517,64**. Zu viel bleiben 131,28 EUR, weil die Obergrenze 3,84 EUR der überhöhten 135,12 EUR schluckt.

### (e) KdU an der Grenze 500,00

Stufe 1, Miete 400,00, Betrieb 50,00. Heizung 50,00: anerkannt 500,00, Zahlbetrag 1.063,00, nicht unangemessen. Heizung 50,01: anerkannt weiter 500,00, Zahlbetrag 1.063,00, unangemessen. Heizung 49,99: anerkannt 499,99, Zahlbetrag 1.062,99. Dynamisch bestätigt. Zwei Personen mit 500,00 und 300,01 gegen dieselbe Grenze ergeben in beiden Reihenfolgen den Zahlbetrag 1.569,00. Die Zuordnung des Überschusses wechselt mit der Personenreihenfolge.

Heizung 100,00 und Parameter `warmwasserAbzugHeizungProzent = 0,20`: Abzug 0,00, KdU 500,00, Zahlbetrag 1.063,00, identisch zum Parameter 0. Dynamisch bestätigt.

### (f) Zwei Satzstände

Amtlich sind 2025 und 2026 gleich hoch. Ein Jahreswechsel mit diesen Beträgen ändert den Zahlbetrag nicht. Der Code wählt je Monat die Zeile mit dem größten `GUELTIG_AB`, das nicht nach dem Monat liegt. Mit zwei künstlichen Ständen, 562,00 ab 2025-01 und 563,00 ab 2026-01, liefert der Plan dynamisch 562,00 für 2025-12 und 563,00 für 2026-01. Der Seed enthält nur die Zeile 2026-01. Ein Bezugsmonat vor dieser Zeile endet fachlich mit fehlendem Satzstand.

## 3. Matrix

| Norm und Fassung | Regel für Bezugsmonat 2026 | Modellannahme | Codepfad | Unabhängiger Soll | Testnachweis | Urteil |
|---|---|---|---|---|---|---|
| Anlage zu § 28, Zeile 01.01.2026 | 563 / 506 / 451 / 471 / 390 / 357 | Satz steht in `SATZSTAND`, nicht im Code. `REFERENZ_2026` ist nur der seedgleiche Fallback. | `SatzstandDao.findeFuerMonat` 24–37; `Satzstand.REFERENZ_2026` 28–30; Seed `lmg_seed.sql` 8–10 | Beträge wie Anlage | Seed und Konstante stimmen mit der Anlage überein. Kein DB-Lesebeleg in dieser Prüfung. | bestätigt |
| Stufe und Alter | Stufe 6 endet mit dem 6. Lebensjahr; „unter sieben“ ist weiter | Kein Geburtsdatum. Kinderzähler und Stufe sind getrennte Eingaben. | `SozialFall`; Maske `app.js` 478–485; Schonvermögen `Leistungsberechnung` 253–261 | Stufe darf die Altersgrenze des § 30 Abs. 3 nicht ersetzen | Zähler werden nicht aus der Stufe abgeleitet. Statisch. | bestätigt, mit Proxy beim Vermögen |
| § 30 Abs. 1 | 17 Prozent nur mit Alters- oder Erwerbsminderungsstatus und Merkzeichen G | Ein Wahrheitswert gilt als vollständiger Nachweis | `Leistungsberechnung` 178–180; Maske `app.js` 518–519 | ohne den Personenstatus 0 | kein Test der Personenstatusvoraussetzung gefunden | Modellgrenze, siehe INFO |
| § 30 Abs. 2, 13. SSW | nach der 12. Woche bis zum Ende des Entbindungsmonats, 17 Prozent | Merkmal setzt die Woche voraus. Ohne Monat läuft das Merkmal weiter. | `Bewilligungsplan.faelleFuerMonat` 34–44; Aufruf in Service 295–296 und Saga 240–241, 398 | Juni 658,71; Juli 563,00 | dynamisch 658,71 / 563,00 | bestätigt |
| § 30 Abs. 3 | 36 Prozent, und nur sonst 12 Prozent je Kind, Deckel 60 Prozent | Vergleich des höheren Satzes, auch wenn Nummer 1 vorliegt | `mehrbedarfAlleinerziehend` 231–244 | 202,68 sobald Nummer 1 vorliegt | `LeistungsberechnungTest` 245–254 erwartet 270,24 und 337,80. Das ist Konsistenz mit dem Fehler. | **Implementierungsfehler, FB-20261015-01** |
| § 30 Abs. 6 | Summe Abs. 1–5 höchstens die eigene Regelbedarfsstufe | Warmwasser bleibt außerhalb | `Leistungsberechnung` 189–193 | Stufe 6 mit acht Kindern unter 16: 359,86 | Test erwartet 359,86; Komponenten unabhängig gerechnet | bestätigt |
| § 30 Abs. 7 | dezentrale Sätze; Stufe 3 ohne Satz | kein Messnachweis für höhere Kosten | Anteile 79–85 | 12,95 / 11,64 / 0,00 / 6,59 / 4,68 / 2,86 | Stufentests erwarten diese Cents | bestätigt |
| § 35 Abs. 5 | zentrale Warmwasserkosten bleiben Heizbedarf | Altparameter wird geprüft und nicht gerechnet | `Leistungsberechnung` 195–198; `LmgConfig.kduParameter` 180–184 | Abzug 0,00 auch bei 0,20 | dynamisch beide Zahlbeträge 1.063,00 | bestätigt; README Zeile 141 ist falsch |
| § 35 Abs. 1, 3, 7 und § 42a | Angemessenheit, Karenz, Absenkung, Haushaltsanteil | eine Grenze auf die Summe, sofort, ohne Karenz und ohne Sechsmonatsfrist | Schleife `Leistungsberechnung` 141–148 | exakt 1.063,00; ein Cent darüber weiter 1.063,00 mit Kennzeichen | dynamisch bestätigt | Modellgrenze, sobald eine Grenze gesetzt ist. Default 0 lässt die KdU unverändert. |
| Personenreihenfolge | Gesamtbetrag der Grenze ist reihenfolgeunabhängig | Überschuss trifft die später gelesenen Personen | `SozialFallDao` ordnet nach `ID` | Summe 1.569,00 in beiden Reihenfolgen | dynamisch gleiche Summe, wechselnde Zuordnung | Betrag bestätigt |
| § 82 Abs. 2 und 3 | Absetzungen und ferner 30 Prozent vom Erwerbseinkommen, Deckel halbe Stufe 1 | Basis ist das Bruttofeld. Werkstattregel und Abs. 4 fehlen. Negative Einkommen werden je Person auf 0 gesetzt. | `erwerbsfreibetrag` 271–276; Summe 210–215 | 938,32 → Freibetrag 281,50; 938,31 → 281,49 | dynamisch bestätigt | Abs. 3 Satz 1 bestätigt. Satz 2 und Abs. 4 Modellgrenze. |
| § 43 Abs. 1, § 90, § 1 DVO | 10.000 je volljährige berechtigte Person, 500 je überwiegend unterhaltene Person; verwertbares Vermögen ist einzusetzen | Stufe 1–3 zählt als volljährig, Stufe 4–6 als unterhalten. Ohne Stufe 1–3 einmal 10.000. Verbrauch nur bei positiver Zahlung. | `schonvermoegen` 253–261; Fortschreibung Service 343–346 und `Bewilligungsplan` 68–70 | 10.000,01 → erste Zahlung 562,99, danach 563,00 | dynamisch für die knappe Überschreitung. Der deckende Bestand 10.563,00 bleibt stehen. | knapper Fall bestätigt; deckender Fall FB-20261015-04 |
| § 44 Abs. 3 | in der Regel zwölf Monate | länger wird abgelehnt; vorläufige sechs Monate werden nicht erzwungen | `pruefeBewilligungszeitraum` 801–810; Plan 52–55 | 1 bis 12 Monate | statisch | bestätigt |
| § 44 Abs. 1 und 2 | Antrag, Rückwirkung auf den Monatsersten | kein Antragsdatum | kein Feld | — | — | nicht modelliert |
| § 48 SGB X | Änderung durch neuen Verwaltungsakt; bis dahin gilt der erteilte Bescheid | keine Aufhebung in der Sachbearbeitung. Zahlung verlangt Gleichheit von aktueller Rechnung und Snapshot. Ein überschneidender neuer Bescheid wird abgelehnt. | `BescheidPaymentBinding` 19–36 und 95–100; Aufhebung nur in der Saga-Kompensation | erteilter Monatsbetrag bleibt zahlbar, bis ein Änderungsbescheid ihn ersetzt | statisch | **FB-20261015-02** |
| § 36 SGB X, § 84 SGG, § 36a SGB I, § 9a Abs. 5 OZG, § 37 Abs. 2 SGB X | Frist, Form einschließlich elektronischer Form, Stelle, Vier-Tage-Zugang | Belehrungstext, ohne berechnetes Fristende und ohne die Widerlegung bei fehlendem oder späterem Zugang | `BescheidGenerator.belehrungText` 389–421 | Wortlaut deckt § 84 Abs. 1 | statisch gegen den abgerufenen Wortlaut | im Kern bestätigt |
| Snapshot und Nachdruck | erteilter Bescheid bleibt der erteilte Bescheid | Version 3 speichert Plan und HTML. Nachdruck gibt das HTML zurück. | `BescheidDokument.snapshot` 14–23; `BerechnungsSnapshot` 75–84 und 203–207; Druckpfad `SozialLeistungsService` 679–681 | kein stiller Austausch | statisch | HTML bestätigt; Eingabemerkmale im JSON unvollständig, FB-20261015-10 |
| Monatliche Eindeutigkeit, Idempotenz, Vier-Augen, Kassenmenge | eine wirksame Zahlung je BG und Monat; Wiederholung derselben Vorgangsnummer bucht nicht erneut; ANGELEGT, dann andere Person, dann Übergabe der gesperrten Menge | Service und Saga rechnen dieselbe Funktion. Die Maskenvorschau bindet den Monat an die JVM-Uhr. | Service 257–361; Saga 389–487; Index `lmg_schema.sql` 219–221; Vorschau 759–764 | gleiche Konstellation, gleicher Monat: gleicher Zahlbetrag | Formel dynamisch; Buchungspfade statisch | Formel bestätigt. Monatsbindung der Vorschau FB-20261015-03. |

## 4. Befunde

### FB-20261015-01 — KRITISCH — STATISCH für den Pfad, DYNAMISCH für die Beträge

`src/main/java/de/allgemein/lmg/calc/Leistungsberechnung.java`, Zeilen 231–244.

§ 30 Abs. 3 Nr. 2 SGB XII in der abgerufenen Fassung gewährt 12 Prozent je Kind nur, wenn die Voraussetzungen der Nummer 1 nicht vorliegen. Der Code setzt bei einem Kind unter 7 oder bei zwei bis drei Kindern unter 16 den höheren Wert aus 36 Prozent und 12 Prozent je minderjährigem Kind an und deckelt danach auf 60 Prozent. Das ist die Vergleichsklausel des § 21 Abs. 3 SGB II, nicht der Wortlaut des § 30 Abs. 3 SGB XII. Die im Quellkommentar genannte Ausarbeitung WD 6-046/24 ist hier UNVERIFIZIERT und ersetzt die Primärnorm nicht.

Soll und Ist, Erwerb 938,32 EUR, sonst keine Abzüge:

- Drei Kinder unter 16 und ein weiteres minderjähriges Kind: Soll-Mehrbedarf 202,68 und Soll-Zahlbetrag 1.749,86. Ist-Mehrbedarf 270,24 und Ist-Zahlbetrag 1.817,42. Zu viel: 67,56 EUR je Monat.
- Drei Kinder unter 16 und drei weitere Minderjährige: Soll 202,68 und 2.691,86. Ist 337,80 und 2.826,98. Zu viel: 135,12 EUR je Monat.
- Vier Minderjährige mit einem Kind unter 7: Soll 202,68 und 1.635,86. Ist 270,24 und 1.703,42. Zu viel: 67,56 EUR je Monat.

`LeistungsberechnungTest`, Zeilen 245–254, erwartet diese höheren Beträge. Der Test beweist die beabsichtigte Implementierung, nicht die Norm. Service, Saga, Vorschau und Snapshot verwenden dieselbe Funktion. Dieselben Haushalte werden dort um denselben Centbetrag zu hoch bewilligt und ausgezahlt. Die Obergrenze des Absatzes 6 kann einen kleinen Teil schlucken; in der Stufe-2-Mischung bleiben 131,28 EUR übrig.

`README.md` Zeile 138 („sonst 12 %“) beschreibt die gesetzliche Ausschlussstruktur. Der Code weicht von README und Norm ab.

### FB-20261015-02 — MAJOR — STATISCH

`src/main/java/de/allgemein/lmg/service/BescheidPaymentBinding.java`, Zeilen 19–36 und 95–100.

Sobald irgendein Bescheid existiert, wird eine Zahlung abgelehnt, wenn die aktuelle Rechnung nicht centgenau dem gespeicherten Monatsbetrag entspricht. Ein zweiter erteilter Bescheid mit überschneidendem Zeitraum wird ebenfalls abgelehnt. Eine Aufhebung gibt es in der Sachbearbeitung nicht; sie hängt an der Saga-Kompensation. Nach einer Änderung von Einkommen, Miete oder Satzstand ist der bestandskräftige Betrag nicht mehr auszahlbar, und ein Änderungsbescheid nach § 48 SGB X kann den Zeitraum nicht neu festsetzen. Der gespeicherte Bescheid wird nicht still überschrieben. Der Geldfluss stoppt.

### FB-20261015-03 — MAJOR — STATISCH

`src/main/java/de/allgemein/lmg/service/SozialLeistungsService.java`, Zeilen 759–764.

Vorgangsliste und Vorgangsdetail rechnen mit `YearMonth.now()`, also dem aktuellen JVM-Monat. Auszahlung, Saga und Bescheidplan rechnen den beauftragten Monat. Dieselbe Fallkonstellation zeigt deshalb auf der Maske einen anderen Betrag als die Zahlung für einen anderen Monat. Im Beispiel Entbindung 2026-06 beträgt die Differenz ab Juli 95,71 EUR. Die Buchung selbst verwendet den Auftragsmonat und den Satzstand dieses Monats.

### FB-20261015-04 — MAJOR — DYNAMISCH für den Plan, STATISCH für die Buchung

`src/main/java/de/allgemein/lmg/calc/Bewilligungsplan.java`, Zeilen 62–70. `SozialLeistungsService.ordneAuszahlungAn`, Zeilen 301–305 und 343–346.

Der über dem Schonvermögen liegende Betrag wird nur verbucht, wenn der Zahlbetrag positiv ist. Decken 10.563,00 EUR einen Bedarf von 563,00 EUR genau, ist der Zahlbetrag 0,00 und der Bestand im Folgemonat weiterhin 10.563,00. Die Auszahlung lehnt den Fall ab, bevor sie den Bestand mindert. Der knappe Fall 10.000,01 EUR wird richtig auf 562,99 und im Folgemonat auf 563,00 fortgeschrieben. Der deckende und der überschießende Fall bleiben im System dauerhaft ohne Zahlung und ohne Verbrauch.

### FB-20261015-05 — MAJOR — STATISCH

`Leistungsberechnung.mehrbedarfAlleinerziehend`, Zeilen 231–244, aufgerufen je SozialFall. `pruefeUndNormalisiereFall`, Zeilen 814–849.

§ 30 Abs. 3 setzt voraus, dass die Person allein für Pflege und Erziehung sorgt. Der Mehrbedarf hängt nur an den Zählern des jeweiligen SozialFalls. Ein zweiter Erwachsener mit denselben Zählern erhält denselben Betrag noch einmal, bis zu weiteren 337,80 EUR. Die Zähler werden nicht mit den Mitgliedern, deren Stufen oder einem einzelnen Elternteil abgeglichen. `Math.max` hebt einen zu kleinen äußeren Zähler an; widersprüchliche Zähler werden nicht abgelehnt.

### FB-20261015-06 — MINOR — STATISCH, Norm verifiziert

`README.md`, Zeile 137.

Die README nennt den Schwangerschaftsmehrbedarf ab der 12. Schwangerschaftswoche. § 30 Abs. 2 und die Maske nennen den Zeitraum nach der zwölften Woche. Der Rechenkern verändert dadurch keinen Cent; falsch ist die Projektbeschreibung.

### FB-20261015-07 — MINOR — DYNAMISCH für die Wirkungslosigkeit, Norm verifiziert

`README.md`, Zeile 141. `Leistungsberechnung`, Zeilen 195–198.

Die README beschreibt einen konfigurierbaren Abzug zentraler Warmwasserkosten. § 35 Abs. 5 nimmt diese Kosten in den Heizbedarf auf und ordnet keine Absetzung an. Der Parameter `lmg.kdu.warmwasserabzug` wird gelesen und auf den Bereich 0 bis 1 geprüft. In der Rechnung ist der Abzug fest 0,00. Bei Heizung 100,00 und Parameter 0,20 bleibt der Zahlbetrag 1.063,00. Das ist fachlich zur SGB-XII-Norm passend. Falsch ist die README, nicht der Rechenkern.

### FB-20261015-08 — MINOR — STATISCH

`SozialLeistungsService.wiederholeAuszahlung`, Zeilen 711–727.

Dieselbe Vorgangsnummer mit ausdrücklich anderer IBAN, anderem BIC oder anderem Namen wird abgelehnt. Leere Bankfelder überspringen den Vergleich. Eine verlorene Antwort ohne Bankdaten gilt auch dann als Wiederholung, wenn der gespeicherte Auftrag eine abweichende Bankverbindung trägt. Eine zweite Zahlung entsteht dabei nicht.

### FB-20261015-09 — MINOR — STATISCH

`SozialLeistungsService.storniereZahlung`, Zeilen 542–568.

Anlage, Änderung, Bescheid, Freigabe, neue Zahlung und Kassenübergabe prüfen die Aktivität unter Sperre. Der Storno sperrt die Bedarfsgemeinschaft und erhöht Budget sowie Vermögen auch bei einem historisierten Vorgang. Der Webpfad lässt den Storno nur mit Admin-Rolle aus der Sitzung zu (`LmgServer`, Zeilen 292–295 und 485–491). Die Servicemethode selbst prüft die Rolle nicht.

### FB-20261015-10 — MINOR — STATISCH

`BerechnungsSnapshot.lese`, Zeilen 203–207.

Version 3 speichert das erzeugte HTML und der Nachdruck gibt es unverändert zurück. Ein erteilter Bescheid wird dadurch nicht neu berechnet. Das strukturierte JSON setzt Merkzeichen, Schwangerschaft, Kinderzähler, Warmwasser und Entbindungsmonat beim Lesen auf leer und übernimmt von den Eingaben Stufe, Rente und Erwerb. Eine Rekonstruktion der Berechnung allein aus dem JSON ist unvollständig. Version 2 kennzeichnet den nachgedruckten Altstand.

### INFO, ohne eigene Geldabweichung im geprüften Pfad

- Merkzeichen G löst 17 Prozent aus, ohne die Altersgrenze oder die volle Erwerbsminderung des § 30 Abs. 1 zu erfassen. Die Maske nennt nur das Merkzeichen.
- § 30 Abs. 4, 5, 8, 9 und 10, der höhere Warmwasser-Messnachweis, die Werkstattregel des § 82 Abs. 3 Satz 2, § 82 Abs. 4, § 1 DVO Satz 2 zur alleinstehenden minderjährigen Person bei einer reinen Kinder-BG und § 2 DVO zur Notlage sind nicht modelliert.
- § 35 Karenz, Eineinhalb-Grenze und Absenkungsfrist fehlen. Der Bescheid sagt das, wenn eine Grenze greift. Solange die konfigurierte Grenze 0 ist, bleibt die gesamte erfasste KdU Bedarf.
- § 42a Absätze 3 bis 7, die besondere Wohnform und der Kopfteil sind nicht modelliert. Die eine Gesamtgrenze ist von § 35 Abs. 7 gedeckt, sobald sie als solche gemeint ist.
- § 44 Abs. 2, die Rückwirkung auf den Monatsersten, hat kein Antragsdatum.
- Die Vier-Tage-Fiktion im Bescheid nennt die Widerlegung bei fehlendem oder späterem Zugang nicht.
- Der Kassenlauf schreibt einen Journaleintrag ohne BG-Bezug. Die Einsichtsdeduplizierung läuft unter BG-Sperre mit `SYSTIMESTAMP` und 60 Sekunden; unterdrückte Wiederholungen schieben das Fenster nicht.
- Bescheiddatum und Vorschau verwenden die JVM-Uhr, das Journal die Datenbankuhr.

## 5. Widerlegte Verdächte

- Die Stufe ersetzt beim Mehrbedarf nach § 30 Abs. 3 das Alter. Die Zähler „unter 7“, „unter 16“ und „minderjährig“ sind eigene Felder. Ein Kind im siebten Lebensjahr ist Stufe 5 und zugleich unter sieben; der Code vermischt das nicht.
- Der Entbindungsmonat streicht den Mehrbedarf schon im Geburtsmonat. Juni bleibt 658,71, Juli wird 563,00.
- Zentrale Warmwasserkosten müssen nach § 35 Abs. 5 abgezogen werden. Die Norm enthält keine Absetzung. Parameter 0,20 und 0 ergeben beide 1.063,00.
- Dezentrales Warmwasser liegt unter der Obergrenze des Absatzes 6. Es wird danach addiert. Auf Stufe 6 mit acht Kindern unter 16 bleiben 359,86, davon 2,86 außerhalb der Kappung.
- Die Personenreihenfolge ändert den Zahlbetrag der BG an einer KdU-Grenze. Beide Reihenfolgen ergeben 1.569,00. Es wechselt nur, welche Person den Überschuss trägt.
- Dieselbe Vorgangsnummer bucht ein zweites Mal, auch nach verlorener HTTP-Antwort. Der Service gibt die vorhandene Zahlung zurück. Eine stornierte Vorgangsnummer wird abgelehnt und verlangt eine neue Nummer. Der Unique-Index `UQ_ZAHLUNG_BG_MONAT_AKTIV` lässt je BG und Monat nur eine nicht stornierte Zeile zu.
- Vier-Augen lässt sich über den Webkörper oder die Saga umgehen. Der Webpfad setzt die Kennung aus der Sitzung, beginnt bei ANGELEGT und erlaubt die Selbstfreigabe nur der Rolle Admin. Die Saga schreibt ANGELEGT ohne Freigebenden. Die Übergabe nimmt nur BEREIT und nur die zuvor gesperrte, noch aktive Menge.
- Storno schreibt einen neu berechneten Vermögensbetrag zurück oder schreibt ihn doppelt. Zurück gebucht wird der gespeicherte Einsatz, und nur wenn der Statuswechsel genau eine Zeile trifft.
- Ein erteilter Bescheid wird beim Nachdruck still durch eine aktuelle Rechnung ersetzt. Version 3 liefert das gespeicherte HTML. Ein snapshotloser Altbescheid ist als Neuberechnung gekennzeichnet.
- Der Jahreswechsel ist im Code unmöglich. Zwei Satzstände werden monatsgenau gewählt. Amtlich ändert sich von 2025 auf 2026 kein Cent. Fehlt eine Zeile, bricht die Rechnung mit fehlendem Satzstand ab.
- Die elektronische Widerspruchsbelehrung zitiert eine nicht mehr vorhandene Form. § 84 Abs. 1 SGG, § 36a Abs. 2 und 2a SGB I und § 9a Abs. 5 OZG enthalten die im Bescheid genannten Wege.

## 6. Offene Hypothesen

- Ob „für ein Kind unter sieben Jahren“ bei sechs Kindern unter sieben noch Nummer 1 auslöst. Für den ausgeführten Sechs-Kinder-Haushalt bleibt der Zahlbetrag auch dann 2.385,98, weil 72 Prozent auf 60 Prozent gedeckelt werden. Die Hypothese ändert diesen einen Haushalt nicht. Sie ändert den Vier-Kinder-Haushalt mit einem Kind unter sieben: bei enger Lesart, Nummer 1 gelte nur für genau diese Kinder und keine weiteren, läge der Soll bei 1.703,42 und der Code wäre dort zutreffend. Die Vergleichsklausel bliebe trotzdem ein Normverstoß in den Haushalten, in denen zwei oder drei Kinder unter sechzehn neben älteren Minderjährigen leben.
- Ob 30 Prozent nach § 82 Abs. 3 vom Erwerbseinkommen nach Abzug des Absatzes 2 zu rechnen sind. Der Wortlaut sagt „ferner“ und „des Einkommens aus Tätigkeit“. Der Code verwendet das Bruttofeld und zieht Absatz 2 zusätzlich ab. Eine engere Nettobasis ist nicht als Fehler festgestellt.
- Ob bei einer BG nur aus Minderjährigen jede alleinstehende minderjährige Person eigene 10.000 EUR Schonvermögen erhält. Der Code setzt ohne Stufe 1–3 einmal 10.000 EUR. Die DVO-Definition hängt davon ab, dass der Anspruch nicht vom Elternvermögen abhängt. Ohne Falldaten bleibt das offen.
- Ob WD 6-046/24 den Wortlaut des § 30 Abs. 3 anders liest. Die Ausarbeitung war nicht erreichbar und ist UNVERIFIZIERT.

## 7. Prüfstatus je Norm

| Norm | Status dieser Prüfung |
|---|---|
| Anlage zu § 28, Beträge und Altersbänder 2026 | geprüft, Beträge bestätigt, Zuordnung als Eingabe |
| § 30 Abs. 1 | geprüft, Modellgrenze beim Personenstatus |
| § 30 Abs. 2 | geprüft, Monatslogik bestätigt, README-Woche falsch |
| § 30 Abs. 3 | geprüft, Implementierungsfehler FB-20261015-01 und Validierung FB-20261015-05 |
| § 30 Abs. 4, 5, 8, 9, 10 | als nicht modelliert festgestellt |
| § 30 Abs. 6 und 7 | geprüft, Kappung und dezentrale Sätze bestätigt |
| § 35 und § 42a | geprüft, Summe und Centgrenze bestätigt; Karenz, Absenkung, Haushaltssonderfälle Modellgrenze; kein zentraler Warmwasserabzug, normgerecht |
| § 82 | geprüft, Bruttofreibetrag, Deckel und Centgrenze bestätigt; Werkstatt und Altersvorsorge nicht modelliert |
| § 43, § 90, § 1 DVO | geprüft, knapper Verbrauch bestätigt, deckender Bestand FB-20261015-04 |
| § 44 | Zwölfmonatsgrenze geprüft; Antragsrückwirkung nicht modelliert |
| § 48 SGB X | nur soweit ein Änderungsbescheid fehlen und die Zahlung sperren kann, FB-20261015-02 |
| § 36, § 37 SGB X, § 84 SGG, § 36a SGB I, § 9a OZG, § 65a, § 73, § 87 SGG | Belehrung geprüft und im Kern bestätigt |
| Geldfluss Vorschau, Service, Web, Saga | gemeinsame Rechenfunktion geprüft; Vorschau-Monat FB-20261015-03; Buchung, Idempotenz, Vier-Augen, Kassenmenge und Journal statisch |

## 8. Gelesene Dateien

Vollständig gelesen: `Leistungsberechnung.java`, `Satzstand.java`, `Bewilligungsplan.java`, `BerechnungsSnapshot.java`, `SozialFall.java`, `BescheidPaymentBinding.java`, `BescheidDokument.java`, `ZahlungDao.java`, `SatzstandDao.java`, `JournalDao.java`, `ddl/lmg_schema.sql` im fachlichen Tabellenteil, `ddl/lmg_seed.sql`.

Pfadweise vollständig für die Geld- und Bescheidpfade, nicht jede Hilfsmethode: `SozialLeistungsService.java`, `AntragsSagaProzess.java`, `BescheidGenerator.java`, `LmgServer.java`, `BedarfsgemeinschaftDao.java`, `BescheidDao.java`, `LmgConfig.java`, `LeistungsberechnungTest.java` in den Mehrbedarfs- und Freibetragsfällen, `README.md` im Berechnungsabschnitt, die Maskentexte in `app.js` und `index.html`.

Nicht ausgeführt: die volle Maven-Suite, HTTP-Läufe, Schreib- oder Lesetests auf der Oracle-Datenbank. Der Rechenkern wurde nach `mvn -DskipTests compile` mit `jshell` ausgeführt. Service, Saga, Web und Snapshot verwenden diese Funktion; ihre Transaktionen sind statisch geprüft.
