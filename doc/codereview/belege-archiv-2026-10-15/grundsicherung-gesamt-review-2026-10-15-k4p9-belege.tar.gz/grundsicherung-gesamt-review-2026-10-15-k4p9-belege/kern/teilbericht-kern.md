# Teilbericht A — Transaktionskern, Oracle, Pools, Nebenläufigkeit, Recovery

Prüfer A, Commit `37abfb6f3da841e440ab21a53fbffa7eadf7cd04`, Branch `main`.
Produkt SDN.Leistung. Fachbegriffe SozialFall und Bedarfsgemeinschaft.
Compilerziel `--release 21`. Es wurde kein Produktcode geändert.

Evidenz dieses Teilberichts ist **statisch** (Quelltext, DDL, Aufrufer, Tests nur als Aussage darüber, welche Pfade behauptet werden). Die gemeinsam genutzte Developer-Datenbank wurde nicht angefasst, die volle Testsuite nicht gestartet, kein Container verändert. Ein Befund ist deshalb nicht „dynamisch belegt“.

## Befunde

### KR-20261015-01 — Abbruch und äußere Deadline beweisen den Rollback der Fachwirkung nicht

- Schwere: **KRITISCH**
- Belegsicherheit: **STATISCH BELEGT**
- Orte: `src/main/java/de/allgemein/tx/TxManager.java:44-51`, `src/main/java/de/allgemein/tx/TaskController.java:228-235` und `273-281`, `src/main/java/de/allgemein/lmg/web/LmgServer.java:225-250` und `464-472`, `src/main/java/de/allgemein/lmg/service/SozialLeistungsService.java:259`

Vorbedingung: Jeder HTTP-Aufruf läuft als Task mit `TxOptions.DEFAULT` (30 s, 3 Versuche). `TaskExecution.call` startet den Wachhund und ruft danach `TxManager.execute` auf. Die Fachmethoden und `SagaEngine.run` öffnen darin weitere eigene `TxManager.execute`-Transaktionen auf zusätzlichen Poolverbindungen. Die innere Transaktion committet die Fachwirkung. Die äußere Verbindung führt keinen Fach-SQL aus.

Ablauf:

1. Der Wachhund startet bei Ausführungsbeginn, vor dem Borrow der äußeren Verbindung (`TaskController.java:232-235`). `future.cancel(true)` setzt nur das Interrupt-Flag.
2. `TxManager.execute` prüft dieses Flag vor `commit()` nicht (`TxManager.java:45-47`). `checkDeadline()` gilt je Versuch und beginnt erst mit dem `TxContext` dieser Verbindung. Eine innere Transaktion, die später eine Verbindung erhält, hat damit ein frisches 30-s-Budget, während Wachhund und äußere Deadline die bereits vergangene Borrow- und Laufzeit mitzählen.
3. Läuft die Facharbeit nahe an oder über 30 s (Pool-Wartezeit plus langsame Schritte, Bescheid über mehrere Monate, Saga aus vier eigenen Commits), committet die innere Transaktion, und die äußere `checkDeadline()` wirft danach `TxException.timeout`. `rollbackQuietly` trifft nur die leere äußere Verbindung.
4. Wirkt der Abbruch schon während des inneren JDBC-Aufrufs, läuft dieser weiter. Der Kern ruft `Statement.cancel()` nicht auf. Das gesetzte Lese-Timeout (`oracle.jdbc.ReadTimeout`, Standard 120 s in `LmgConfig.java:56` und `UcpConnectionPool.java:51`) ist die Grenze für einen blockierten Socket-Read. Kehrt der Aufruf zurück und die Versuchsdeadline ist noch offen, folgt `commit()`.
5. `TaskHandle.result()` liefert bei Cancel sofort eine nicht wiederholbare `TxException`, noch während der Worker weiterläuft. `LmgServer` antwortet darauf mit HTTP 500 und dem Text, es solle erneut versucht werden (`LmgServer.java:247-250`).

Verletzte Regel: Ein Fehler nach erfolgreichem Commit ist kein Rollbackbeweis. Der Wachhund-Kommentar (`TaskController.java:38-50`) beschreibt das Restfenster als JDBC-Commit, der den Server bereits erreicht hat. Der tatsächliche Pfad ist breiter: verschachtelte, bereits bestätigte Fachcommits und jeder JDBC-Aufruf, der das Interrupt-Flag nicht auswertet.

Auswirkung: Der Client sieht einen Fehlschlag, obwohl Zahlung, Bescheid oder Saga-Schritte dauerhaft sind. Dieselbe Vorgangsnummer und der Unique-Index `UQ_ZAHLUNG_BG_MONAT_AKTIV` verhindern eine zweite wirksame Zahlung desselben Monats; Kassenlauf, Freigabe und Storno sind über Status-Guards ebenfalls nicht doppelt wirksam. Die Oberfläche erzeugt beim nächsten Klick jedoch eine neue Vorgangsnummer (`webapp/app.js:636`) und zeigt den technischen Fehler als „nicht möglich“. Der Sachbearbeiter erfährt den Erfolg nicht. Eine Antrags-Saga bleibt nach dem inneren Abschluss im Journal vollständig, während die HTTP-Antwort fehlschlägt; ein zweiter Lauf mit demselben Aktenzeichen legt wegen `UQ_BG_AKTENZEICHEN` und `istVonSagaAngelegt` keinen zweiten Vorgang an.

Die Tests schließen das nicht. `TaskControllerWatchdogBudgetTest` unterbricht einen `SQLException`-Wurf im Backoff-`sleep` auf `FakePool`. Ein Commit nach Ablauf des Wachhunds bei noch offener Versuchsdeadline wird nicht behauptet und nicht verhindert.

Grenze, nicht als eigener Defekt gewertet: Ein Thread-Interrupt beendet einen laufenden Oracle-JDBC-Call nicht. Das ist am fehlenden `Statement.cancel()` statisch belegt. Das Verhalten des Treibers selbst wurde hier nicht ausgeführt.

### KR-20261015-02 — Offene Sagas werden bei geänderter Schrittliste über den Index kompensiert

- Schwere: **MAJOR**
- Belegsicherheit: **STATISCH BELEGT**
- Orte: `src/main/java/de/allgemein/tx/saga/SagaEngine.java:316-329`, `src/main/java/de/allgemein/lmg/saga/AntragsSagaProzess.java:75-81`, `ddl/oracle_schema.sql:30-39`

Vorbedingung: `TX_SAGA` speichert `SAGA_TYPE`, keine Definitionsversion. `TX_SAGA_STEP.NAME` wird erst in `stepDone` gesetzt (`SagaJournal.java:99-101`), die Anlage schreibt nur `IDX` und `PENDING` (`SagaJournal.java:64-71`). Wiederanlauf und Laufzeitkompensation wählen die Kompensation mit `definition.steps().get(i)`.

Ablauf: Eine Saga vom Typ `SGB_XII_ANTRAGSVERARBEITUNG` ist RUNNING, FAILED oder COMPENSATING. Vor dem nächsten Start wird ein Schritt eingefügt, entfernt oder umsortiert, der Typname bleibt. `requireSuccessfulRecovery` kompensiert beim Start jede unfertige Saga dieses Typs (`LmgServerMain.java:81` und `163-171`). Index 0 der neuen Liste kompensiert dann den früheren Index 0.

Verletzte Regel: Kompensation muss die persistierte Fachwirkung derselben Saga treffen. Der Journal-Marker der Antrags-Saga schützt vor fremden Bedarfsgemeinschaften, nicht vor einer verschobenen Schrittliste.

Auswirkung: Beim Deploy mit offenen Sagas wird die falsche Kompensation ausgeführt oder ein bekanntes `DONE`/`IN_FLIGHT` als unbekannt FAILED gelassen (`SagaEngine.java:341-352` nur wenn der Index über die neue Länge hinausgeht). Frische Installationen ohne Alt-Sagas sind nicht betroffen. Ein Upgrade-Skript, das offene Sagas dieses Typs sperrt oder eine Typversion fortschreibt, liegt nicht bei.

### KR-20261015-03 — Kassenlauf übergibt die gesperrte Menge in einer Oracle-IN-Liste

- Schwere: **MAJOR**
- Belegsicherheit: **STATISCH BELEGT** (SQL-Form; ORA-01795 ist die dokumentierte Oracle-Grenze und wurde hier nicht ausgeführt)
- Orte: `src/main/java/de/allgemein/lmg/dao/ZahlungDao.java:71-88` und `95-107`, `src/main/java/de/allgemein/lmg/service/SozialLeistungsService.java:516-537`

Vorbedingung: `bereiteZahlungenGesperrt` sperrt alle Zeilen mit Status `BEREIT` aktiver Bedarfsgemeinschaften ohne Zeilenobergrenze (`FOR UPDATE ORDER BY z.ID`). `uebergebeGesperrte` baut daraus `WHERE ID IN (?,?,…)` mit einem Platzhalter je ID.

Ablauf: Mehr als 1000 bereite Zahlungen. Das SELECT sperrt die Menge. Das anschließende UPDATE überschreitet die Oracle-Grenze von 1000 Ausdrücken in einer IN-Liste (ORA-01795). `TxManager` rollt die Transaktion zurück. Die Zahlungen bleiben `BEREIT`. Jeder erneute Kassenlauf nimmt denselben Weg.

Verletzte Regel: Die Übergabe soll genau die gesperrte Menge in einer Transaktion fortschreiben. Die Sperre ist nach ID geordnet und damit untereinander verklemmungsarm; die Schreibanweisung ist für diese Menge in Oracle nicht ausführbar. 19c und 23ai behalten diese Parsergrenze.

Auswirkung: Ein Rückstand über 1000 bereiten Zahlungen lässt sich über diesen Pfad nicht an die Kasse übergeben. Es entsteht keine Teilübergabe, weil die Exception vor dem Commit liegt. Summe und Anzahl können dabei nicht auseinanderlaufen: der Vergleich von `anzahl` mit `ids.size()` fehlt (`SozialLeistungsService.java:529-537`), unter der gehaltenen Sperre ist eine kleinere Trefferzahl aber kein erreichbarer Zustand. Der Fehler tritt erst oberhalb der IN-Liste auf.

### KR-20261015-04 — Verlorene Bestätigung des Write-ahead lässt IN_FLIGHT unter einem beendeten Kopf stehen

- Schwere: **MINOR**
- Belegsicherheit: **STATISCH BELEGT** für den Kontrollfluss; der mehrdeutige `commit()`-Ausgang selbst ist nicht ausgeführt
- Orte: `src/main/java/de/allgemein/tx/saga/SagaJournal.java:465-481`, `src/main/java/de/allgemein/tx/saga/SagaEngine.java:89-91` und `141-148`

Vorbedingung: `markStepInFlight` committet in `SagaJournal.tx` auf eigener Verbindung. `imFlug = true` steht erst nach der Rückkehr dieses Aufrufs. `schrittCommittet` prüft `isStepDone` und nur wenn `imFlug` bereits gesetzt ist.

Ablauf: `connection.commit()` des Write-ahead ist auf dem Server wirksam, der Client erhält trotzdem eine `SQLException` (verlorene Bestätigung). `tx` rollt zurück; nach einem erfolgreichen Commit ist das ein Leerlauf. `record` wirft eine nicht wiederholbare `TxException`. Die Fachaktion dieses Index ist nicht gestartet. Die Laufzeitkompensation zählt den Index nicht mit. Erfolgreiche Kompensation der älteren Schritte setzt den Kopf auf `COMPENSATED` und löscht den Payload (`SagaJournal.java:355-367` und `395-396`). Recovery liest `COMPENSATED` nicht erneut.

Verletzte Regel: `IN_FLIGHT` bedeutet für den Wiederanlauf „möglicherweise ausgeführt“. Ein terminaler Kopf mit gelöschtem Payload entzieht diesen Schritt der weiteren Bearbeitung.

Auswirkung: Keine zweite Fachwirkung, weil die Aktion nicht begonnen wurde und `RetryPolicy` diesen Journalfehler nicht wiederholt. Das Journal behält einen `IN_FLIGHT`-Schritt unter einem abgeschlossenen, payloadlosen Kopf. Die Klärung über `isStepDone` gilt für den Fachschritt (`SagaEngine.java:142-144`), nicht für die Write-ahead-Transaktion.

### KR-20261015-05 — Der Übersichtsscan liest den Saga-Payload

- Schwere: **MINOR**
- Belegsicherheit: **STATISCH BELEGT**
- Orte: `src/main/java/de/allgemein/tx/saga/SagaJournal.java:199-213`, `src/main/java/de/allgemein/tx/saga/TxSagaJournal.java:73-74`

Vorbedingung: `unfinished(Duration)` ist der ungesperrte Überblick vor `claimUnfinished`. Der Schnittstellenkommentar sagt, der Payload werde hier nicht geladen.

Ablauf: Das SELECT enthält `s.PAYLOAD`. Startup- und Admin-Wiederanlauf materialisieren damit für jede unfertige Saga, auch für übersprungene Typen, den JSON-Payload im Speicher. `claimUnfinished` liest ihn danach erneut.

Verletzte Regel: Payload-Löschung bei `COMPLETED`/`COMPENSATED` begrenzt die Aufbewahrung. Der Scan holt die Sozialdaten trotzdem, solange der Kopf unfertig ist.

Auswirkung: Zusätzliche Datenhaltung und größere Recovery-Lesemenge. Die Löschung im Endzustand selbst ist im `UPDATE` des Claims vorhanden und wurde nicht als wirkungslos befunden.

## Offene Hypothesen

1. **Claim-Verbindung wird zwischen `checkAlive` und `commit` entzogen.** `UcpConnectionPool` setzt `AbandonedConnectionTimeout` auf 300 Sekunden (`UcpConnectionPool.java:46-48`). `checkAlive` liegt im Fachschritt vor der Aktion und erneut danach, vor dem Commit (`SagaEngine.java:93-100`). Ein Entzug während der Aktion lässt `checkAlive` scheitern; `TxManager` rollt die noch offene Fachtransaktion zurück, bevor sie committet. Ein Entzug in der Lücke nach erfolgreichem `checkAlive` und vor `raw.commit()`, bei gleichzeitig startendem Recovery, könnte die Kompensation auf dem noch unsichtbaren Stand als No-Operation ausführen und den Schritt danach auf `COMPENSATED` setzen. Diese Lücke ist kurz und wurde nicht ausgeführt. Der praktische 300-s-Fall während der Aktion ist durch das zweite `checkAlive` abgedeckt. Nicht als Befund gewertet.

2. **ORA-00054, ORA-00060 oder ORA-08177 aus `Connection.commit()` selbst.** `RetryPolicy` würde dann den ganzen Versuch wiederholen. Im Standard `READ COMMITTED` entstehen 54 und 8177 auf den DML-Anweisungen, nicht als verlorene Commit-Quittung. `withIsolation` hat im Produktcode keinen Aufrufer. Nicht ausgeführt.

3. **Idle-Firewall beendet die Claim-Session, ohne dass der Client die Verbindung sofort als tot sieht.** Solange Oracle die Sitzung hält, hält `FOR UPDATE` die Recovery fern. Ein Nachweis bräuchte eine exklusive Datenbank und wurde nicht geführt.

## Widerlegte Verdächte

- **Automatischer Retry nach mehrdeutigem Fach-Commit.** Kommunikationsfehler tragen nicht die Vendorcodes 54, 60 oder 8177. `RetryPolicy.isRetryable` wertet nur diese Codes aus, zyklensicher über `getCause` und `getNextException`, und nicht mehr SQLState 61000 allein (`RetryPolicy.java:36-54`). Ein erfolgreicher Fachschritt, dessen Commit-Aufruf danach fehlschlägt, wird über `isStepDone` in die Kompensation aufgenommen (`SagaEngine.java:142-144`, `448-457`).
- **Fachliche Fehler gelten als Sperrkonflikt.** `FachlicheException` ruft `TxException(String)` auf und ist damit nicht retryable (`FachlicheException.java:29-31`, `TxException.java:15-17`). `catch (Exception)` im `TxManager` wiederholt grundsätzlich nicht (`TxManager.java:68-72`).
- **Error umgeht den Rollback.** `catch (Error)` rollt zurück und reicht den Error weiter (`TxManager.java:73-80`). Beide Pools rufen vor `setAutoCommit(true)` `rollback()` auf und schalten Autocommit nur nach erfolgreichem Rollback um (`SimpleConnectionPool.java:190-196`, `UcpConnectionPool.java:86-91`).
- **Doppeltes `release` hebt die Poolgrenze auf.** `SimpleConnectionPool` führt ausgeliehene Verbindungen in einem Set und gibt das Permit bei unbekanntem Handle nicht frei (`SimpleConnectionPool.java:178-184`). `UcpConnectionPool.release` verlässt eine bereits geschlossene logische Verbindung ohne zweiten `close` (`UcpConnectionPool.java:86-94`). `JournalClaim.finish` setzt `beendet` vor der Freigabe; das folgende `close` ist dann wirkungslos (`SagaJournal.java:355-383`).
- **Manuelles `rollback` nach erfolgreichem `commit`.** `rollback` kehrt bei Status ungleich `ACTIVE` sofort zurück (`TxManager.java:124-127`). `commit` setzt den Status erst nach Rückkehr von `connection.commit()` (`TxManager.java:118-122`).
- **IN_FLIGHT nach fachlichem Schrittfehler ist eine vergessene Kompensation.** Schlägt die Fachaktion vor dem Commit fehl, bleibt der Schritt absichtlich `IN_FLIGHT`, der Kopf wird `COMPENSATED`. `SagaEngineTest.fachfehlerKompensiertRueckwaertsGenauEinmalUndEndetCompensated` erwartet das. Der Crash-Pfad kompensiert `IN_FLIGHT` (`SagaEngine.java:312-329`). Die Fachaktion der Antrags-Saga schreibt nur auf der übergebenen Verbindung.
- **Kompensationsfehler, der ältere Schritte trotzdem ausführt, gibt Geld frei.** Der Ablauf ist beabsichtigt und getestet (`SagaEngine.java:416-421`). `freigebenZahlung` und der Kassenlauf verlangen eine aktive Bedarfsgemeinschaft (`SozialLeistungsService.java:476-481` und `518-525`). Eine noch `ANGELEGT` gebliebene Saga-Zahlung auf einem bereits historisierten Vorgang wird nicht freigegeben. Der nächste Wiederanlauf sieht den Kopf `FAILED` und die noch `DONE` gebliebene Zahlung.
- **Optimistisches Locking wird vom Version-Trigger ausgehebelt.** `TRG_BG_VERSION` und `TRG_FALL_VERSION` erhöhen `VERSION` nur, wenn der neue Wert leer oder nicht größer als der alte ist (`ddl/lmg_schema.sql:180-198`). Die Masken-Updates fordern `WHERE ID = ? AND VERSION = ?` und werten 0 Zeilen als `KONKURRENZ` (`BedarfsgemeinschaftDao.java:78-94`, `SozialLeistungsService.java:237-244`).
- **Zwei Kassenläufe oder Storno gegen Kassenlauf verklemmungssicher falsch.** Kassenlauf sperrt Zahlungen `ORDER BY z.ID`, danach Bedarfsgemeinschaften aufsteigend. Storno und Freigabe sperren zuerst die Zahlung, dann die Bedarfsgemeinschaft. ORA-00060 ist retrybar; die Status-Guards machen die Wiederholung idempotent. Eine Datenkorruption aus dieser Sperrreihenfolge wurde nicht belegt.
- **Pool-Zyklus HTTP-Executor, Taskpool, Datenbankpool ohne Ausweg.** Der HTTP-Pool hat 16 Threads und hält keine Datenbankverbindung (`LmgServer.java:83-84`). Acht Tasks können je äußere Verbindung, Claim und Fach-/Journalverbindung belegen. Standard 24 liegt auf `3 × maxTasks`; darunter warnt der Start (`LmgServerMain.java:60-64`). `getConnection` endet nach 30 s Borrow-Timeout. Ein dauerhaftes Warten ohne Fehler wurde nicht gefunden.
- **Startup-Recovery läuft in den Listener.** `requireSuccessfulRecovery` läuft vor `LmgServer`-Erzeugung. Scanfehler und unvollständige Kompensation werfen und verhindern den Start (`LmgServerMain.java:79-85`, `163-171`). Die Altersfrist von fünf Minuten wird erst danach gesetzt; bis dahin schützt die Kopf-Sperre `FOR UPDATE SKIP LOCKED`.
- **Unbekannter Saga-Zustand legt den Wiederanlauf still.** `leseUnfinished` überspringt einzelne unbekannte Kopfzustände (`SagaJournal.java:228-239`). Die CHECK-Constraints lassen die fünf bekannten Zustände zu (`ddl/oracle_schema.sql:19-20`).
- **Audit nach Commit macht die Fachtransaktion rückgängig.** `TxAuditLog.record` fängt Listener-, Datei- und Loggerfehler (`TxAuditLog.java:216-242`). Ein Wurf nach `raw.commit()` aus diesem Pfad ist damit nicht belegt.

## Prüfstatus

| Teilfeld | Status | Begründung |
|---|---|---|
| `TxManager.execute` und manuelle API | GEPRÜFT | Exception, Error, Deadline, Commit/Rollback, mehrfache Freigabe und verlorene Bestätigung am Quelltext und an den Aufrufern geprüft. Befund KR-20261015-01 und KR-20261015-04. `begin`/`commit`/`finish` haben im Produkt keinen Aufrufer außerhalb des Claim-Finish. |
| `RetryPolicy` | GEPRÜFT | Nur Vendorcodes 54, 60, 8177; Ketten, Limit, Backoff-Deckel 30 s plus Jitter, Interrupt setzt das Flag und wirft nicht retrybar. Kein Befund. |
| `TaskController` / `TaskHandle` | GEPRÜFT | Queue, Settle-Gate, Shutdown-Drain, Statistik und Abbruch gegen Commit geprüft. Der Abbruch ist Teil von KR-20261015-01. Interrupt als JDBC-Abbruch ist eine Grenze, kein ausgeführter Treibernachweis. |
| `SagaEngine` und Journal | GEPRÜFT | Write-ahead, Fachschritt plus DONE, COMPLETED ohne Fehlkompensation, Claim über die Schritte, paralleles `SKIP LOCKED`, Payload-Löschung, alte Indizes. Befunde KR-20261015-02, KR-20261015-04, KR-20261015-05. |
| `SimpleConnectionPool` und `UcpConnectionPool` | GEPRÜFT | Borrow-/Connect-/Read-Timeout, Validierung, Rollback vor Autocommit, einmalige Freigabe, Erschöpfung, drei Verbindungen je Saga-Task. Kein eigener Defekt. Abandoned-Timeout nur als Hypothese 1. |
| DDL, Sperren, Bootstrap, Konfiguration, JMX, Shutdown | TEILWEISE | Saga- und Fach-Constraints, Trigger, FK-Indizes, Kassenlauf-IN-Liste und Startreihenfolge gelesen. Frische Anlage enthält `BESCHEID.BERECHNUNG`; bestehende Datenbanken brauchen das im Skript kommentierte `ALTER`. Kein versioniertes Migrationsprogramm geprüft, weil keins im DDL-Ordner liegt. Shutdown: Drain 10 s plus 5 s (`TaskController.java:57`, `173-175`) ist kürzer als das Lese-Timeout 120 s; danach schließt der Hook den Pool, während ein nicht unterbrochener JDBC-Call noch laufen kann. Das ist eine Betriebsgrenze, kein zusätzlich ausgeführter Fehler. JMX vergibt bei belegtem Namen eine eigene Instanz (`TxMonitoring.java:75-79`). UTF-8-Kaskade in `LmgConfig` bricht bei defekter Datei ab. |

## Vollständig gelesene Dateien

- `doc/architektur.md` (gesamte Datei)
- `src/main/java/de/allgemein/tx/TxManager.java`
- `src/main/java/de/allgemein/tx/TxContext.java`
- `src/main/java/de/allgemein/tx/TxOptions.java`
- `src/main/java/de/allgemein/tx/TxException.java`
- `src/main/java/de/allgemein/tx/RetryPolicy.java`
- `src/main/java/de/allgemein/tx/TaskController.java`
- `src/main/java/de/allgemein/tx/TaskHandle.java`
- `src/main/java/de/allgemein/tx/TaskInfo.java`
- `src/main/java/de/allgemein/tx/ConnectionPool.java`
- `src/main/java/de/allgemein/tx/SimpleConnectionPool.java`
- `src/main/java/de/allgemein/tx/UcpConnectionPool.java`
- `src/main/java/de/allgemein/tx/saga/SagaEngine.java`
- `src/main/java/de/allgemein/tx/saga/SagaJournal.java`
- `src/main/java/de/allgemein/tx/saga/SagaClaim.java`
- `src/main/java/de/allgemein/tx/saga/TxSagaJournal.java`
- `src/main/java/de/allgemein/tx/saga/UnfinishedSaga.java`
- `src/main/java/de/allgemein/tx/saga/SagaDefinition.java`
- `src/main/java/de/allgemein/tx/saga/SagaState.java`
- `src/main/java/de/allgemein/tx/audit/TxAuditLog.java`
- `src/main/java/de/allgemein/tx/monitoring/TxMonitoring.java`
- `src/main/java/de/allgemein/lmg/saga/AntragsSagaProzess.java`
- `src/main/java/de/allgemein/lmg/web/LmgServerMain.java`
- `src/main/java/de/allgemein/lmg/service/Systemdiagnose.java`
- `src/main/java/de/allgemein/lmg/service/FachlicheException.java`
- `src/main/java/de/allgemein/lmg/config/LmgConfig.java`
- `ddl/oracle_schema.sql`
- `ddl/lmg_schema.sql`
- `src/test/java/de/allgemein/tx/TaskControllerWatchdogBudgetTest.java`
- `src/test/java/de/allgemein/tx/saga/SagaEngineTest.java` (Assertions zu IN_FLIGHT, Kompensationsreihenfolge und Wiederanlauf; die Datei ist 673 Zeilen, der für die genannten Pfade maßgebliche Teil einschließlich des In-Memory-Journals wurde gelesen)

Gezielt gelesen, nicht als Volllektüre gewertet: `LmgServer.java` (Task-Rand, Saga-Route, HTTP-Executor, Fehlerantwort), `SozialLeistungsService.java` (Buchung, Freigabe, Kassenlauf, Storno, Bescheid), `ZahlungDao.java`, `BedarfsgemeinschaftDao.java` (Version, Budget, Sperre), `webapp/app.js` (Vorgangsnummer je Klick).
