# Teilbericht C — Web, Berechtigungen, Sozialdaten, Simulator, Zertifikatsbelegkette

Prüfer C. Produkt SDN.Leistung. Fachbegriffe SozialFall, Bedarfsgemeinschaft.
Commit `37abfb6f3da841e440ab21a53fbffa7eadf7cd04`, Branch `main`.
Stand der Prüfung: 2026-10-15. Review ohne Reparatur. Kein Produktcode, keine Tests, keine Konfiguration, keine Rechtsgrundlagen und keine Bestandsbelege unter `testsweet/logs` verändert. Volle Maven-Suite, die sieben Simulator-Pflichtläufe, echte LLM-API-Aufrufe und schreibende Server gegen die gemeinsame Datenbank wurden nicht gestartet.

Isolierte Proben liefen nur unter `tmp/review-k4p9/` (JSON-Parser, Node-Antwortvertrag, Einmal-Drucktoken). Ergebnisse sind mit **DYNAMISCH BELEGT** gekennzeichnet.

## Prüfstatus

Abgeschlossen für das Prüfgebiet C am genannten Commit. Suche zuerst nach unzulässigen Zugriffen und fälschlich positiven Prüfergebnissen.

| Bereich | Ergebnis |
|---|---|
| Objektzugriff LmgServer | Befund WB-20261015-01 |
| Geheimnisse, Klartext, lokaler Simulator | Befunde WB-20261015-02, -03, -05 |
| Einmal-Drucktoken, JSON, CSRF, Methoden, Sachbearbeiterherkunft | am gelesenen Stand geschlossen; Reste WB-20261015-04 und -06 |
| testsweet falscher Erfolg | am gelesenen Stand widerlegt |
| Zertifikatskette grün trotz Abbruch/älterem Erfolg | am gelesenen Stand widerlegt |
| Lokaler Hash als Urheberschaft | Grenzbefund ZT-20261015-01 |

## 1. Endpunktmatrix LmgServer

Gemeinsame Schranken, soweit die Zeile nichts anderes sagt:

- Bindung über `lmg.host`. Standard-Demo-Konten brechen bei Nicht-Loopback hart ab (`LmgServerMain.java:44-49`). Konfigurierte Konten dürfen an einem Nicht-Loopback-`HttpServer` antworten (`LmgServer.java:81`).
- Anmeldung: `Authorization: Bearer <Sitzung>`. Query-Token nur beim Druck. Abschließende Schrägstriche werden vor der Rollenprüfung entfernt (`LmgServer.java:114-116`).
- Rolle: Admin nur für `/api/system/*`, `/api/kassenlauf` und Storno (`LmgServer.java:292-296`, Storno zusätzlich im Handler `485-490`). Objektzugriff auf eine Bedarfsgemeinschaft, einen SozialFall oder eine Zahlung gibt es nicht.
- Sachbearbeiterkennung kommt aus der Sitzung. Auszahlung ignoriert eine Kennung im Körper (`436-443`). Die Antrags-Saga überschreibt `sachbearbeiterId` vor Validierung und Serialisierung (`469-471`).
- POST/PUT: Körper höchstens 1 MB, einmal gelesen und für TxManager-Retries zwischengespeichert (`834-844`).
- JSON-API: `Content-Type application/json`, CSP `default-src 'self'`, `X-Content-Type-Options: nosniff`, `Cache-Control: no-store` (`960-966`). Kein CORS-Header, kein Cookie.
- Falsche Methode auf bekanntem API-Pfad: 405 mit erlaubten Methoden (`527-533`). Unbekannter Pfad: 404. Überlast: 503 `UEBERLAST` plus `Retry-After: 2`. Fachfehler: 400, fehlendes Objekt: 404, Berechtigung: 403.
- Unerwartete Fehler nach außen ohne SQL-Text; JUL nur Klassenname und ORA-Code (`123-124`, `247-248`).

Legende Schreibwirkung: L = Lesen, S = Fachschreiben, A = Audit/Journal, — = keine Fachwirkung.

| Methode / Pfad | Anmeldung | Rolle / Objekt | Validierung | Wirkung | Status | Protokoll |
|---|---|---|---|---|---|---|
| GET, HEAD `/`, `/index.html`, `/app.js`, `/druck.js`, `/style.css` | keine | öffentlich, Klassenpfad-Whitelist | Pfad fest verdrahtet | — | 200 | keines |
| andere Methode auf Statik | keine | — | Allow GET, HEAD | — | 405 | keines |
| sonstige Statik | keine | — | — | — | 404 text/plain, CSP `default-src 'none'`, nosniff | keines |
| POST `/api/anmeldung` | keine | Konto aus `LMG_BENUTZER` bzw. Demo | Kennung, Passwort, Drosselung | Sitzung im Speicher | 200 Token, sonst 400/403 fachlich | keines (Token in Antwort, no-store) |
| POST `/api/abmeldung` | Sitzung | eigene Sitzung | — | Sitzung und zugehörige Drucktoken weg | 200 | keines |
| GET `/api/werbin` | Sitzung | eigene Sitzung | — | L Kennung, Rolle | 200 | keines |
| POST `/api/drucktoken` | Sitzung | jede BG-ID | `bgId` Zahl | S Kurzzeit-Token 60 s, an BG gebunden | 200 | keines |
| GET `/api/bedarfsgemeinschaften` | Sitzung | jede BG | — | L Name, Aktenzeichen, Budget, Vorschau; ohne IBAN | 200 | keine fallweise Einsicht |
| POST `/api/bedarfsgemeinschaften` | Sitzung | Neuanlage, jede Kennung | Aktenzeichen, Name, Beträge, Datum, optionale Bank | S Bedarfsgemeinschaft | 200 / 400 | Journal über Service, Kennung aus Sitzung |
| GET `/api/bedarfsgemeinschaften/{id}` | Sitzung | jede ID | ID Zahl | L vollständiges Detail inkl. Bank, Einkommen, Bescheid | 200 / 404 | Einsicht „Vorgangsdaten (Detail)“ |
| PUT `/api/bedarfsgemeinschaften/{id}` | Sitzung | jede ID | Version, Status, Bank, Vermögen | S Stammdaten und Bank | 200 / 400 / 404 | Journal, Kennung aus Sitzung |
| GET `…/{id}/bescheid` | Sitzung | jede ID | ID Zahl | L letzter Bescheid | 200 | Einsicht über `letzterBescheid` |
| POST `…/{id}/bescheid` | Sitzung | jede ID | Bewilligung von/bis | S Bescheid | 200 / 400 | Journal, Kennung aus Sitzung |
| GET `…/{id}/bescheid/druck` | Header-Sitzung oder Einmal-Query-Token | jede ID; Query-Token nur für genau diese ID | Token, Verbrauch, Ablauf | L HTML-Bescheid | 200 / 401 / 400 / 500 / 503 | Einsicht im Druckgenerator-Pfad; no-store, nosniff, CSP mit `style-src 'unsafe-inline'` |
| POST `…/{id}/sozialfaelle` | Sitzung | jede BG-ID | Stufen, Beträge, Monate | S SozialFall | 200 / 400 | Journal, Kennung aus Sitzung |
| PUT `/api/sozialfaelle/{id}` | Sitzung | jede Fall-ID; BG aus Bestand | Version, Beträge | S SozialFall | 200 / 400 | Journal, Kennung aus Sitzung |
| POST `/api/auszahlung` | Sitzung | jede BG; Replay bekannter Vorgangsnummer | Monat, Vorgangsnummer, optionale Bank | S Zahlung immer ANGELEGT; Antwort inkl. IBAN | 200 / 400 | Journal; Replay liefert Bankdaten |
| POST `/api/zahlungen/{id}/freigabe` | Sitzung | jede Zahlung; Vier-Augen gegen Erfasser | Status ANGELEGT, Vorgang aktiv | S BEREIT | 200 / 400 / 403 | Journal; Admin darf eigene Anordnung feststellen |
| POST `/api/zahlungen/{id}/storno` | Sitzung | Admin, jede Zahlung | Admin im Gate und im Handler | S STORNIERT, Budget zurück | 200 / 403 | Journal |
| GET `/api/zahlungen` | Sitzung | alle Zahlungen | `limit` 1–500, Standard 20 | L kompakt ohne IBAN/BIC | 200 | keine fallweise Einsicht |
| GET `/api/journal` | Sitzung | letzte Journaleinträge aller Vorgänge | `limit` 1–500 | L Aktionstext, Kennung, BG-ID | 200 | keine fallweise Einsicht |
| POST `/api/kassenlauf` | Sitzung | Admin, gesamter Bestand BEREIT | — | S ÜBERGEBEN der gesperrten Menge | 200 / 403 | Journal |
| POST `/api/saga/antrag` | Sitzung | jede Kennung; Saga muss vorhanden sein | Payload nach Überschreiben der Kennung | S Vorgang, Prüfung, Bescheid, Erstauszahlung | 200 / 400 / 404 | Saga-Journal |
| GET `/api/system/status` | Sitzung | Admin | — | L Erreichbarkeit, Zähler, Java-Version; `dbFehler` redigiert | 200 / 403 | keines |
| GET `/api/system/db-identity` | Sitzung | Admin | — | L SYS_CONTEXT-Felder ohne Passwort | 200 / 403 | keines |
| POST `/api/system/wiederanlauf` | Sitzung | Admin | — | S Kompensation halbfertiger Sagas | 200 / 403 | Saga-Journal |

Statische Dateien setzen nosniff und CSP, kein `no-store`. Die Sitzung liegt im `sessionStorage` der Oberfläche, nicht in den statischen Dateien.

## 2. Endpunktmatrix SweetServer

Gemeinsame Schranken: Bindung nur `127.0.0.1` (`SweetServer.java:59`). `localRequest` verlangt `Host` exakt `127.0.0.1:<port>` oder `localhost:<port>` und `Origin` leer oder `http://` plus diesem Host (`623-628`). Keine Anmeldung, keine Rolle. JSON-Antworten `no-store` (`870-871`). Körper höchstens 1 MB, JSON-Objekt (`631-636`). Während eines Zertifikatslaufs liefern `/api/pdf`, `/api/md`, `/api/llm/report/pdf` und `/api/zertifikat/pdf` 409 (`76-78`).

| Methode / Pfad | Zugang | Validierung | Wirkung | Status | Inhalt / Protokoll |
|---|---|---|---|---|---|
| GET `/api/status` | lokal, keine Anmeldung | — | L | 200 | DB-URL und DB-Benutzer, Laufzustand, letzte Logzeilen; Passwortfeld nicht in der Statusstruktur |
| POST `/api/start` | lokal | Modus, Kategorie, Zahlen; WEB+STRESS 400; DB-Erreichbarkeit | S Simulatorlauf, optional Aufräumen | 200 / 400 / 409 / 503 | Laufverzeichnis |
| POST `/api/stop` | lokal | — | S Abbruch | 200 / 409 | Abbruchzustand |
| GET `/api/pdf`, GET `/api/md` | lokal | Datei vorhanden; Suite-Sperre | L | 200 / 404 / 409 | Bericht des letzten Laufs |
| GET `/api/auftraege` | lokal | — | L | 200 | Auftragsliste des laufenden Simulators |
| GET `/api/auftrag/{id}` | lokal | numerische ID | L | 200 / 400 / 404 | ein Auftrag |
| GET `/api/testfaelle` | lokal | — | L | 200 | Katalog |
| POST `/api/zertifikat` | lokal | Suite und LLM nicht laufend; Exportsperre | S Veröffentlichung | 200 / 404 / 409 / 500 | Fingerprint-Prüfung im Werkzeug |
| GET `/api/zertifikat/pdf` | lokal | READY, Fingerprint | L | 200 / 404 / 409 | PDF |
| GET `/api/zertifikat/tests/status` | lokal, nur GET | — | L | 200 / 405 | Suite-Status |
| POST `/api/zertifikat/tests/start` | lokal, nur POST | keine zweite Suite | S eigene Prüf-JVM | 200 / 405 / 409 | Statusdateien |
| POST `/api/zertifikat/tests/stop` | lokal, nur POST | — | S Abbruch der Suite | 200 / 405 | Abbruch |
| GET `/api/zertifikat/tests/glm-protokoll` | lokal, nur GET | Pfad beginnt komponentenweise unter der Basis | L | 200 / 404 | `protocol.md` |
| GET `/api/llm/grundlagen`, GET `/api/llm/pruefauftrag` | lokal, nur GET | Datei vorhanden | L | 200 / 404 | Dokumenttexte |
| GET `/api/llm/pruefmenge` | lokal, nur GET | — | L | 200 / 404 | Prüfpaket |
| GET oder POST `/api/llm/config` | lokal | URL-Regeln beim Schreiben | S lokale Schlüsseldatei, Git-ignoriert | 200 / 400 / 405 | öffentliche Sicht nur `apiKeyConfigured` |
| POST `/api/llm/test` | lokal | Konfiguration | S ein Verbindungstest | 200 / 400 / 405 | Fehlertext ohne Roh-Antwort des Anbieters |
| POST `/api/llm/start` | lokal | Simulator nicht aktiv | S Prüflauf | 200 / 409 | Requests/Responses auf Platte, Schlüssel redigiert |
| GET `/api/llm/status` | lokal | — | L | 200 | Fortschritt, ohne Schlüssel |
| GET `/api/llm/report/pdf`, GET `/api/llmpruefung` | lokal | Nachweis vorhanden; Suite-Sperre für PDF | L | 200 / 404 / 409 | Bericht |
| POST `/api/llmpruefung/paket` | lokal, nur POST | — | S Prüfpaket | 200 / 405 | Fallauswahl |
| GET `/`, `/index.html`, `/app.js`, `/style.css`, `/assets/…` | lokal | `..` verboten, Asset-Muster, Realpath-Grenze | L | 200 / 404 | no-store; kein Fallback auf Schlüsseldateien |

Mehrere Lese-Routen (`/api/status`, `/api/pdf`, `/api/md`, `/api/auftraege`, `/api/testfaelle`, `/api/llm/status`) prüfen die Methode nicht. Eine falsche Methode führt dort zum Lesen, nicht zum Schreiben. Schreibrouten prüfen POST.

## 3. Sitzungen, Token, Grenzen, Sozialdaten

Sitzungen liegen im Speicher. Idle-Timeout kommt aus der Konfiguration. Fehlversuche konfigurierter Konten und unbekannter Kennungen haben getrennte Zähler. Der Drosselungsschlüssel ist auf 64 Zeichen begrenzt; unbekannte Kennungen verdrängen aktive Sperren nicht über eine feste Karte. Abmeldung entfernt die Sitzung und ihre Drucktoken.

Einmal-Drucktoken: Erzeugung an Sitzung und BG-ID, Ablauf 60 Sekunden, Verbrauch über `Map.remove` in einer synchronisierten Methode. **DYNAMISCH BELEGT** an einer isolierten `Benutzerverwaltung` ohne Server und ohne Datenbank: von zwei parallelen Abrufen trifft genau einer; Replay, falsche BG-ID, erneuter Abruf nach falscher BG-ID, Abruf nach Abmeldung und Verwendung der Sitzung als Drucktoken bleiben ohne Benutzer. Eine falsche BG-ID verbraucht das Token (geschlossen, kein zweiter Zugang). Der Header-Pfad beim Druck ist die normale API-Sitzung und umgeht den Einmalverbrauch absichtlich; die Objektlücke WB-20261015-01 bleibt dort bestehen. Das Query-Token wird nicht URL-decodiert; die Oberfläche kodiert es mit `encodeURIComponent`, UUIDs bleiben unverändert.

JSON (`Json.java`), **DYNAMISCH BELEGT**: leeres Objekt, leeres Array und Objekt in Array akzeptiert; doppelte Schlüssel auf oberster und verschachtelter Ebene abgelehnt; `1e999` und `1e-999` als `BigDecimal` akzeptiert; `1e1000` und ein 2000-stelliges Exponentenfeld abgelehnt; führende Null, `+1`, Nachtext, rohes Steuerzeichen und ungepaartes Surrogat abgelehnt; gepaartes Surrogat akzeptiert; Array-, Leerarray- und Objekt-Schachtelung 128 akzeptiert, 129 abgelehnt. Eine erste Probe mit rohen Klammern ohne Schlüssel war ungültiges JSON und kein Produktfehler. Node-Vertrag `llm-answer-json.js`, **DYNAMISCH BELEGT**: doppelter Schlüssel abgelehnt, Exponent als EUR abgelehnt, `schemaVersion` `2.0` akzeptiert, `2.0000000000000000001` abgelehnt.

XSS: Druckfehler sind `text/plain` mit nosniff und CSP `default-src 'none'`. Der Bescheidgenerator maskiert Titel, Namen und Belehrungsfragmente. Die Oberfläche maskiert vor `innerHTML`; Dialoge nutzen `textContent`. CSP der API und der Statik ist `default-src 'self'`. `frame-ancestors` und `X-Frame-Options` fehlen (WB-20261015-04).

CSRF: authentisierte API-Aufrufe brauchen einen Bearer-Header, den der Browser nicht von selbst sendet. Die Anmeldung setzt kein Cookie. Eine fremde Seite kann die JSON-Antwort ohne CORS nicht lesen. Der Druck ist ein GET mit Einmal-Token.

SQL- und Pfadgrenzen: Fachzugriffe laufen über die DAOs mit gebundenen Parametern; die HTTP-Schicht baut aus Pfadsegmenten nur Zahlen-IDs. Sweet-Protokoll- und Exportpfade prüfen `Path.startsWith` komponentenweise und lehnen `..` ab. Überlast des LmgServers antwortet 503 statt unbegrenzter Annahme.

Audit: `TxAuditLog.fehlerBeschreibung` schreibt Klassenname und ORA-Code. `TxAuditEvent.bereinige` entfernt Steuerzeichen. Der `Error`-Zweig in `TxManager.java:79` schreibt `e.toString()`; das ist bei `OutOfMemoryError` typischerweise der Klassenname. Der `Exception`-Zweig (`TxManager.java:72`) hängt `e.getMessage()` an die geworfene `TxException`. Der HTTP-Handler protokolliert diesen Text nicht, sondern erneut `fehlerBeschreibung`.

## 4. Simulator — falscher Erfolg

Geprüft am Quellstand, ohne die sieben Pflichtläufe zu starten.

- Erwarteter Fachfehler: `SzenarioAktion.execute` wirft, wenn der Fehler ausbleibt. Der Mitarbeiter markiert den Auftrag FEHLGESCHLAGEN. Technische Exceptions sind FEHLGESCHLAGEN und zählen nicht als bestandener Negativfall.
- Fachzustand: vor und nach dem erwarteten Fehler liest eine Read-only-Transaktion die fünf Fachtabellen. Neue Journalzeilen sind nur zulässig, wenn der Aktionstext mit `Einsicht: ` beginnt. Jede andere Änderung scheitert den Auftrag. Web-Abweisungen laufen denselben Vergleich im `finally`.
- `WebHelfer.beweiseKeineZahlung` wertet ein Timeout von 1,5 s als fehlenden Freigabe-Button. Das ist eine Oberflächenheuristik. Verbindlich ist der Fachzustand-Schnappschuss der Abweisung. Ein Timeout nach dem Schreibklick allein trägt den Erfolg nicht.
- Bestätigte Web-Schreibschritte sind nicht wiederholbar. Ein toter Treiber auf einem solchen Schritt scheitert den Auftrag, weil der Commit-Ausgang unklar bleibt. Wiederholt werden Navigations- und Anmeldeschritte.
- Browser-Aufräumen beendet nur `chrome.exe`, deren `--user-data-dir` auf ein registriertes Profil mit der Markierung `.testsweet-profile` zeigt (`BrowserProzesse.java`, `testsweet/raeume-fenster.ps1`). In dieser Prüfung wurde kein Prozess beendet.
- Verifikator: genau eine Zeile, NULL scheitert, zusätzliche Zeile scheitert, SQL-Fehler setzt `ok` auf falsch, leere Erwartungen können nicht bestehen. Beträge über `BigDecimal.compareTo`. Eine erneute Prüfung kann VERIFIZIERT zurückstufen.
- Globale Prüfung und Laufabschluss: Erfolg verlangt alle Aufträge VERIFIZIERT, globale Zähler in Ordnung und keine Nachweisfehler. FEHLGESCHLAGEN überspringt der Verifikator und der Lauf bleibt erfolglos. Last- und Stressberichte sind Aggregate; bestanden kommt aus `run-state.json` (`verified === total`, `failed === 0`, `success === true`), nicht aus einem fertigen Kurz-PDF.
- Stressbarriere: Welle 1 hat die IDs `1..N`, Welle 2 `N+1..2N`, `stressPhase1Ende = size/2`. Latch und Indexgate treffen diese Anordnung. Der Generator zählt einen Latch-Countdown je Auftrag einmal.
- Kombinationsgenerator: Signatur enthält Monat, Vermögen, Budget, Workflow, Bescheidzeitraum, Wiedervorlage, neue Miete und Fallsignatur (Regelbedarfsstufe, Merkzeichen, Schwangerschaft, Entbindungsmonat, Warmwasser, Kinderzahlen, KdU, Einkommen, Absetzbeträge). Eine Kollision verwirft die Ziehung und zählt sie nicht doppelt. Seed ungleich 0 wiederholt deterministisch. Der Zertifikatsworker nutzt Seed `20261014`. Zusätzliche Vielfalt aus Budgetüberschuss und Wiedervorlage ändert Daten, nicht zwingend die Leistungsarithmetik; die Signatur verhindert trotzdem stille Doppelzählung.
- PDF, Markdown, Logs und GUI-Zähler des Laufs hängen am selben Auftragszustand. Ein erzeugtes PDF ohne `run-state`-Erfolg ist kein bestandener Lauf.

## 5. Zertifikatskette

Gelesen und gegen den Vertrag gehalten: `CertificateSuiteService`, `CertificateSuiteWorker`, `CertificateSuiteState`, `BuildEvidence`, `LlmReviewService`, `LlmAnswerValidator`, `LlmCalculationReference`, `doc/testzertifikat-werkzeug/` (`certificate-evidence.js`, `run-chronology.js`, `publish-certificate.js`, `llm-answer-json.js`, `llm-response-contract.json`, `llm-reference.js`), `tools/BuildStamp.java`, `tools/evidence-sources.txt`.

Kette: Quellen- und Buildstempel (Klassenort des laufenden Prozesses plus `sourceSha256`/`classesSha256`) → Maven `clean install`, isolierter `LmgConfigTest`, testsweet `clean test` → eigene Worker-JVM und Ports → sieben Pflichtschichten → Fallauswahl mit exakten IDs → Dokumentbytes → Request/Response mit Redaktion des Schlüssels → formale Validierung → Referenzrechnung → Gesamturteil → atomare Veröffentlichung.

Pflichtschichten im Worker: WEB POSITIV 3/60, WEB NEGATIV 3/60, WEB LAST 3/30, FACH POSITIV 8/500, FACH NEGATIV 8/500, FACH LAST 8/120, FACH STRESS 4/21. WEB+STRESS wirft vor dem Serverstart. `latestRuns` lässt `WEB:STRESS` aus der Matrix fallen und schiebt es nicht in `unknown` (`certificate-evidence.js:135`). `notApplicable` enthält `WEB:STRESS` (`355`). Das ist die begründete Nichtanwendbarkeit und kein Grünwaschen.

Zuordnung: je Pflichtschicht der neueste begonnene Lauf. RUNNING, Abbruch, fehlende Berichte, Skips und Fehler bleiben an der Schicht hängen; ein älterer PASS deckt sie nicht zu. Teiltests löschen einen früheren FAIL nicht, solange der Laufmarker nicht COMPLETED ist und die XML-Zusammenführung den FAIL behält. Ein begonnener Neubau schreibt den Marker auf RUNNING. Die Portvergabe bindet einen flüchtigen Socket, merkt den Port, schließt ihn und startet danach den eingebetteten Server; schlägt der Start fehl, bricht `requireEmbedded` ab. Das prüft keinen fremden Server.

Urteile: eine Schicht FAIL ergibt NICHT BESTANDEN, alle PASS ergeben BESTANDEN, sonst UNVOLLSTÄNDIG (`certificate-evidence.js:343`). Ein technischer Suite-Abbruch ist UNVERIFIED, nicht FAIL. Download und Verify verlangen READY und denselben Fingerprint. `collect()` kann während FINALIZING schon BESTANDEN rechnen, bevor die PDF-Datei READY ist; der Worker setzt SUCCESS erst nach READY und BESTANDEN. Das ist der kodierte Vertrag, kein stilles Grün des Downloads.

LLM: höchstens drei Sendeversuche, Pause 30 s, nur bei formal ungültiger Antwort. Eine valide fachliche FAIL-Antwort wird behalten und nicht erneut gesendet. Wiederholungen hängen einen Korrekturhinweis an; die Dokumenttexte bleiben vollständig. Das entspricht dem Produktvertrag und weicht von der Formulierung „identische Sendeversuche“ in der Prüffrage ab, ohne einen festgehaltenen Fach-FAIL zu löschen. Unparsebare Antworten ohne vorläufige FAILs können nach Schema-Korrektur noch PASS werden; das ist Schema-Nachhilfe, kein Löschen eines Fachurteils. Referenzprüfungen erzwingen FAIL, wenn dokumentiertes NIO oder `erwartet ≠ ist` vorliegt, auch wenn das Modell PASS sagt. Testdaten sind im Auftrag als Nicht-Weisungen gekennzeichnet. Ein LLM-PASS ist kein Rechtsbeweis. Transport, formale Gültigkeit, Stichprobenurteil und Zertifikatsumfang bleiben getrennte Stufen.

Java- und Node-JSON-Vertrag: beide lehnen doppelte Schlüssel, Exponenten als EUR, zu große Tiefe und ungepaarte Surrogate ab. `schemaVersion` muss exakt 2 sein. Node geht die Roh-Tokens ab und vertraut nicht auf die Rundung von `JSON.parse`. **DYNAMISCH BELEGT** an den genannten Proben.

Veröffentlichung: Lock mit `wx`, Staging, Fingerprint nach dem PDF-Lauf erneut gegen `collect()`, READY zuletzt (`publish-certificate.js:20`, `38`, `71`, `87`). Ein gesperrtes PDF auf Windows führt den Export in den Fehler, nicht in ein grünes Zertifikat. Die Umbenennung hat keine Wiederholung bei `AccessDeniedException`; das ist fail-closed.

## 6. Bestätigte Befunde

### WB-20261015-01 — Keine Objektberechtigung

- Datei: `src/main/java/de/allgemein/lmg/web/LmgServer.java:208-214`, `292-296`, `332-334`, `349-364`, `436-455`, `476-483`, `502-504`; `src/main/java/de/allgemein/lmg/service/SozialLeistungsService.java:91-100`, `118-131`
- Schwere: HOCH
- Belegsicherheit: HOCH, statisch
- Auslöser: Jede gültige Sitzung, Rolle Sachbearbeiter oder Admin, darf jede Bedarfsgemeinschaft, jeden SozialFall und jede Zahlung lesen und ändern. Die Admin-Pflicht gilt nur für Systemdiagnose, Kassenlauf und Storno. Vier-Augen blockiert die Freigabe der eigenen Anordnung, außer die Rolle ist Admin.
- Auswirkung: Ein angemeldetes Konto liest Bankverbindung, Einkommen und Bescheid fremder Vorgänge, ändert IBAN und Vermögen, erteilt Bescheide und ordnet Auszahlungen an. `GET /api/bedarfsgemeinschaften` und `GET /api/journal` liefern Namen, Aktenzeichen und Journaltexte ohne fallweise Einsicht. Die protokollierte Detail-Einsicht zeichnet den Zugriff auf, lässt ihn aber zu. Ein Replay einer bekannten Vorgangsnummer gibt die IBAN in der Auszahlungsantwort zurück.
- Warum Tests es nicht fangen: `LmgServerHttpTest` prüft 401/403 auf Admin-Routen, den Schrägstrich vor Storno und den zweiten Druckabruf. Eine zweite Kennung gegen einen fremden Vorgang ist dort nicht der Prüffall. Option B/C (Zuständigkeit) ist als Ausbau dokumentiert; der vorliegende Stand bleibt die Lücke, weil eine Einsicht keine Berechtigung ersetzt.

### WB-20261015-02 — Zugangsgeheimnisse in Ausnahme und Startausgabe

- Datei: `src/main/java/de/allgemein/lmg/web/Benutzerverwaltung.java:85-86`; `src/main/java/de/allgemein/lmg/web/LmgServerMain.java:121-125`; Konstante der Standardkonten `Benutzerverwaltung.java:30`
- Schwere: MITTEL
- Belegsicherheit: HOCH, statisch
- Auslöser: Ein fehlerhaftes Segment von `LMG_BENUTZER` wird vollständig in die `IllegalArgumentException` geschrieben. Im Demo-Betrieb gibt die Startzeile die Standardkonten samt Passwörtern auf stdout aus. Die Werte werden in diesem Bericht nicht wiederholt.
- Auswirkung: Prozesslogger, Dienstwrapper und Konsolenmitschnitte erhalten die Klartext-Passwörter. Die Loopback-Sperre verhindert den Demo-Betrieb an einer Netzwerkschnittstelle, nicht das Mitschneiden der lokalen Startzeile.
- Warum Tests es nicht fangen: Tests prüfen den harten Abbruch bei Nicht-Loopback und die erfolgreiche Anmeldung. Sie prüfen nicht, ob die Ausnahme oder stdout frei von Geheimnissen bleibt.

### WB-20261015-03 — Kein TLS

- Datei: `src/main/java/de/allgemein/lmg/web/LmgServer.java:81`
- Schwere: MITTEL
- Belegsicherheit: HOCH, statisch
- Auslöser: Der Server ist ein `HttpServer`. Mit konfigurierten Konten und `lmg.host` ungleich Loopback laufen Anmeldung und Bearer im Klartext.
- Auswirkung: Passwort und Sitzung sind auf dem Netzpfad lesbar. Der Default bleibt Loopback; Demo-Konten sind außerhalb davon verweigert (`LmgServerMain.java:44-49`).
- Warum Tests es nicht fangen: Die HTTP-Tests sprechen den Loopback an und erwarten kein `HttpsServer`.

### WB-20261015-04 — Einbettung der Oberfläche

- Datei: `src/main/java/de/allgemein/lmg/web/LmgServer.java:590`, `963`
- Schwere: NIEDRIG
- Belegsicherheit: HOCH, statisch
- Auslöser: CSP setzt `default-src 'self'` und kein `frame-ancestors`. `X-Frame-Options` fehlt. `default-src` deckt `frame-ancestors` nicht ab.
- Auswirkung: Eine lokale Seite kann die bereits angemeldete Oberfläche einbetten. Öffentliche Seiten scheitern an der Private-Network-Access-Schranke aktueller Chromium-Browser, sobald der Server auf Loopback bleibt.
- Warum Tests es nicht fangen: Header-Tests erwarten CSP und nosniff, nicht `frame-ancestors`.

### WB-20261015-05 — Simulator ohne Anmeldung, Origin leer zulässig

- Datei: `testsweet/src/main/java/de/allgemein/testsweet/SweetServer.java:59`, `623-628`, `139-146`
- Schwere: MITTEL
- Belegsicherheit: HOCH, statisch
- Auslöser: Keine Anmeldung. `Origin` darf fehlen. Bindung und Host-Prüfung bleiben auf Loopback.
- Auswirkung: Ein lokaler Prozess, `curl` oder eine `file://`-Seite auf demselben Rechner kann `POST /api/start`, den LLM-Start und den Zertifikatsstart auslösen und damit die Testdatenbank beschreiben. Eine fremde Browser-Origin scheitert an Host und Origin. Die Statusantwort und die letzten Logzeilen können Aktenzeichen und Namen der Testfälle enthalten; das Passwort der Datenbank steht nicht in der Statusstruktur.
- Warum Tests es nicht fangen: Tests prüfen die Host-Ablehnung und den Path-Traversal. Ein lokaler Aufruf ohne Origin ist der vorgesehene GUI-Pfad und wird als erlaubt behandelt.

### WB-20261015-06 — Drucktoken in der URL

- Datei: `src/main/java/de/allgemein/lmg/web/LmgServer.java:264-277`
- Schwere: NIEDRIG
- Belegsicherheit: HOCH, statisch, Verbrauch **DYNAMISCH BELEGT**
- Auslöser: `window.open` kann keinen Authorization-Header setzen. Das Einmal-Token steht bis zum Abruf in Query, Browser-Historie und gegebenenfalls im Referer gleich-originiger Nachforderungen.
- Auswirkung: Innerhalb von 60 Sekunden und nur für die gebundene BG-ID kann ein Mitleser der URL den Bescheid einmal abrufen. Replay und Parallelabruf liefern einen Treffer. Die Druck-CSP lädt keine fremden Ziele. Die Sitzung selbst steht nicht in der URL.
- Warum Tests es nicht fangen: Der HTTP-Test prüft den zweiten Abruf als abgewiesen. Historie und Referer sind kein automatisierter Fall.

### ZT-20261015-01 — Lokaler Hash ist Konsistenz, keine Urheberschaft

- Datei: `doc/testzertifikat-werkzeug/publish-certificate.js:20`, `71`; `doc/testzertifikat-werkzeug/certificate-evidence.js:355`
- Schwere: NIEDRIG
- Belegsicherheit: HOCH, statisch
- Auslöser: SHA-256 und `evidenceFingerprint` werden aus denselben lokalen Dateien berechnet und beim Export mit einer frischen `collect()`-Berechnung verglichen.
- Auswirkung: Gemeinsames Umschreiben von Beleg und Hash bleibt unsichtbar. Der Vergleich erkennt eine Abweichung zwischen Marker und aktuellem Baum, keinen externen Urheber.
- Warum Tests es nicht fangen: Die Werkzeugtests prüfen, dass ein veränderter Baum den Fingerprint bricht. Sie prüfen keine Signatur eines Dritten.

## 7. Offene Hypothesen

- Weichen die Auftrags-IDs der Stresswelle 1 künftig von `1..N` ab, laufen Latch (nach ID) und Indexgate auseinander. Der aktuelle Generator tut das nicht.
- Die globale Prüfung eines FEHLGESCHLAGEN-Negativauftrags zählt STORNIERT und nicht jede liegengebliebene ANGELEGT-Zeile. Der Lauf bleibt erfolglos, weil der Auftrag nicht VERIFIZIERT ist. Kein grüner Pfad beobachtet.
- Eine Journalzeile mit Präfix `Einsicht: ` ist im Fachzustand-Vergleich ausgenommen. Ein Schreibpfad, der eine echte Buchung nur so tarnt und Zahlung sowie Bescheid unverändert lässt, würde den Schnappschuss bestehen. Ein solcher Produktpfad wurde nicht gefunden.
- Wiederverwendung einer PID kann die Export-Sperre geschlossen halten oder, bei bereits toter PID, einen zweiten Publisher zulassen. Das ist eine Rest-Race-Bedingung und kein belegtes falsches BESTANDEN.
- `TxManager.java:72` kann eine fachliche Meldung in die `TxException` übernehmen. Der HTTP-Fehlerpfad schreibt sie nicht ins JUL. Ob ein anderer Logger das Exception-Objekt ausgibt, ist offen.

## 8. Widerlegte Verdächte

- Erwarteter Fachfehler bleibt aus und der Negativfall gilt als bestanden.
- Technische Fehler zählen als erfolgreiche Negativfälle.
- Verifikator besteht bei NULL, fehlender Zeile, Zusatzzeile, SQL-Fehler oder leerer Erwartung.
- Timeout nach dem Web-Schreibklick beweist allein, dass nichts gespeichert wurde.
- Bestätigte Web-Schreibschritte werden ungesichert wiederholt.
- Browser-Aufräumen beendet fremde Chrome-Profile.
- Drucktoken-Replay, Sitzungstoken in der Query oder doppelter Parallelverbrauch. **DYNAMISCH BELEGT** für die isolierte Verwaltung.
- Admin-Umgehung über einen abschließenden Schrägstrich. Der Pfad wird vor `brauchtAdmin` normalisiert; ein HTTP-Test erwartet 403.
- Sachbearbeiterkennung oder Vier-Augen-Flag aus dem Anfragekörper.
- CSRF auf der Bearer-API oder Festsetzen einer Sitzung über die Anmeldung.
- JSON-Bombe, doppelte Schlüssel, leere Container als Tiefenfehler. **DYNAMISCH BELEGT**. Die erste Leerklammer-Probe war ungültiges JSON.
- Retry mit bereits verbrauchtem Körper. Der Körper wird vor dem Task gepuffert (`LmgServer.java:216-217`, `834-844`).
- Zertifikats-Port prüft einen fremden Server. Fehlstart ist fail-closed.
- WEB-STRESS färbt die Matrix grün oder rot. Der Worker wirft; die Matrix ignoriert die Kombination und markiert sie nicht anwendbar.
- Ein neuerer RUNNING-, FAIL- oder SKIP-Lauf wird von einem älteren PASS verdeckt.
- Ein späteres JUnit-SKIP löscht einen früheren FAIL derselben Schicht.
- Ein fachlicher LLM-FAIL wird durch Wiederholung zu PASS. Eine formal gültige FAIL-Antwort bleibt; vorläufige FAILs aus ungültigen Antworten erzwingen UNVERIFIED.
- `collect()` während FINALIZING ist ein veröffentlichtes grünes PDF. Der Download verlangt READY.
- Ein fertiger Last-Kurzbericht ist der Bestanden-Nachweis. Verbindlich ist `run-state.json`.
- Signaturkollisionen zählen doppelt. Die zweite Ziehung wird verworfen.

## 9. Vollständig gelesene Dateien

Vollständig:

- `src/main/java/de/allgemein/lmg/web/Benutzerverwaltung.java`
- `src/main/java/de/allgemein/lmg/web/Benutzer.java`
- `src/main/java/de/allgemein/lmg/web/Json.java`
- `src/main/java/de/allgemein/lmg/web/HttpServerLimits.java`
- `src/main/java/de/allgemein/lmg/web/LmgServerMain.java`
- `src/main/java/de/allgemein/lmg/service/FachlicheException.java`
- `src/main/java/de/allgemein/lmg/service/Systemdiagnose.java`
- `src/main/java/de/allgemein/tx/TxException.java`
- `src/main/java/de/allgemein/tx/audit/TxAuditEvent.java`
- `src/main/java/de/allgemein/tx/RetryPolicy.java` (Kopf, für die Token-Probe mitübersetzt)
- `testsweet/src/main/java/de/allgemein/testsweet/Verifikator.java`
- `testsweet/src/main/java/de/allgemein/testsweet/GlobaleVerifikation.java`
- `testsweet/src/main/java/de/allgemein/testsweet/WebAktion.java`
- `testsweet/src/main/java/de/allgemein/testsweet/BrowserProzesse.java`
- `testsweet/src/main/java/de/allgemein/testsweet/CertificateSuiteService.java`
- `testsweet/src/main/java/de/allgemein/testsweet/CertificateSuiteState.java`
- `testsweet/src/main/java/de/allgemein/testsweet/CertificateSuiteWorker.java`
- `testsweet/src/main/java/de/allgemein/testsweet/BuildEvidence.java`
- `testsweet/src/main/java/de/allgemein/testsweet/LlmAnswerValidator.java`
- `testsweet/raeume-fenster.ps1`
- `tools/BuildStamp.java`
- `tools/evidence-sources.txt`
- `doc/testzertifikat-werkzeug/publish-certificate.js`
- `doc/testzertifikat-werkzeug/run-chronology.js`
- `doc/testzertifikat-werkzeug/llm-answer-json.js`
- `doc/testzertifikat-werkzeug/llm-response-contract.json`

Schwerpunkt, nicht jede Hilfszeile: `LmgServer.java` (Routing, Auth, Abbildung, Körper, Header), `SweetServer.java` (Routing, localRequest, Start, Export, Statik), `SozialLeistungsService.java` (Liste, Detail, Freigabe, Auszahlung), `TxManager.java` (Rollback-Audit), `TxAuditLog.java`, `BescheidGenerator.java` (Maskierung), `src/main/resources/webapp/app.js` (Maskierung, Dialoge, Drucktoken), `Mitarbeiter.java`, `WebMitarbeiter.java`, `WebHelfer.java`, `SzenarioAktion.java`, `SzenarioBibliothek.java`, `Simulator.java`, `LastBericht.java`, `LlmReviewService.java`, `LlmCalculationReference.java`, `LlmConfig.java`, `certificate-evidence.js`, `llm-reference.js`, Auszüge aus `LmgServerHttpTest.java`.

## 10. Dynamische Proben

Alle unter `tmp/review-k4p9/`, ohne Server und ohne Datenbank.

| Probe | Ergebnis |
|---|---|
| `JsonProbe` gegen `Json.parse` | **DYNAMISCH BELEGT**, Grenzen wie in Abschnitt 3 |
| `node-probe.js` gegen `parseModelAnswer` | **DYNAMISCH BELEGT**, Vertrag wie in Abschnitt 5 |
| `TokenProbe` gegen `Benutzerverwaltung` | **DYNAMISCH BELEGT**, ein Paralleltreffer, kein Replay, keine falsche BG, kein Abruf nach Abmeldung, Sitzung ist kein Drucktoken |
