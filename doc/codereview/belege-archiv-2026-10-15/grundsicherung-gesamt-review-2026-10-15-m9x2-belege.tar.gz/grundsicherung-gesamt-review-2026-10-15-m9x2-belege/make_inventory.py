import os
import hashlib
import subprocess
from datetime import datetime

root_dir = os.path.abspath(".")
belege_dir = os.path.join(root_dir, "doc", "codereview", "grundsicherung-gesamt-review-2026-10-15-m9x2-belege")
os.makedirs(belege_dir, exist_ok=True)

files_to_hash = []

def add_dir(rel_path):
    full_path = os.path.join(root_dir, rel_path)
    if not os.path.isdir(full_path):
        return
    for dirpath, _, filenames in os.walk(full_path):
        for f in filenames:
            files_to_hash.append(os.path.join(dirpath, f))

def add_file(rel_path):
    full_path = os.path.join(root_dir, rel_path)
    if os.path.isfile(full_path):
        files_to_hash.append(full_path)

add_dir("src")
add_dir(os.path.join("testsweet", "src"))
add_dir("ddl")
add_dir("tools")
add_dir(os.path.join("doc", "testzertifikat-werkzeug"))
add_file("pom.xml")
add_file(os.path.join("testsweet", "pom.xml"))
add_file("README.md")
add_file("AGENTS.md")
add_file(os.path.join("doc", "rechtsgrundlagen.md"))
add_file(os.path.join("doc", "projektbeschreibung.md"))
add_file(os.path.join("doc", "architektur.md"))
add_file(os.path.join("doc", "leistungsmanagement.md"))
add_file(os.path.join("doc", "regressionstests.md"))
add_file(os.path.join("doc", "roadmap.md"))

files_to_hash = sorted(list(set(files_to_hash)))

def get_git_output(cmd):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, cwd=root_dir).strip()
    except Exception as e:
        return f"Error: {e}"

head_commit = get_git_output("git rev-parse HEAD")
head_branch = get_git_output("git rev-parse --abbrev-ref HEAD")

lines = [
    "# SHA-256 Inventar des Prüfstands 2026-10-15",
    f"# Erfasst: {datetime.now().isoformat()}",
    f"# Git Commit: {head_commit}",
    f"# Git Branch: {head_branch}",
    f"# Gesamtanzahl erfasster Dateien: {len(files_to_hash)}",
    ""
]

for fpath in files_to_hash:
    rel_path = os.path.relpath(fpath, root_dir).replace("\\", "/")
    h = hashlib.sha256()
    with open(fpath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    lines.append(f"{h.hexdigest()}  {rel_path}")

out_path = os.path.join(belege_dir, "sha256-inventar.txt")
with open(out_path, "w", encoding="utf-8") as out:
    out.write("\n".join(lines) + "\n")

print(f"Inventar erfolgreich geschrieben: {len(files_to_hash)} Dateien nach {out_path}")
