# Teilbericht C: Web, Berechtigungen, Sozialdaten, Simulator, Zertifikats- und GLM-Kette

**PrÃ¼fbasis**
- GeprÃ¼ft wurde die eingefrorene Kopie `C:\Users\tnickel\AppData\Local\Temp\lmg-r7w2\repo`. Alle Zeilennummern stammen aus dieser Kopie.
- Den fremden Zertifikatslauf habe ich nur lesend ausgewertet. Letzter Stand: 2026-10-15, 15:06 MESZ (13:06:40Z).
- Ich habe nichts geÃ¤ndert und weder auf die Datenbank, auf Port 8080/8095 noch auf mvn oder fremde Prozesse zugegriffen.

**Dynamisch ausgefÃ¼hrt wurden nur diese zwei Proben:**
- **P1, Json-Probe** (JDK 25.0.4.1, ohne DB und Server):
  - Befehl: `cd â€¦\lmg-r7w2\probe-C; java -cp '..\repo\target\classes' JsonProbe.java`
  - Abgewiesen: doppelter SchlÃ¼ssel (â€ždoppelter ObjektschlÃ¼sselâ€œ), `01` (â€žfÃ¼hrende Nullâ€œ), U+0661 (â€žZahl erwartetâ€œ), `.5`, `1.` (â€žNachkommastelle erwartetâ€œ), `1e1000` (â€žExponent auÃŸerhalb Â±999â€œ), 65 Ziffern, Tiefe 129 (â€žzu tief (max 128)â€œ), Restzeichen nach dem JSON, `\u12G4`, einzelnes Surrogat `\uD800`.
  - Akzeptiert: `1e999` â†’ 1E+999, `1e-999` â†’ 1E-999, `{}`, `[]`, 128-fach geschachtelt, `"12.34"` als String, `12.345` als BigDecimal, `-0` â†’ 0.
- **P2, Node-Vergleich** der kopierten LLM-Requests `probe-C\llm\request-20-attempt-1.json` und `request-20-attempt-2.json`:
  - Die System-Nachricht ist identisch (164 Zeichen).
  - Die User-Nachricht hat 41643 gegenÃ¼ber 42405 Zeichen. Versuch 2 hÃ¤ngt `=== KORREKTURANWEISUNG ===` mit Fehlertext und einer Liste von Check-IDs an.
  - model, temperature 0.1, max_tokens 16384, thinking und response_format sind gleich.

Alle Ã¼brigen Aussagen sind **STATISCH BELEGT** oder beruhen auf gelesenen Belegen.

**Kurzurteil:**
- Web-HÃ¤rtung, Parser, Drucktoken, Simulator-Verifikation und die Urteilslogik der Zertifikatskette sind Ã¼berwiegend solide. Ich habe keinen Pfad gefunden, auf dem ein erheblicher Fehler als BESTANDEN ausgewiesen wird.
- Die gewichtigsten Punkte:
  1. Es gibt keine Objektberechtigung nach ZustÃ¤ndigkeit (Need-to-know); das ist eine dokumentierte Grenze.
  2. Eine Zahlung ohne Bescheid ist zulÃ¤ssig. Dieser Demo-Buchungsweg liegt in Produktivlogik ohne Betriebsschalter, und der Simulator prÃ¼ft ihn als Sollverhalten.
  3. Die Node-Urteils- und ParitÃ¤tstests laufen nicht in der Zertifikatspipeline.
- Die frischen LÃ¤ufe tragen **keinen belastbaren Lastnachweis**.

---

## A) PrÃ¼ffeld-Statustabelle

| PrÃ¼ffeld | Status | BegrÃ¼ndung / Fundstellen |
|---|---|---|
| 1 Endpunktmatrix LmgServer | GEPRÃœFT (statisch) | LmgServer L104â€“263, 299â€“301, 315â€“531, 546â€“562; Benutzerverwaltung |
| 1 Endpunktmatrix SweetServer | GEPRÃœFT (statisch) | SweetServer S59â€“224, 625â€“644, 773 |
| 1 Objektzugriff/IDOR, Herkunft der IdentitÃ¤t | GEPRÃœFT | Kennung stammt nur aus dem Bearer-Token (L202â€“210). Ein ZustÃ¤ndigkeitsmodell fehlt (C-01). |
| 2 Sitzung, Timeout, Drosselung, Drucktoken | GEPRÃœFT (statisch) | Benutzerverwaltung B32â€“B226 |
| 2 XSS (SPA, Druck, Bescheid-HTML, Simulator-GUI) | GEPRÃœFT (statisch) | BescheidGenerator 130â€“149, 265â€“287 (escapeHtml, auch im `<title>`); app.js 24 innerHTML/39 esc; sweet/app.js |
| 2 CSP, nosniff, no-store, frame-ancestors | GEPRÃœFT (statisch) | L147/161/171/188/596/609/1002. Ob Inline-`style` die CSP verletzt (CR-16), ist nur im Browser prÃ¼fbar â†’ E |
| 2 CSRF/CORS | NICHT ANWENDBAR / GEPRÃœFT | LmgServer nutzt Bearer-Header und keine Cookies. Einen Host-/Origin-Check habe ich im LmgServer nicht gefunden (ohne Token wirkungslos). SweetServer prÃ¼ft Host und Origin (S625â€“631). |
| 2 JSON-Parser, Typen, Geldwerte | GEPRÃœFT (P1 dynamisch + statisch) | Json L142/379; LmgServer L895â€“932; SozialLeistungsService 969â€“983 â†’ C-05 |
| 2 Timeouts, Ãœberlast, Body-Grenzen | GEPRÃœFT (statisch) | HttpServerLimits 18â€“20; 503 bei L180/L250; Body â‰¤ 1 MB; SweetServer S633â€“640 |
| 2 SQL- und Pfadinjektion | TEILWEISE | IDs nur Ã¼ber `\d{1,18}`/parseLong; statische Dateien Ã¼ber Whitelist; SQL der Fachschicht nicht im Detail (anderes Teilgebiet) |
| 3 Sozialdaten in Logs/Fehlern | TEILWEISE | JUL nur Ã¼ber `TxAuditLog.fehlerBeschreibung` (L125/185/255/835); 500-Antworten nur mit Code. JMX und Rotation nicht geprÃ¼ft. LLM-Belege enthalten nur synthetische SWEET-Daten. |
| 3 Revisions- und Manipulationsschutz | GEPRÃœFT | Nur lokale Hashes (ZT-01). Eine Behauptung â€žrevisionssicher/manipulationssicherâ€œ habe ich in doc/testzertifikat-werkzeug nicht gefunden (grep). |
| 4 Verifikator und GlobaleVerifikation | GEPRÃœFT (statisch) | Verifikator (156 Z.), GlobaleVerifikation (81 Z.), Simulator 1083â€“1099 |
| 4 NegativfÃ¤lle (Fachfehler â‰  technischer Fehler) | GEPRÃœFT | Mitarbeiter 83â€“98; SzenarioAktion 44â€“63; SzenarioBibliothek 1860â€“1875 |
| 4 Webmodus (Wiederholung, Recovery, Fachzustand) | GEPRÃœFT (statisch) | WebMitarbeiter 143â€“240; Fachzustand 40â€“43 |
| 4 Browser-AufrÃ¤umen | GEPRÃœFT | BrowserProzesse 20â€“102: nur Prozesse mit eigenem Profil und Markerdatei |
| 4 Datenhygiene | GEPRÃœFT | Simulator 1036, 1058â€“1081; SzenarioBibliothek 917â€“960 â†’ C-04 |
| 4 Kombinationsgenerator | TEILWEISE | Seed deterministisch (Worker Z. 35, 20261014); auf Signaturkollisionen nicht vollstÃ¤ndig geprÃ¼ft |
| 4 Last- und Stress-Aggregate | TEILWEISE | LastBericht 257â€“259/333â€“335, Simulator 290â€“297 â†’ C-07; nur Belege, keine eigenen Lastproben |
| 5 Build-/Quellbindung | GEPRÃœFT (statisch) | BuildStamp 121â€“135, 156â€“175 â†’ C-08 |
| 5 LLM-Kette (Retry, Validierung, Referenz, Urteil) | GEPRÃœFT (statisch + P2) | LlmReviewService 43, 205â€“325, 595â€“612, 815â€“940 â†’ C-06 |
| 5 VerÃ¶ffentlichung und Export | GEPRÃœFT (statisch) | publish-certificate.js P28â€“40/100â€“105; CertificateSuiteState 34â€“51; Downloadsperre S76 â†’ C-09 |
| 5 Node-Tests in der Pipeline | GEPRÃœFT | Werden nicht ausgefÃ¼hrt â†’ C-03 |
| 6 Frischer fremder Lauf | GEPRÃœFT (lesend) | Abschnitt D; noch RUNNING |
| 7 Historische Berichte | TEILWEISE | k4p9, 3c909c2, beide grok-Berichte, testsweet-abdeckung, zertifikat-saga und v0.5.8-CR gegen den Code geprÃ¼ft. fixbericht und die beiden 2026-10-13-Berichte nur Ã¼ber Folgeberichte und Code nachgeprÃ¼ft, nicht einzeln vollstÃ¤ndig gelesen. |
| Web-STRESS | NICHT ANWENDBAR | BegrÃ¼ndet blockiert (eigene Pflicht-N/A) |
| Dynamische HTTP-/DB-Proben | NICHT GEPRÃœFT | Durch Auftrag verboten |

---

## B) Endpunktmatrix

### B.1 LmgServer

**Gemeinsame Eigenschaften:**
- Header: nosniff, no-store, CSP mit `frame-ancestors 'none'`.
- Body â‰¤ 1 MB, gecacht (fÃ¼r Tx-Retry).
- IdentitÃ¤t stammt ausschlieÃŸlich aus dem Sitzungstoken, nie aus dem Body.
- Fehlerabbildung:
  - Fachfehler: 404 (NICHT_GEFUNDEN), 403 (BERECHTIGUNG), 405 (METHODE), alle anderen 400. Auch KONKURRENZ ergibt 400 (L237â€“239; INFO).
  - 409 AUSGANG_UNBEKANNT (L243), 503 UEBERLAST (L250), 500 TECHNISCH (L256), 400 VALIDATION (L260).
- Unbekannter Pfad â†’ 404; bekannter Pfad mit falscher Methode â†’ 405 (L546â€“562).

| Methode / Pfad | Anmeldung | Rolle / Objektzugriff | Validierung | Schreibwirkung | Status | Protokoll |
|---|---|---|---|---|---|---|
| GET/HEAD statische Whitelist | nein | â€“ | Whitelist, nur GET/HEAD (CR-61) | â€“ | 200/404/405 | â€“ |
| GET `/api/bedarfsgemeinschaften/{id}/bescheid/druck?token=` (L112) | Einmal-Drucktoken statt Bearer | Token an Sitzung **und** BG gebunden, 60 s, einmalig, synchronized (B200â€“B220) | `\d{1,18}` | Token wird verbraucht | 200/400 (L173)/401 (L149)/503 (L180)/500 (L190) | JUL bei Fehlern (L185); Token steht in der URL (WB-06-Rest) |
| POST `/api/anmeldung` (L315) | nein | â€“ | Drosselung 5 Fehlversuche/30 s je Kennung, Deckel 1024 (B33ff) | Sitzung | 200 / Fachfehler | â€“ |
| POST `/api/abmeldung` (L323) | Bearer | â€“ | â€“ | Sitzung und zugehÃ¶rige Drucktoken gelÃ¶scht (B223â€“226) | 200 | â€“ |
| GET `/api/werbin` (L327) | Bearer | â€“ | â€“ | â€“ | 200 | â€“ |
| POST `/api/drucktoken` (L330) | Bearer | **jede** BG | BG-ID | Token (60 s) | 200/4xx | â€“ |
| GET `/api/bedarfsgemeinschaften` (L339) | Bearer | **alle** BG (ohne Bankdaten) | â€“ | â€“ | 200 | â€“ |
| POST `/api/bedarfsgemeinschaften` (L342) | Bearer | jeder SB | TypprÃ¼fung L895â€“932 | BG + Journal | 200/400 | Journal |
| GET `/api/bedarfsgemeinschaften/{id}[?monat]` (L356) | Bearer | **jede** BG (kein Need-to-know) | parseLong | â€“ | 200/404 | Einsichtsaudit |
| PUT `/api/bedarfsgemeinschaften/{id}` (L362) | Bearer | jede BG | Version | UPDATE + Journal | 200/400 | Journal |
| GET, POST, PUT `/api/bedarfsgemeinschaften/{id}/bescheid` (L376/382/392) | Bearer | jede BG | Zeitraum etc. (Fachschicht) | Bescheid + Journal | 200/400/404 | Journal |
| POST `/api/bedarfsgemeinschaften/{id}/sozialfaelle` (L401) | Bearer | jede BG | betragWert (C-05) | Fall + Journal | 200/400 | Journal |
| PUT `/api/sozialfaelle/{id}` (L427) | Bearer | jeder Fall | betragWert, Version | Fall + Journal | 200/400 | Journal |
| POST `/api/auszahlung` (L455) | Bearer | jede BG | BescheidPaymentBinding, **Demoweg** (C-02) | Zahlung | 200/400/409/503 | Journal |
| POST `/api/kassenlauf` (L476) | Bearer + **Admin** (L209/L301) | **alle** BEREIT-Zahlungen global | â€“ | Ãœbergabe | 200/403 | Journal |
| POST `/api/saga/antrag` (L483) | Bearer | jeder SB | Saga | BG, Fall, Bescheid, Zahlung | 200/4xx/409 | Journal/Saga |
| POST `/api/zahlungen/{id}/freigabe` (L495) | Bearer | Kennung + Adminflag an den Service (L500; Vier-Augen in der Fachschicht) | â€“ | Freigabe | 200/400/403 | Journal |
| POST `/api/zahlungen/{id}/storno` (L504) | Bearer + **Admin** (L506) | â€“ | â€“ | Storno | 200/403 | Journal |
| GET `/api/zahlungen` (L514) | Bearer | **global** | â€“ | â€“ | 200 | â€“ |
| GET `/api/journal` (L521) | Bearer | **global** | â€“ | â€“ | 200 | â€“ |
| GET `/api/system/status`, `/api/system/db-identity` (L525/528) | Bearer + Admin | â€“ | â€“ | â€“ | 200/403 | â€“ |
| POST `/api/system/wiederanlauf` (L531) | Bearer + Admin | â€“ | â€“ | Saga-Wiederanlauf | 200/403 | Journal/Saga |

### B.2 SweetServer (Simulator-GUI)

**Gemeinsame Eigenschaften:**
- Gebunden an 127.0.0.1 (S59). Host muss `127.0.0.1:port` oder `localhost:port` sein; Origin leer oder gleich dem Host, sonst 403 (S72, S625â€“631).
- **Keine Anmeldung und keine Rollen.**
- Body â‰¤ 1 MiB (S633â€“640). HttpServerLimits gilt (S58). Nur 4 Threads.
- Fehlerabbildung: IllegalArgumentException â†’ 400, IllegalStateException â†’ 409, sonst 500 mit dem Klassennamen (S215â€“220).
- Kein Zugriffsprotokoll.
- WÃ¤hrend einer Suite liefern alle Downloads 409 (S76).

| Methode / Pfad | MethodenprÃ¼fung | Guard | Wirkung |
|---|---|---|---|
| GET `/api/zertifikat/tests/status`, `/glm-protokoll` (S81/85) | ja | â€“ | lesen |
| GET `/api/llm/grundlagen`, `/pruefauftrag`, `/pruefmenge` (S89â€“110) | ja | â€“ | lesen |
| POST `/api/zertifikat/tests/start` (S111) | ja | Suite-Sperre (CertificateSuiteService C130) | startet Worker-JVM (Gesamtlauf mit `aufraeumen=true`) |
| POST `/api/zertifikat/tests/stop` (S134) | ja | â€“ | Abbruch |
| `/api/status` (S138) | **jede Methode** | â€“ | lesen (INFO) |
| POST `/api/start` (S139) | ja | requireNoCertificateSuite (S231) | Simulatorlauf, ggf. AufrÃ¤umen `SWEET-%` |
| POST `/api/stop` (S146) | ja | S149 | Abbruch |
| `/api/pdf`, `/api/md` (S154/155) | jede | S76 (409 wÃ¤hrend Suite) | Download |
| POST `/api/zertifikat` (S156) | ja | S773 | Zertifikat erzeugen |
| `/api/zertifikat/pdf`, `/api/llm/report/pdf` (S163/196) | jede | S76 | Download |
| `/api/auftraege`, `/api/testfaelle`, `/api/llm/status`, `/api/llmpruefung`, `/api/auftrag/{id}` | jede | â€“ | lesen |
| GET/POST `/api/llm/config` (S166â€“174) | ja | S170 | **Ã¤ndert Modell bzw. baseUrl** |
| POST `/api/llm/test` (S176â€“180) | ja | S178 | externer Verbindungstest |
| POST `/api/llm/start` (S182) | ja | S185 | sendet Falltexte an das externe LLM |
| POST `/api/llmpruefung/paket` (S198â€“203) | ja | S200 | PrÃ¼fpaket |
| GET sonst | â€“ | â€“ | statische Dateien (S208â€“209); sonst 404 mit RÃ¼ckgabe des Pfads (S211) |

---

## C) BestÃ¤tigte Befunde

### C-01: Kein Need-to-know bzw. keine Objektberechtigung nach ZustÃ¤ndigkeit
- **Einstufung:** MAJOR; fÃ¼r einen Produktivbetrieb Freigabehindernis bzw. KRITISCH. STATISCH BELEGT.
- **Fundstellen:** LmgServer L339, L356â€“360, L362, L376â€“431, L455, L495â€“500, L514, L521.
- **Dokumentation:** Die Grenze ist als Einmandanten-Grenze bzw. â€žOption Dâ€œ beschrieben (architektur.md 173â€“178, 399â€“401).
- **Verletzte Regel:** Erforderlichkeit und Zweckbindung bei Sozialdaten (Â§ 35 SGB I, Â§Â§ 67 ff. SGB X, Art. 5 Abs. 1 lit. c und Art. 25 DSGVO). Ein protokollierter Zugriff ersetzt keine Berechtigung.
- **Ablauf:**
  1. Ein beliebiger angemeldeter Sachbearbeiter ruft `GET /api/bedarfsgemeinschaften/{fremdeId}` bzw. `PUT /api/sozialfaelle/{id}` auf.
  2. Es gibt nur eine TokenprÃ¼fung (L202â€“210).
  3. Ergebnis: Er liest und Ã¤ndert jede BG und gibt Auszahlungen fÃ¼r jede BG ein. `/api/zahlungen` und `/api/journal` sind global sichtbar.
- **Soll:** ZustÃ¤ndigkeit (Team/Sachgebiet) je BG wird serverseitig geprÃ¼ft. **Ist:** Nur RollenprÃ¼fung fÃ¼r Admin-Pfade.
- **Mildernd:** Einsicht wird auditiert; Ãœbersichten enthalten keine Bankdaten.
- **GegenprÃ¼fung:** Weder im Service noch im DAO gibt es einen ZustÃ¤ndigkeitsfilter. Es fehlt auch ein Test, der den Zugriff auf eine fremde BG mit 403 erwartet.
- **Reparatur (nicht umsetzen):** Zuordnung BGâ†’Team, PrÃ¼fung im Service-Eintritt (`ladeDetail`/`aendere*`/`erfasse*`) und Filter in Listen.
- **Regressionstest:** sb-01 ist Team A und BG X gehÃ¶rt zu Team B. Erwartet wird:
  - GET, PUT und Auszahlung auf X liefern 403 BERECHTIGUNG;
  - die Liste enthÃ¤lt X nicht;
  - der Journal-Eintrag â€žverweigertâ€œ existiert.
- **Historische ID:** FB-20261015-04 (k4p9).

### C-02: Zahlung ohne Verwaltungsakt in Produktivlogik; der Simulator verifiziert sie als Soll
- **Einstufung:** MAJOR, STATISCH BELEGT. Die rechtliche Wertung gehÃ¶rt zum Fach-Reviewer.
- **Fundstellen:**
  - `BescheidPaymentBinding.verify` Z. 18â€“21: `if (zaehleFuerBg(..) == 0) return;`
  - Aufrufer: SozialLeistungsService 319 und AntragsSagaProzess 406.
  - Endpunkte: POST `/api/auszahlung` (L455) und `/api/saga/antrag` (L483).
- **Dokumentation:** Als â€žDemowegâ€œ beschrieben (architektur.md 255, leistungsmanagement.md 158). Es gibt **keinen** Betriebsmodusschalter: Demokonten sind auÃŸerhalb von Loopback gesperrt, dieser Buchungsweg nicht.
- **Ablauf:**
  1. FÃ¼r eine BG wird kein Bescheid erteilt; der Bescheid scheitert z. B. an der Validierung von>bis (SzenarioBibliothek 1659â€“1662).
  2. Auszahlung 2026-07 â†’ Zahlung Ã¼ber den berechneten Betrag, Freigabe und Ãœbergabe.
  3. Fall SWEET-N-0029 (TF29): Der Simulator erwartet genau das als Sollverhalten (Erwartungen ab 1860ff.).
- **Soll:** Im Produktivbetrieb keine Zahlung ohne bestandskrÃ¤ftigen bzw. erlassenen Bescheid; der Demoweg nur mit explizitem Demo-Schalter. **Ist:** Immer aktiv.
- **Auswirkung:**
  - Fachlich: Auszahlung ohne Verwaltungsakt.
  - PrÃ¼fwerkzeug: Die Simulatorschicht weist TF29 als bestanden aus. Das GLM bewertet denselben Fall als FAIL (im fremden Lauf b20 provisional).
  - Das Zertifikat scheitert deshalb nur, wenn TF29 in der GLM-Stichprobe liegt. Ob TF29 immer ausgewÃ¤hlt wird, ist nicht nachgewiesen (â†’ E-04).
- **GegenprÃ¼fung:** Kein Test erwartet die Ablehnung einer Zahlung ohne Bescheid im Produktivmodus.
- **Reparatur:** Betriebsmodus-Flag (Default: produktiv = Bescheidpflicht). Den Simulator-Fall TF29 je Modus auf die Erwartung â€žVALIDATION, keine Zahlungâ€œ umstellen.
- **Regressionstest:** Produktivmodus, BG ohne Bescheid, `POST /api/auszahlung`. Erwartet:
  - 400 VALIDATION;
  - `COUNT(ZAHLUNG WHERE BG_ID)=0`;
  - BUDGET_REST unverÃ¤ndert.
- **Historische ID:** neu (in der NÃ¤he von TF29 und GLM-Befunden).

### C-03: Node-Urteilslogik und ParitÃ¤tstests laufen nicht in der Zertifikatspipeline
- **Einstufung:** MINOR (mit Potenzial zu MAJOR), STATISCH BELEGT.
- **Betroffene Tests:** certificate-evidence.test.js, llm-reference.test.js, llm-answer-parity.test.js, testsweet/src/test/js/* (u. a. llm-ui.test.js, produkt-ui-review.test.js). Der Worker ruft nur `node publish-certificate.js --publish` auf (CertificateSuiteWorker Z. 65). Nur das Java-GegenstÃ¼ck `LlmAnswerParityTest` lÃ¤uft Ã¼ber JUnit.
- **Verletzte Regel:** â€žJava-/Node-Vertrag und unabhÃ¤ngige Referenz dÃ¼rfen nicht auseinanderlaufen (ParitÃ¤tskorpus)â€œ; das Zertifikat muss den PrÃ¼fstand seiner eigenen UrteilstrÃ¤ger binden.
- **Auswirkung:** Eine Regression in certificate-evidence.js, llm-evidence.js oder generate.js, also dem Code, der BESTANDEN ausspricht, wÃ¼rde vom Zertifikatslauf nicht erkannt.
- **Reparatur:** In der Pipeline vor `--publish` `node --test` Ã¼ber alle Werkzeug- und JS-Tests als Pflichtschicht ausfÃ¼hren und deren Ergebnis im Manifest binden.
- **Regressionstest:**
  - Pipeline mit absichtlich gebrochenem ParitÃ¤tskorpus â†’ Gesamturteil NICHT BESTANDEN bzw. UNVOLLSTÃ„NDIG.
  - Schicht â€žNODEâ€œ im Manifest mit Testanzahl > 0 und 0 Fehlern.
- **Historische ID:** GR-09 (3c909c2), Rest.

### C-04: PrÃ¤fixbasiertes AufrÃ¤umen ohne DB-ExklusivitÃ¤t und ohne TestdatenbankprÃ¼fung
- **Einstufung:** MINOR, STATISCH BELEGT.
- **Fundstellen:**
  - Simulator 1058â€“1081 lÃ¶scht JOURNAL, BESCHEID, ZAHLUNG, SOZIAL_FALL und BG aller `AKTENZEICHEN LIKE 'SWEET-%'` sowie Kassenjournale `sb-sim-%`.
  - Der Worker setzt `aufraeumen=true` (Z. 35).
  - `requireNoCertificateSuite` (S644) kennt nur das In-Prozess-Flag bzw. `suite-current.json` **desselben** Checkouts (C33â€“37, C84).
  - Kein DB-Lock. Keine Allowlist fÃ¼r Test-DBs (Default tx_demo).
- **Ablauf:** Zwei SweetServer bzw. CLIs aus unterschiedlichen Checkouts arbeiten gegen dieselbe DB. Lauf B rÃ¤umt die SWEET-Daten von Lauf A weg.
- **Auswirkung:**
  - Lauf A schlÃ¤gt sichtbar fehl (Verifikator: keine Zeile â†’ false; GlobaleVerifikation zÃ¤hlt global). Es entsteht **kein falscher Erfolg**.
  - Gegen eine falsch konfigurierte Nicht-Test-DB werden SWEET-Altdaten gelÃ¶scht.
  - Kassenjournale anderer Kennungen aus dem Web-Modus bleiben liegen.
- **Mildernd:** `pruefeKeineAltenAktenzeichen` (1036) bricht ab, wenn Altdaten vorhanden sind und nicht aufgerÃ¤umt wird.
- **Reparatur:**
  - Lauf-ID-Spalte bzw. eigenes PrÃ¤fix je Lauf.
  - `DBMS_LOCK` oder eine Sperrtabelle.
  - Allowlist der Test-DB-IdentitÃ¤t (Ã¼ber `/api/system/db-identity` bzw. JDBC-URL).
- **Regressionstest:**
  - Zweiter Simulator mit aktiver DB-Sperre â†’ Start wird mit klarer Meldung abgelehnt.
  - DB-IdentitÃ¤t nicht in der Allowlist â†’ kein DELETE ausgefÃ¼hrt.
- **Historische ID:** CR-49 sowie der k4p9-Hinweis â€žAufrÃ¤umen lÃ¶scht fremde SWEET-Datenâ€œ.

### C-05: Geldwerte werden still zu 0,00 gesetzt bzw. still gerundet
- **Einstufung:** MINOR. Parseranteil DYNAMISCH BELEGT (P1), Ãœbernahme in die Fachwerte STATISCH BELEGT.
- **Fundstellen:**
  - LmgServer `betragWert` L932: null bzw. fehlender SchlÃ¼ssel â†’ 0.00. Ein Nicht-BigDecimal wird korrekt abgewiesen; Skala und GrÃ¶ÃŸe werden aber nicht geprÃ¼ft.
  - `SozialLeistungsService.normiereBetrag` 969â€“983: `setScale(2, HALF_UP)`.
  - Unbekannte SchlÃ¼ssel werden ignoriert.
  - Betroffene Endpunkte: L342, L401, L427, L362 und weitere mit Geldfeldern.
- **Ablauf:**
  - `PUT /api/sozialfaelle/{id}` mit `{"kdumiete": 450.00, â€¦}` (Tippfehler) bzw. als Teilobjekt â†’ `kduMiete` wird 0.00 und gespeichert.
  - `12.345` wird zu 12.35, `1e-999` zu 0.00 (Parser akzeptiert beides, P1).
- **Soll:** Fehlende Pflicht-Geldfelder, unbekannte SchlÃ¼ssel und mehr als 2 Nachkommastellen liefern 400 VALIDATION. **Ist:** stille Koerzierung.
- **Auswirkung:** Falsche Bedarfs- bzw. EinkommensansÃ¤tze. Die eigene SPA sendet immer vollstÃ¤ndige Objekte; das Risiko trifft API-Clients und Simulator-/Fremdintegrationen.
- **Reparatur:** In `betragWert` Pflichtfeld- und `scale() â‰¤ 2`-PrÃ¼fung ergÃ¤nzen; Allowlist der SchlÃ¼ssel je Endpunkt.
- **Regressionstest:** Drei Anfragen, jeweils mit erwartetem 400 und unverÃ¤ndertem `SOZIAL_FALL`:
  - `{"kduMiete":12.345}`
  - Teilobjekt ohne `kduMiete`
  - unbekannter SchlÃ¼ssel
- **Historische ID:** CR-11 (Rest).

### C-06: Retry-Vertrag â€židentische Sendeversucheâ€œ nicht eingehalten
- **Einstufung:** MINOR, DYNAMISCH BELEGT (P2) und statisch (LlmReviewService 205â€“325, `korrekturAnweisung` 595â€“612).
- **Ist:** Ab Versuch 2 wird `=== KORREKTURANWEISUNG ===` mit Fehlertext und Check-ID-Liste angehÃ¤ngt (+762 Zeichen in b20). HÃ¶chstens 3 Versuche, 30 s Pause, nur bei formal ungÃ¼ltiger Antwort. HTTP-Fehler und Timeout ergeben sofort ERROR. Sollwerte werden nicht mitgesendet.
- **Soll laut Vertrag:** hÃ¶chstens drei **identische** Versuche.
- **Auswirkung:**
  - Vertrag und Implementierung widersprechen sich; AGENTS.md dokumentiert die Abweichung.
  - Der Hinweis kann die Modellausgabe steuern, und die Reproduzierbarkeit â€žgleicher Inputâ€œ geht verloren.
  - Fachliche FAILs werden **nicht** wegwiederholt: provisionalFailures bleiben erhalten; PASS mit provisional ergibt UNVERIFIED.
- **Reparatur:** Den Vertrag ausdrÃ¼cklich auf â€židentischer PrÃ¼finhalt plus formaler Korrekturhinweis ohne Sollwerteâ€œ Ã¤ndern und den Hash des Basis-Prompts je Versuch im Manifest binden. Alternativ wirklich identisch senden.
- **Regressionstest:** Bei drei Versuchen gilt:
  - `sha256(basePrompt)` ist gleich;
  - Differenz ausschlieÃŸlich im Korrekturblock;
  - der Korrekturblock enthÃ¤lt keine BetrÃ¤ge aus der Referenz.
- **Historische ID:** Retry-Vertrag (AGENTS.md); neu als Befund.

### C-07: Durchsatz aus abgeschnittenen Sekunden; Lastschicht ohne belastbare Kennzahlen
- **Einstufung:** MINOR, STATISCH BELEGT; der Belegwert wurde gelesen.
- **Fundstellen:** Simulator 290â€“297 (`Duration.toSeconds()` schneidet ab); LastBericht 257â€“259/333â€“335 (gesamtÂ·60/Sekunden).
- **Ablauf:** FACH LAST mit 120 AuftrÃ¤gen in ~2,1 s ergibt â€ž3600/minâ€œ (Beleg `run-20261015-142459`). Unter 1 s ergÃ¤be sich 0.
- **Auswirkung:** Die Kennzahl ist um bis zu ~50 % verzerrt. Ohne Perzentile und Ressourcenmetriken (CPU, Pool, DB-Wartezeit) und bei LÃ¤ufen von 2â€“64 s gibt es keinen Lastnachweis, der â€žLasttest bestandenâ€œ fachlich trÃ¤gt.
- **Reparatur:** Millisekunden-Basis (`toMillis()/60000.0`), Perzentile p50/p95/p99, Mindestlaufdauer und SÃ¤ttigungsstufen.
- **Regressionstest:** Laufdauer 2100 ms und 120 AuftrÃ¤ge â†’ Durchsatz 3428,6/min Â± 0,1; Laufdauer 800 ms â†’ Wert > 0.

### C-08: Quellinventar unvollstÃ¤ndig; fehlende Pfade werden still Ã¼bersprungen
- **Einstufung:** MINOR, STATISCH BELEGT.
- **Fundstellen:**
  - BuildStamp 168 (`if(!Files.exists(entry))continue;`), 156â€“175.
  - tools/evidence-sources.txt enthÃ¤lt u. a. nicht doc/rechtsgrundlagen.md, die README des Werkzeugs und xml-js.
- **Ablauf:** Ein Eintrag ist umbenannt oder gelÃ¶scht bzw. eine relevante Datei fehlt in der Liste. Der Fingerprint `sourceSha256` Ã¤ndert sich dann nicht bzw. deckt die Datei nie ab.
- **Auswirkung:** Die Bindung â€žZertifikat â†” Quellstandâ€œ lÃ¼ckt, ohne dass es sichtbar wird.
- **Mildernd:** Die tatsÃ¤chlich gesendeten Dokumente sind im LLM-Manifest mit Hash gebunden (llm-evidence.js L246).
- **Reparatur:** Fehlende Regel â†’ IOException; Pflichtliste fÃ¼r fachlich relevante Dokumente.
- **Regressionstest:** Regel `file:doc/gibtsnicht.md` â†’ BuildStamp bricht mit Fehler ab.

### C-09: Stale-Lock-Race in publish-certificate
- **Einstufung:** MINOR, STATISCH BELEGT.
- **Fundstelle:** publish-certificate.js P31â€“40: `existsSync` â†’ Owner lesen â†’ `kill(pid,0)` â†’ ESRCH â†’ `unlinkSync` â†’ `openSync(...,"wx")`.
- **Ablauf:**
  1. Der vorherige Publisher ist abgestÃ¼rzt.
  2. A und B lesen beide den veralteten Owner.
  3. A lÃ¶scht den Lock und legt seinen eigenen an.
  4. B lÃ¶scht anschlieÃŸend **A's** Lock und legt seinen eigenen an.
  5. Beide verÃ¶ffentlichen gleichzeitig.
- **ZusÃ¤tzlich:** Wird die PID wiederverwendet, bleibt der Lock dauerhaft bestehen.
- **Auswirkung:** Eine Verflechtung der VerÃ¶ffentlichung ist mÃ¶glich. Die Downloadvalidierung bzw. der Fingerprint wÃ¼rden das voraussichtlich sichtbar machen (nicht geprÃ¼ft).
- **Reparatur:** Den Lock nur lÃ¶schen, wenn Inhalt und Inode bzw. mtime noch dem gelesenen Owner entsprechen; PID plus Startzeit speichern.
- **Regressionstest:** Zwei parallel gestartete Publisher auf einem veralteten Lock â†’ genau einer verÃ¶ffentlicht, der andere bricht mit â€žgesperrtâ€œ ab.

### C-10: Kein Absolut-Timeout; Bereinigung nur beim Login
- **Einstufung:** MINOR, STATISCH BELEGT.
- **Fundstellen:** Benutzerverwaltung B32 (Idle 60 min), B185, B156â€“165 (AufrÃ¤umen nur in `anmelden` B108). Abmelden rÃ¤umt korrekt auf (B223â€“226).
- **Auswirkung:** Ein aktiv gehaltenes oder gestohlenes Token bleibt unbegrenzt gÃ¼ltig.
- **Reparatur:** Absolutgrenze, z. B. 8â€“10 h, ab Anmeldung.
- **Regressionstest:** Mit einer Clock alle 30 min aktiv; nach 10 h liefert `zuToken` einen leeren Wert.
- **Historische ID:** CR-13 (TEILWEISE).

### C-11: Kontosperre per Fremdeingabe (Lockout-DoS)
- **Einstufung:** MINOR, STATISCH BELEGT.
- **Fundstellen:** B33â€“B146, B34 (30 s Sperre je **Kennung**, ohne Bezug auf die Quelle).
- **Ablauf:** FÃ¼nf falsche PasswÃ¶rter fÃ¼r â€žsb-01â€œ alle 30 s halten das Konto dauerhaft gesperrt.
- **Reparatur:** Drosselung je Kennung plus Quelle, exponentielles Backoff, Admin-Entsperrung.
- **Historische IDs:** CR-12 (TEILWEISE); GR-07 ist sonst BEHOBEN.

### C-12: SweetServer ohne Anmeldung; LLM-Ziel lokal umkonfigurierbar
- **Einstufung:** INFO/MINOR, STATISCH BELEGT.
- **Fundstellen:**
  - S59 (Loopback) und S625â€“631 (Host/Origin) schÃ¼tzen vor Browser- und DNS-Rebinding-Angriffen, nicht vor lokalen Prozessen.
  - POST `/api/llm/config` (S166â€“174) Ã¤ndert baseUrl bzw. Modell.
  - `/api/start` lÃ¶st AufrÃ¤umen aus.
  - Lese-Endpunkte haben keine MethodenprÃ¼fung (S138, S154ff.).
  - 404 gibt den Pfad zurÃ¼ck (S211).
  - Die Startanfrage koerziert Zahlen-Strings Ã¼ber `zahl()`; der Zweig `wunsch==null` ist tot (S236, da `readJsonBody` `Map.of()` liefert).
- **Auswirkung:** Ein lokaler Prozess bzw. Nutzer kann LÃ¤ufe starten oder abbrechen und den LLM-Verkehr umleiten.
- **Reparatur:** Lokales Zufallstoken (Datei mit Benutzer-ACL), baseUrl-Allowlist.
- **Historische ID:** WB-05.

### C-13: GLM-Umfang und Falltexte (Offenlegung)
- **Einstufung:** INFO, STATISCH BELEGT.
- Die GLM-Stichprobe umfasst nur FACH POS/NEG; LAST, STRESS und WEB werden nicht vom LLM geprÃ¼ft.
- Die Falltexte enthalten die Ergebniswerte.
- Die Grenzen sind korrekt offengelegt (generate.js L102, README L134, llm-pruefauftrag.txt L8: â€žausdrÃ¼cklich begrenzte Stichprobeâ€œ).
- Ein LLM-PASS ist **kein** unabhÃ¤ngiger Rechennachweis. UnabhÃ¤ngig ist erst LlmCalculationReference, die auch der Verifikator nutzt (CR-48).

---

## D) Zertifikatskette

| Glied | Status | Evidenz | LÃ¼cke |
|---|---|---|---|
| 1 Quellstand | TEILWEISE | BuildStamp `sources()`/`inventory()` 156â€“175, `sourceSha256` 122 | C-08 (fehlende Pfade, unvollstÃ¤ndige Liste) |
| 2 Build und geladene Artefakte (auch JAR aus ~/.m2) | GEPRÃœFT | `artifact()` 126â€“135: Klassen-Hash **und** Modulquellen-Hash gegen den eingebetteten Stempel `META-INF/<name>-build.properties`; `sourceArtifactsMatch` 121â€“123; Pflichtschicht BUILD (generate.js L18). Ein abweichendes ~/.m2-JAR ergibt `sourceMatch=false`. | Der Stempel ist selbstdeklariert, ohne Signatur bzw. Urheberschaft (ZT-01, INFO) |
| 3 JUnit | TEILWEISE | `expectedClasses` 143â€“150 (Klassen nach Namenskonvention); certificate-evidence.js L198 (â€žspÃ¤terer Skip beweist keinen Fixâ€œ) | Node-Tests fehlen (C-03); Testklassen auÃŸerhalb der Namenskonvention werden nicht erwartet |
| 4 Simulator (7 Pflichtkombinationen; Web-STRESS begrÃ¼ndet N/A) | GEPRÃœFT | Verifikator: keine bzw. mehrere Zeilen, NULL und SQL-Fehler ergeben false; BETRAG Ã¼ber compareTo. NegativfÃ¤lle: erwarteter Code **und** Grund (SzenarioAktion 44â€“63), technische Exception = Fehlschlag (Mitarbeiter 98), Fachzustandshash (Fachzustand 40â€“43). `laufErfolgreich` 1083â€“1099 | C-02 (TF29-Soll), C-04, C-07 |
| 5 Fallauswahl | TEILWEISE | 200 FÃ¤lle in 67 Batches (fremder Lauf), nur FACH POS/NEG | Grenzfallpriorisierung und Aufnahme von TF29 nicht bewiesen (E-04) |
| 6 Ãœbertragung (Dokumentbytes, Request) | GEPRÃœFT (P2 an Kopien) | PrÃ¼fauftrag und Falltexte im User-Prompt (41643 Zeichen); Dokumente mit Hash im Manifest (llm-evidence.js L246) | â€“ |
| 7 Antwortvalidierung und Retry | GEPRÃœFT | LlmAnswerValidator; Retry 205â€“325; `validateStored` 815â€“940 | C-06 |
| 8 Referenzrechnung | GEPRÃœFT | LlmCalculationReference (â€žINDEPENDENT_CALCULATION_2026â€œ); Java-ParitÃ¤t Ã¼ber JUnit | Node-ParitÃ¤t nicht in der Pipeline (C-03) |
| 9 Gesamturteil | GEPRÃœFT | PASS mit provisional = UNVERIFIED; explicitOffset als Pflicht fÃ¼r PASS (CR-45); Urteile BESTANDEN / NICHT BESTANDEN / UNVOLLSTÃ„NDIG | â€“ |
| 10 VerÃ¶ffentlichung und Export | GEPRÃœFT | Staging plus `wx`-Temp (P13); `ATOMIC_MOVE` mit nicht-atomarem Fallback (CertificateSuiteState 50â€“51, INFO); Downloadsperre S76 | C-09 |

### Frischer fremder Lauf (nur gelesen)

- **Suite:** `D:\â€¦\testsweet\logs\certificate-suite-7b1ef5e5-a3d8-47e1-991d-3c29f1f0c1a5\status.json`, Stand 13:06:40Z: `running=true`, Phase GLM_REVIEW, â€žFallgruppe 29/67â€œ, kein Urteil.
- **LLM:** `llm-review-e5a829c7-â€¦\status.json`, Stand 13:06:35Z:
  - RUNNING, 87/200 FÃ¤lle, 29/67 Batches.
  - Bisheriges caseVerdict PASS, **hasFindings=true, hasUnverifiedFindings=true**; noch kein result.json.
  - Formal ungÃ¼ltige Erstantworten mit Retry: b2, b8, b11, b18, b20; b20 war erst im 3. Versuch gÃ¼ltig. Das sind 5 von 29 Batches, also eine fragile Ausgabeformatierung. Ein vierter formaler Fehlschlag in einem Batch wÃ¼rde zu ERROR bzw. UNVOLLSTÃ„NDIG fÃ¼hren.
  - Prognose (kein Beleg): kein BESTANDEN, da unverifizierte bzw. provisionale FAILs vorliegen (u. a. TF29).

**SimulatorlÃ¤ufe** (alle 0 Fehler, Berichte vollstÃ¤ndig, Run-Verzeichnisse mit status.json konsistent):

| Kombination | Lauf | Umfang | Dauer | Kennzahlen |
|---|---|---|---|---|
| WEB POS | run-20261015-141715 | 100 | 228 s | 727 PNG-Dialogbelege |
| WEB NEG | run-20261015-142104 | 100 | 153 s | 404 PNG, global 72 |
| WEB LAST | run-20261015-142338 | 30 | 64 s | 2881/3692/4535 ms, 28,1/min |
| FACH POS | run-20261015-142443 | 500 | 8 s | â€“ |
| FACH NEG | run-20261015-142451 | 500 | 7 s | Kennzahl â€žerwartet 490â€œ; die Differenz zu 500 ist im Bericht nicht aufgeschlÃ¼sselt (vermutlich NegativfÃ¤lle ohne Fachfehlerschritt wie TF29; nicht verifiziert) |
| FACH LAST | run-20261015-142459 | 120 | 2 s | 31/38/87 ms, â€ž3600/minâ€œ (C-07) |
| FACH STRESS | run-20261015-142501 | 21 Nutzer, 42 AuftrÃ¤ge | 3 s | 8 StressprÃ¼fungen ok |
| WEB STRESS | â€“ | N/A | â€“ | begrÃ¼ndet |

**Bewertung:**
- Funktional sind die LÃ¤ufe schlÃ¼ssig.
- Ein **Lastnachweis wird nicht getragen**:
  - Laufzeiten von 2â€“64 s;
  - 30 Web-AuftrÃ¤ge;
  - keine Perzentile, keine Ressourcenmetriken, keine SÃ¤ttigung;
  - Stress mit 21 Nutzern Ã¼ber 3 s.

---

## E) Offene Hypothesen (nicht in der Fundliste)

- **E-01 (CR-16):** Inline-`style`-Attribute in index.html/app.js werden von `default-src 'self'` blockiert. Probe:
  1. Statik mit identischem CSP-Header Ã¼ber einen Mini-JDK-HttpServer ausliefern.
  2. Headless-Chrome mit eigenem Profil starten.
  3. Konsole auf â€žRefused to apply inline styleâ€œ prÃ¼fen und die Darstellung per Screenshot vergleichen.
- **E-02:** LÃ¶schen sich zwei Checkouts gegenseitig die Daten (C-04, dynamisch)? Probe:
  1. Zwei SweetServer auf Wegwerf-Schema, Ports â‰  8095.
  2. A startet FACH POS, B startet mit AufrÃ¤umen.
  3. Erwartet: A schlÃ¤gt **sichtbar** fehl, kein FERTIG.
- **E-03:** BESTANDEN auch ohne Suite-Verzeichnis. Probe: Kopie eines abgeschlossenen Zertifikatsbelegs in probe-C, Suite-Verzeichnis entfernen, `certificate-evidence.js`/`--verify` auf der Kopie ausfÃ¼hren. Erwartet: nicht BESTANDEN.
- **E-04:** Ist TF29 deterministisch in der GLM-Stichprobe? Probe: Auswahlfunktion mit Seed 20261014 isoliert gegen den NEG-Katalog ausfÃ¼hren und auf SWEET-N-0029 prÃ¼fen. Ist der Fall nicht enthalten, kÃ¶nnte das Zertifikat den Demoweg (C-02) als bestanden ausweisen; dann KRITISCH.
- **E-05:** Fehlerdialog-SpezifitÃ¤t im WebMitarbeiter. Die PrÃ¼fung erfolgt per Teilstring, z. B. â€žZahlungsmonatâ€œ. Probe: Unit-Test mit dem Dialogtext â€žZahlungsmonat: technischer Fehlerâ€œ; der Negativschritt muss fehlschlagen.
- **E-06:** Wird beim Ã„ndern der baseUrl der gespeicherte API-SchlÃ¼ssel an das neue Ziel gesendet? Probe: Isolierte LlmReviewService-Instanz mit lokalem Fake-Endpunkt; Authorization-Header prÃ¼fen.
- **E-07:** Sind Inhalte von `TxAuditLog.fehlerBeschreibung` und JUL bzw. JMX frei von Sozialdaten (CR-38)? Probe: Unit-Test mit einer Exception-Message, die eine IBAN bzw. einen Namen enthÃ¤lt, und Assertion auf die Redaktion.
- **E-08:** Die rechtliche Einordnung von TF29 bzw. C-02 liegt beim Fach-Reviewer.

---

## F) NachprÃ¼fung historischer Befunde

| ID | Status | Anmerkung |
|---|---|---|
| FB-20261015-04 (k4p9) | NOCH VORHANDEN | C-01, dokumentierte Grenze |
| FB-06 | BEHOBEN | ZahlungDao 100â€“113, BlÃ¶cke Ã  1000 |
| FB-14 | TEILWEISE | HTTP-Storno nur fÃ¼r Admin (L506); der Service selbst prÃ¼ft keine Rolle (INFO) |
| FB-16 / CR-15 | BEHOBEN | frame-ancestors Ã¼berall gesetzt |
| WB-05 | NOCH VORHANDEN | C-12, INFO |
| WB-06 | TEILWEISE | Token einmalig, 60 s, an Sitzung und BG gebunden; die URL-Spur bleibt |
| ZT-01 | NOCH VORHANDEN (INFO) | lokaler Hash ohne Urheberschaftsnachweis; keine Ãœberbehauptung gefunden |
| GR-07 | BEHOBEN | Rest: C-11 |
| GR-08 | BEHOBEN | â€“ |
| GR-09 | TEILWEISE | C-03 |
| GR-01..06, GR-10 | NICHT VERIFIZIERBAR | von k4p9 als BEHOBEN gefÃ¼hrt, von mir nicht einzeln nachgeprÃ¼ft |
| CR-06 | BEHOBEN | Timeouts 30/120/30 s |
| CR-11 | BEHOBEN | Rest: C-05 |
| CR-12 | TEILWEISE | C-11 |
| CR-13 | TEILWEISE | C-10 |
| CR-14 | BEHOBEN | 503 auch im Druckpfad |
| CR-16 | NICHT VERIFIZIERBAR | E-01 |
| CR-38 | NICHT VERIFIZIERBAR | nicht geprÃ¼ft; E-07 |
| CR-39, CR-40, CR-60 | INFO | Restthemen ohne Befundrelevanz |
| CR-45 | TEILWEISE | explicitOffset als Pflicht fÃ¼r PASS |
| CR-47 | TEILWEISE | `SELECT ? FROM DUAL` prÃ¼ft nur die Service-RÃ¼ckgabe; echte DB-Erwartungen (ID, Status, FREIGEGEBEN_VON, Betrag, Journal) ergÃ¤nzen |
| CR-48 | WEITGEHEND BEHOBEN | unabhÃ¤ngige Nachrechnung im Verifikator |
| CR-49 | NOCH VORHANDEN | C-04 |
| CR-50 | TEILWEISE | Marker ERROR plus `--verify` |
| CR-51 | NOCH VORHANDEN | externer Modus mit festen sb-01/sb-02 (Simulator ~560) |
| CR-56 | BEHOBEN | 51 testsweet-Testdateien |
| CR-57 | BEHOBEN | P1 dynamisch |
| CR-58 | NICHT VERIFIZIERBAR | nicht erneut geprÃ¼ft |
| CR-61 | BEHOBEN | statische Whitelist nur GET/HEAD |
| CR-70 | TEILWEISE (by design) | `istToterTreiber` begrenzt |
| CR-41..44, 46, 52..55, 59 | NICHT VERIFIZIERBAR | nicht einzeln nachgeprÃ¼ft |
| Verdacht â€žSimulator-Kassenlauf Ã¼ber fremde BEREIT-Zahlungenâ€œ | BEHOBEN | SzenarioBibliothek 917â€“960 auf das eigene Aktenzeichen begrenzt. Die Produktroute L476 ist absichtlich global (Admin) |

**Nebenwirkung frÃ¼herer Fixes:**
- Der Retry-Korrekturhinweis (Fix gegen formale Fehler) erzeugt den Vertragsbruch C-06.
- Die strengere TypprÃ¼fung (CR-11) lÃ¤sst die Default-0.00-LÃ¼cke offen (C-05).

---

## G) Widerlegte Verdachtsmomente

- **XSS:** in sweet/app.js nicht vorhanden; alle innerHTML-Senken nutzen `esc()`, unescaped sind nur Enum- und Zahlwerte. Im Bescheid-HTML ebenfalls nicht vorhanden, auch nicht im `<title>` (BG265â€“287). ZusÃ¤tzlich ist das Druck-CSP `script-src 'self'`.
- **Browser-AufrÃ¤umen:** Es werden keine fremden Chrome-Prozesse beendet (eigenes Profil plus Markerdatei).
- **Wiederholung von Schreibschritten im Webmodus:** BestÃ¤tigte Schritte werden nie wiederholt; bei unklarem Commit schlÃ¤gt der Auftrag fehl.
- **Technische Fehler gelten nicht als erfolgreiche NegativfÃ¤lle:** Mitarbeiter 98 und SzenarioAktion 56â€“63 (falscher Grund oder ausgebliebener Fehler â†’ Fehlschlag).
- **Teilverifikation, NULL, fehlende oder zusÃ¤tzliche Zeilen und SQL-Fehler gelten nicht als Erfolg** (Verifikator, GlobaleVerifikation).
- **Retry wiederholt fachliche FAILs nicht weg:** provisionalFailures bleiben erhalten.
- **JSON-Parser:** keine nachsichtige Verarbeitung (CR-57; P1).
- **Slowloris:** abgedeckt (CR-06).
- **Parallelabruf bzw. Replay des Drucktokens:** `synchronized` und einmaliger Verbrauch, BG-gebunden.
- **SachbearbeiteridentitÃ¤t aus dem Request-Body:** nein, nur aus dem Token.
- **Retry nach gelesenem Body:** Der Body ist gecacht; ein unklarer Ausgang ergibt 409 AUSGANG_UNBEKANNT.
- **Downloads alter Berichte wÃ¤hrend einer laufenden Suite:** gesperrt (409, S76).

---

## H) TestlÃ¼cken

1. Node-Tests fÃ¼r Werkzeuge und JS (inkl. ParitÃ¤tskorpus) sind keine Pipeline-Pflicht (C-03).
2. Kein Objektberechtigungstest â€žfremde BG â†’ 403â€œ (C-01).
3. Kein Test â€žZahlung ohne Bescheid im Produktivmodus abgelehntâ€œ (C-02).
4. Keine Tests fÃ¼r Geldwerte mit Skala > 2, fehlenden Feldern oder unbekannten SchlÃ¼sseln, jeweils mit erwartetem 400 (C-05).
5. Kein Test fÃ¼r DB-ExklusivitÃ¤t bzw. die Allowlist der Test-DB (C-04).
6. Kein Durchsatztest fÃ¼r Laufdauern unter bzw. um 1 s; keine Perzentil-Assertions (C-07).
7. Kein Test â€žfehlende Inventarregel â†’ Abbruchâ€œ (C-08).
8. Kein Test fÃ¼r konkurrierende Publisher auf einem veralteten Lock (C-09).
9. Kein Test zum Absolut-Timeout bzw. Lockout (C-10, C-11).
10. Kein Test zur SpezifitÃ¤t des Fehlerdialogs (E-05).
11. Kein Test â€žTF29 bzw. GrenzfÃ¤lle immer in der GLM-Stichprobeâ€œ (E-04).
12. Kein Test zur Redaktion von Sozialdaten in Logs (E-07).
13. Kein Browser-CSP-Test (E-01).

**Probenartefakte:** verbleiben unter `â€¦\lmg-r7w2\probe-C\` (`JsonProbe.java` und `llm\` mit 60 Belegkopien). Fremde Prozesse und Belege habe ich nicht verÃ¤ndert.