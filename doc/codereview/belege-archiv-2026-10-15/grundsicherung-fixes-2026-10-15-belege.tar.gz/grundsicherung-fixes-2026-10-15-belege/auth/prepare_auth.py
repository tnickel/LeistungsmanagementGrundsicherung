"""Bereitet Auth-Korrekturen vor; schreibt ausschließlich in diesen Belegordner."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
PROPOSED = OUT / "proposed"
manifest = {}


def change(relative, replacements):
    original = (ROOT / relative).read_bytes()
    text = original.decode("utf-8").replace("\r\n", "\n")
    for old, new in replacements:
        count = text.count(old)
        if count != 1:
            raise ValueError(f"{relative}: {count} statt 1 Treffer für {old[:90]!r}")
        text = text.replace(old, new, 1)
    target = PROPOSED / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    ending = "\r\n" if b"\r\n" in original else "\n"
    target.write_bytes(text.replace("\n", ending).encode("utf-8"))
    manifest[relative] = hashlib.sha256(original).hexdigest()


change("src/main/java/de/allgemein/lmg/web/Benutzerverwaltung.java", [
    ("private record DruckToken(Benutzer benutzer, Instant faelltAb)",
     "private record DruckToken(String sitzungsToken, long bgId, Instant faelltAb)"),
    ("    private final Map<String, Fehlversuche> fehlversuche = new ConcurrentHashMap<>();",
     "    /** Phantomkennungen sind gedeckelt; echte Konten haben davon unabhängige Zähler. */\n"
     "    private final Map<String, Fehlversuche> fehlversuche = new ConcurrentHashMap<>();\n"
     "    private final Map<String, Fehlversuche> kontoFehlversuche = new ConcurrentHashMap<>();"),
    ("    public String anmelden(String kennung, String passwort)",
     "    public synchronized String anmelden(String kennung, String passwort)"),
    ("        Fehlversuche bisher = fehlversuche.get(schluessel);",
     "        Konto konto = bereinigt.isEmpty() ? null : konten.get(bereinigt);\n"
     "        Map<String, Fehlversuche> zaehler = konto == null ? fehlversuche : kontoFehlversuche;\n"
     "        // Konfigurierte Konten nicht auf einen Phantomschlüssel verkürzen.\n"
     "        if (konto != null) schluessel = bereinigt;\n"
     "        Fehlversuche bisher = zaehler.get(schluessel);"),
    ("        Konto konto = bereinigt.isEmpty() ? null : konten.get(bereinigt);\n        if (konto == null",
     "        if (konto == null"),
    ("            registriereFehlversuch(schluessel);",
     "            registriereFehlversuch(schluessel, zaehler);"),
    ("        fehlversuche.remove(schluessel);", "        zaehler.remove(schluessel);"),
    ("    /** Zählt atomar einen Fehlversuch; aktive Sperren werden nie verdrängt. */\n"
     "    private void registriereFehlversuch(String schluessel) {\n"
     "        if (!fehlversuche.containsKey(schluessel) && fehlversuche.size() >= MAX_FEHLVERSUCH_EINTRAEGE)",
     "    /** Aufruf unter dem Anmeldemonitor: Deckel und Zähler gelten auch bei parallelen Requests. */\n"
     "    private void registriereFehlversuch(String schluessel, Map<String, Fehlversuche> zaehler) {\n"
     "        if (zaehler == fehlversuche && !fehlversuche.containsKey(schluessel)\n"
     "                && fehlversuche.size() >= MAX_FEHLVERSUCH_EINTRAEGE)"),
    ("                return; // nur noch aktive Sperren vorhanden: neue Kennung wird nicht verfolgt",
     "                return; // nur unbekannte Kennungen; echte Konten werden separat immer gezählt"),
    ("        fehlversuche.compute(schluessel, (k, alt) -> {", "        zaehler.compute(schluessel, (k, alt) -> {"),
    ("                || jetzt.isAfter(e.getValue().gesperrtBis()));",
     "                || !jetzt.isBefore(e.getValue().gesperrtBis()));"),
    ("                Duration.between(e.getValue().zuletztAktiv(), jetzt).compareTo(idleTimeout) > 0);",
     "                Duration.between(e.getValue().zuletztAktiv(), jetzt).compareTo(idleTimeout) >= 0);\n"
     "        druckTokens.entrySet().removeIf(e -> !sitzungen.containsKey(e.getValue().sitzungsToken())\n"
     "                || !jetzt.isBefore(e.getValue().faelltAb()));"),
    ("    public Optional<Benutzer> zuToken(String token)",
     "    public synchronized Optional<Benutzer> zuToken(String token)"),
    ("        if (Duration.between(sitzung.zuletztAktiv(), uhr.instant()).compareTo(idleTimeout) > 0) {\n"
     "            sitzungen.remove(token);",
     "        if (Duration.between(sitzung.zuletztAktiv(), uhr.instant()).compareTo(idleTimeout) >= 0) {\n"
     "            abmelden(token);"),
    ("    public String erzeugeDruckToken(Benutzer benutzer) {\n"
     "        Instant jetzt = uhr.instant();\n"
     "        druckTokens.entrySet().removeIf(e -> jetzt.isAfter(e.getValue().faelltAb()));\n"
     "        String token = UUID.randomUUID().toString();\n"
     "        druckTokens.put(token, new DruckToken(benutzer, jetzt.plus(DRUCK_TOKEN_GUELTIG)));\n"
     "        return token;\n"
     "    }\n\n"
     "    /** Verbraucht das Druck-Token (genau ein Abruf möglich); ungültig/abgelaufen → leer. */\n"
     "    public Optional<Benutzer> verbraucheDruckToken(String token) {\n"
     "        if (token == null || token.isBlank()) {\n"
     "            return Optional.empty();\n"
     "        }\n"
     "        DruckToken druck = druckTokens.remove(token);\n"
     "        if (druck == null || uhr.instant().isAfter(druck.faelltAb())) {\n"
     "            return Optional.empty();\n"
     "        }\n"
     "        return Optional.of(druck.benutzer());\n"
     "    }\n\n"
     "    public void abmelden(String token) {\n"
     "        if (token != null) {\n"
     "            sitzungen.remove(token);\n"
     "        }\n"
     "    }",
     "    public synchronized String erzeugeDruckToken(String sitzungsToken, long bgId) {\n"
     "        if (bgId <= 0) throw new IllegalArgumentException(\"bgId muss positiv sein\");\n"
     "        raeumeSitzungenAuf();\n"
     "        if (zuToken(sitzungsToken).isEmpty()) {\n"
     "            throw new FachlicheException(FachlicheException.BERECHTIGUNG,\n"
     "                    \"Drucktoken erfordert eine aktive Sitzung\");\n"
     "        }\n"
     "        String token = UUID.randomUUID().toString();\n"
     "        druckTokens.put(token, new DruckToken(sitzungsToken, bgId,\n"
     "                uhr.instant().plus(DRUCK_TOKEN_GUELTIG)));\n"
     "        return token;\n"
     "    }\n\n"
     "    /** Einmaliger Abruf nur für die Ziel-BG und eine weiterhin aktive Herkunftssitzung. */\n"
     "    public synchronized Optional<Benutzer> verbraucheDruckToken(String token, long bgId) {\n"
     "        if (token == null || token.isBlank()) return Optional.empty();\n"
     "        DruckToken druck = druckTokens.remove(token);\n"
     "        if (druck == null || druck.bgId() != bgId || !uhr.instant().isBefore(druck.faelltAb())) {\n"
     "            return Optional.empty();\n"
     "        }\n"
     "        return zuToken(druck.sitzungsToken());\n"
     "    }\n\n"
     "    public synchronized void abmelden(String token) {\n"
     "        if (token != null) {\n"
     "            sitzungen.remove(token);\n"
     "            druckTokens.entrySet().removeIf(e -> token.equals(e.getValue().sitzungsToken()));\n"
     "        }\n"
     "    }")
])

change("src/main/java/de/allgemein/lmg/web/LmgServer.java", [
    ("        Benutzer benutzer = benutzerAusHeaderOderQuery(exchange);",
     "        long bgId = Long.parseLong(pfad.split(\"/\")[3]);\n"
     "        Benutzer benutzer = benutzerAusHeaderOderQuery(exchange, bgId);"),
    ("        String[] teile = pfad.split(\"/\");\n        long bgId = Long.parseLong(teile[3]);\n        try {",
     "        try {"),
    ("    private Benutzer benutzerAusHeaderOderQuery(HttpExchange exchange)",
     "    private Benutzer benutzerAusHeaderOderQuery(HttpExchange exchange, long bgId)"),
    ("return benutzerverwaltung.verbraucheDruckToken(part.substring(\"token=\".length()))",
     "return benutzerverwaltung.verbraucheDruckToken(part.substring(\"token=\".length()), bgId)"),
    ("                || pfad.matches(\"/api/zahlungen/\\\\d+/storno\");\n    }",
     "                || istZahlungsAktion(pfad.split(\"/\"), \"storno\");\n    }\n\n"
     "    /** Dieselbe Routenstruktur für Berechtigungsprüfung und Handler, unabhängig von ID-Schreibweisen. */\n"
     "    private static boolean istZahlungsAktion(String[] teile, String aktion) {\n"
     "        return teile.length == 5 && teile[2].equals(\"zahlungen\") && teile[4].equals(aktion);\n"
     "    }"),
    ("            return Map.of(\"drucktoken\", benutzerverwaltung.erzeugeDruckToken(angemeldet));",
     "            Map<String, Object> body = leseKoerper(exchange);\n"
     "            return Map.of(\"drucktoken\", benutzerverwaltung.erzeugeDruckToken(\n"
     "                    tokenAus(exchange.getRequestHeaders().getFirst(\"Authorization\")),\n"
     "                    zahlWert(body.get(\"bgId\"), \"bgId\")));"),
    ("        if (teile.length == 5 && teile[2].equals(\"zahlungen\") && teile[4].equals(\"storno\")\n"
     "                && \"POST\".equals(methode)) {\n"
     "            Zahlung storniert",
     "        if (istZahlungsAktion(teile, \"storno\") && \"POST\".equals(methode)) {\n"
     "            // Sicherheitsgrenze direkt am erreichbaren Schreibhandler; keine Regex-Parität voraussetzen.\n"
     "            if (!angemeldet.istAdmin()) {\n"
     "                throw new FachlicheException(FachlicheException.BERECHTIGUNG,\n"
     "                        \"Diese Funktion erfordert die Admin-Rolle\");\n"
     "            }\n"
     "            Zahlung storniert")
])

change("src/main/resources/webapp/app.js", [
    ('    const antwort = await api("/api/drucktoken", { method: "POST" });',
     '    const antwort = await api("/api/drucktoken", {\n'
     '      method: "POST", body: JSON.stringify({ bgId: detail.bedarfsgemeinschaft.id }),\n'
     '    });')
])

change("src/test/java/de/allgemein/lmg/web/BenutzerverwaltungZeitTest.java", [
    ("import static org.junit.jupiter.api.Assertions.assertFalse;",
     "import static org.junit.jupiter.api.Assertions.assertEquals;\n"
     "import static org.junit.jupiter.api.Assertions.assertFalse;"),
    ('        String druck = verwaltung.erzeugeDruckToken(new Benutzer("sb-01", "sachbearbeiter"));\n'
     '        assertTrue(verwaltung.verbraucheDruckToken(druck).isPresent());\n'
     '        assertFalse(verwaltung.verbraucheDruckToken(druck).isPresent(), "One-time: second call empty");',
     '        String sitzung = verwaltung.anmelden("sb-01", "sb-01");\n'
     '        String druck = verwaltung.erzeugeDruckToken(sitzung, 7);\n'
     '        assertTrue(verwaltung.verbraucheDruckToken(druck, 7).isPresent());\n'
     '        assertFalse(verwaltung.verbraucheDruckToken(druck, 7).isPresent(), "Einmaliger Abruf");'),
    ('        String druck = verwaltung.erzeugeDruckToken(new Benutzer("sb-01", "sachbearbeiter"));\n'
     '        uhr.plus(Duration.ofSeconds(61));\n'
     '        assertFalse(verwaltung.verbraucheDruckToken(druck).isPresent(), "abgelaufen");',
     '        String sitzung = verwaltung.anmelden("sb-01", "sb-01");\n'
     '        String druck = verwaltung.erzeugeDruckToken(sitzung, 7);\n'
     '        uhr.plus(Duration.ofSeconds(60));\n'
     '        assertFalse(verwaltung.verbraucheDruckToken(druck, 7).isPresent(), "am Fristende abgelaufen");'),
    ('    @Test\n    void abmeldenBeendetDieSitzung()',
     '''    @Test
    void vollePhantomSperrmapVerhindertKeineNeueSperreFuerEinEchtesKonto() throws Exception {
        BeweglicheUhr uhr = new BeweglicheUhr();
        Benutzerverwaltung verwaltung = verwaltungMitUhr(uhr);
        for (int i = 0; i < 1024; i++) {
            String kennung = "phantom-" + i;
            for (int j = 0; j < 5; j++) {
                assertThrows(FachlicheException.class, () -> verwaltung.anmelden(kennung, "x"));
            }
        }
        for (int i = 0; i < 5; i++) {
            assertThrows(FachlicheException.class, () -> verwaltung.anmelden("sb-01", "falsch"));
        }
        FachlicheException gesperrt = assertThrows(FachlicheException.class,
                () -> verwaltung.anmelden("sb-01", "sb-01"));
        assertTrue(gesperrt.getMessage().contains("Zu viele fehlgeschlagene"));
        assertTrue(verwaltung.anmelden("admin-01", "admin") != null);
        assertTrue(assertThrows(FachlicheException.class,
                () -> verwaltung.anmelden("phantom-0", "x")).getMessage().contains("Zu viele"),
                "bestehende aktive Phantomsperren bleiben erhalten");
        var feld = Benutzerverwaltung.class.getDeclaredField("fehlversuche");
        feld.setAccessible(true);
        assertEquals(1024, ((java.util.Map<?, ?>) feld.get(verwaltung)).size(),
                "der Phantom-Speicher bleibt begrenzt");
        var kontofeld = Benutzerverwaltung.class.getDeclaredField("kontoFehlversuche");
        kontofeld.setAccessible(true);
        assertEquals(1, ((java.util.Map<?, ?>) kontofeld.get(verwaltung)).size(),
                "echte Zähler wachsen höchstens mit den konfigurierten Konten");
        uhr.plus(Duration.ofSeconds(30));
        assertTrue(verwaltung.anmelden("sb-01", "sb-01") != null, "Sperre endet regulär");
    }

    @Test
    void druckTokenIstAnZielBgGebundenUndFehlversuchVerbrauchtEs() {
        Benutzerverwaltung verwaltung = verwaltungMitUhr(new BeweglicheUhr());
        String sitzung = verwaltung.anmelden("sb-01", "sb-01");
        String druck = verwaltung.erzeugeDruckToken(sitzung, 7);
        assertFalse(verwaltung.verbraucheDruckToken(druck, 8).isPresent());
        assertFalse(verwaltung.verbraucheDruckToken(druck, 7).isPresent());
    }

    @Test
    void logoutWiderruftNurDruckTokenDerHerkunftssitzung() {
        Benutzerverwaltung verwaltung = verwaltungMitUhr(new BeweglicheUhr());
        String ersteSitzung = verwaltung.anmelden("sb-01", "sb-01");
        String zweiteSitzung = verwaltung.anmelden("sb-01", "sb-01");
        String ersterDruck = verwaltung.erzeugeDruckToken(ersteSitzung, 7);
        String zweiterDruck = verwaltung.erzeugeDruckToken(zweiteSitzung, 7);
        verwaltung.abmelden(ersteSitzung);
        verwaltung.anmelden("sb-01", "sb-01");
        assertFalse(verwaltung.verbraucheDruckToken(ersterDruck, 7).isPresent(),
                "erneute Anmeldung darf ein widerrufenes Token nicht reaktivieren");
        assertTrue(verwaltung.verbraucheDruckToken(zweiterDruck, 7).isPresent());
    }

    @Test
    void druckTokenPrueftIdleAuchVorAblaufSeinerEigenenFrist() {
        BeweglicheUhr uhr = new BeweglicheUhr();
        Benutzerverwaltung verwaltung = new Benutzerverwaltung("sb-01:sb-01:sachbearbeiter",
                Duration.ofSeconds(30));
        verwaltung.setzeUhrFuerTests(uhr);
        String sitzung = verwaltung.anmelden("sb-01", "sb-01");
        String druck = verwaltung.erzeugeDruckToken(sitzung, 7);
        uhr.plus(Duration.ofSeconds(30));
        assertFalse(verwaltung.verbraucheDruckToken(druck, 7).isPresent(),
                "Sitzung ist nach 30s idle, obwohl die Drucktokenfrist 60s beträgt");
        assertFalse(verwaltung.zuToken(sitzung).isPresent());
    }

    @Test
    void druckTokenErfordertAktiveSitzungUndPositiveBgId() {
        Benutzerverwaltung verwaltung = verwaltungMitUhr(new BeweglicheUhr());
        assertThrows(FachlicheException.class, () -> verwaltung.erzeugeDruckToken("unbekannt", 7));
        String sitzung = verwaltung.anmelden("sb-01", "sb-01");
        assertThrows(IllegalArgumentException.class, () -> verwaltung.erzeugeDruckToken(sitzung, 0));
        verwaltung.abmelden(sitzung);
        assertThrows(FachlicheException.class, () -> verwaltung.erzeugeDruckToken(sitzung, 7));
    }

    @Test
    void abmeldenBeendetDieSitzung()''')
])

change("src/test/java/de/allgemein/lmg/web/LmgServerHttpTest.java", [
    ('        @Override\n        public Zahlung storniereZahlung(long zahlungId, String sachbearbeiterId) {\n'
     '            throw new UnsupportedOperationException();\n'
     '        }',
     '''        final java.util.concurrent.atomic.AtomicInteger stornoAufrufe = new java.util.concurrent.atomic.AtomicInteger();
        final java.util.concurrent.atomic.AtomicInteger druckAufrufe = new java.util.concurrent.atomic.AtomicInteger();

        @Override
        public Zahlung storniereZahlung(long zahlungId, String sachbearbeiterId) {
            stornoAufrufe.incrementAndGet();
            return new Zahlung(zahlungId, 1, null, "HTTP-TEST-1", "2026-10",
                    java.math.BigDecimal.TEN, "STORNIERT", Instant.now(), sachbearbeiterId, "sb-y",
                    "DE89370400440532013000", "MARKDEF1100", "Max Mustermann");
        }'''),
    ('        public String generiereBescheidHtml(long bgId, String sachbearbeiterId) {\n'
     '            return "<html><body><h1>Bescheid-Test</h1></body></html>";',
     '        public String generiereBescheidHtml(long bgId, String sachbearbeiterId) {\n'
     '            druckAufrufe.incrementAndGet();\n'
     '            return "<html><body><h1>Bescheid-Test</h1></body></html>";'),
    ('    private ServiceFake serviceFake;',
     '    private ServiceFake serviceFake;\n'
     '    private Benutzerverwaltung benutzerverwaltung;\n'
     '    private static final Instant AUTH_ZEIT = Instant.parse("2026-10-15T10:00:00Z");'),
    ('        Benutzerverwaltung benutzerverwaltung = new Benutzerverwaltung(\n'
     '                "admin-01:admin:admin;sb-01:sb-01:sachbearbeiter", Duration.ofMinutes(60));',
     '        benutzerverwaltung = new Benutzerverwaltung(\n'
     '                "admin-01:admin:admin;sb-01:sb-01:sachbearbeiter", Duration.ofSeconds(30));\n'
     '        benutzerverwaltung.setzeUhrFuerTests(java.time.Clock.fixed(AUTH_ZEIT, java.time.ZoneOffset.UTC));'),
    ('HttpResponse<String> tokenAntwort = sende("POST", "/api/drucktoken", "{}", token);',
     'HttpResponse<String> tokenAntwort = sende("POST", "/api/drucktoken", "{\\"bgId\\":1}", token);'),
    ('    @Test\n    void ueberlangeIdInDruckPfadGibtKein500()',
     '''    @Test
    void alternativeStornoIdsErreichenAlsSachbearbeiterNiemalsDenService() {
        String token = meldeAn("sb-01", "sb-01");
        for (String id : List.of("7", "+7", "%2B7", "%D9%A7", "0007", "-7")) {
            for (String ende : List.of("", "/", "//")) {
                assertEquals(403, sende("POST", "/api/zahlungen/" + id + "/storno" + ende,
                        "{}", token).statusCode(), id + ende);
            }
        }
        assertEquals(0, serviceFake.stornoAufrufe.get(), "keine unzulässige Fachoperation");
        String admin = meldeAn("admin-01", "admin");
        assertEquals(200, sende("POST", "/api/zahlungen/7/storno", "{}", admin).statusCode());
        assertEquals(1, serviceFake.stornoAufrufe.get(), "Admin-Storno funktioniert weiterhin");
    }

    @Test
    void ueberlangeIdInDruckPfadGibtKein500()'''),
    ('    @Test\n    void abmeldungBeendetSitzung()',
     '''    private String druckToken(String sitzung, long bgId) {
        HttpResponse<String> antwort = sende("POST", "/api/drucktoken",
                "{\\"bgId\\":" + bgId + "}", sitzung);
        assertEquals(200, antwort.statusCode());
        return String.valueOf(((Map<?, ?>) Json.parse(antwort.body())).get("drucktoken"));
    }

    @Test
    void druckTokenNachLogoutOderIdleLiefertKeineBescheiddaten() {
        String sitzung = meldeAn("sb-01", "sb-01");
        String druck = druckToken(sitzung, 1);
        assertEquals(200, sende("POST", "/api/abmeldung", "{}", sitzung).statusCode());
        assertEquals(401, sende("GET", "/api/bedarfsgemeinschaften/1/bescheid/druck?token=" + druck,
                null, null).statusCode());
        sitzung = meldeAn("sb-01", "sb-01");
        druck = druckToken(sitzung, 1);
        benutzerverwaltung.setzeUhrFuerTests(java.time.Clock.fixed(AUTH_ZEIT.plusSeconds(30),
                java.time.ZoneOffset.UTC));
        assertEquals(401, sende("GET", "/api/bedarfsgemeinschaften/1/bescheid/druck?token=" + druck,
                null, null).statusCode());
        assertEquals(0, serviceFake.druckAufrufe.get());
    }

    @Test
    void druckTokenIstAnDieAngeforderteBgGebunden() {
        String sitzung = meldeAn("sb-01", "sb-01");
        String druck = druckToken(sitzung, 1);
        assertEquals(401, sende("GET", "/api/bedarfsgemeinschaften/2/bescheid/druck?token=" + druck,
                null, null).statusCode());
        assertEquals(0, serviceFake.druckAufrufe.get());
        assertEquals(401, sende("GET", "/api/bedarfsgemeinschaften/1/bescheid/druck?token=" + druck,
                null, null).statusCode(), "falsches Ziel verbraucht das Token ebenfalls");
    }

    @Test
    void druckTokenBodyMussEinePositiveGanzzahlBgIdEnthalten() {
        String sitzung = meldeAn("sb-01", "sb-01");
        for (String body : List.of("", "{}", "{\\"bgId\\":0}", "{\\"bgId\\":-1}",
                "{\\"bgId\\":1.5}", "{\\"bgId\\":\\"1\\"}")) {
            assertEquals(400, sende("POST", "/api/drucktoken", body, sitzung).statusCode(), body);
        }
    }

    @Test
    void druckHeaderVerwendetAktiveSitzungUndQueryNurEinmalToken() {
        String sitzung = meldeAn("sb-01", "sb-01");
        String pfad = "/api/bedarfsgemeinschaften/1/bescheid/druck";
        assertEquals(200, sende("GET", pfad, null, sitzung).statusCode());
        assertEquals(401, sende("GET", pfad + "?token=" + sitzung, null, null).statusCode());
        String druck = druckToken(sitzung, 1);
        assertEquals(401, sende("GET", pfad + "?token=" + druck, null, "ungueltig").statusCode(),
                "ungültiger Header wird nicht durch ein Querytoken ersetzt");
        assertEquals(200, sende("GET", pfad + "?token=" + druck, null, null).statusCode());
        assertEquals(2, serviceFake.druckAufrufe.get());
    }

    @Test
    void abmeldungBeendetSitzung()''')
])

(OUT / "original-sha256.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
diff = []
for relative in manifest:
    before = (ROOT / relative).read_text(encoding="utf-8").splitlines(keepends=True)
    after = (PROPOSED / relative).read_text(encoding="utf-8").splitlines(keepends=True)
    diff.extend(difflib.unified_diff(before, after, fromfile="a/" + relative, tofile="b/" + relative))
(OUT / "auth-product.patch").write_text("".join(diff), encoding="utf-8")
print(f"Vorbereitet: {len(manifest)} Produktdateien ausschließlich unter {PROPOSED}")
