"""Nur nach expliziter Quellenfreigabe ausführen; prüft Originalhashes vor dem Kopieren."""
from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = Path(__file__).resolve().parents[4]
manifest = json.loads((OUT / "original-sha256.json").read_text(encoding="utf-8"))
for relative, expected in manifest.items():
    if hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() != expected:
        raise RuntimeError(f"Quelle seit Vorbereitung verändert: {relative}")
result = {}
for relative in manifest:
    contents = (OUT / "proposed" / relative).read_bytes()
    (ROOT / relative).write_bytes(contents)
    result[relative] = hashlib.sha256(contents).hexdigest()
(OUT / "applied-sha256.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(f"{len(result)} freigegebene Dateien übernommen; kein Build und kein Testlauf ausgeführt")
