from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent / 'prepared'
FILES = {}

def edit(name, old, new):
    if name not in FILES:
        FILES[name] = (ROOT / name).read_text(encoding='utf-8')
    if old not in FILES[name]:
        raise RuntimeError(f'Nicht gefunden in {name}: {old[:90]!r}')
    FILES[name] = FILES[name].replace(old, new)

calc = 'src/main/java/de/allgemein/lmg/calc/Leistungsberechnung.java'
edit(calc, ' *                                    sonst 12 % je minderjährigem Kind; Deckel 60 % der RBS 1', ' *                                    Vergleich mit 12 % je minderjährigem Kind: höherer Betrag,\n *                                    Deckel 60 % der RBS 1 (kein abweichender Einzelfallbedarf)')
edit(calc, ' *                                    gekennzeichnet (Übernahme unter Vorbehalt). Optionaler\n *                                    örtlicher Heizkosten-Abzug nur bei zentralem Warmwasser\n *                                    (Default 0 = aus)', ' *                                    gekennzeichnet (Übernahme unter Vorbehalt). Zentrale\n *                                    Warmwasserkosten gehören zu den Heizkosten (Abs. 5),\n *                                    ohne zusätzlichen Warmwasserabzug')
edit(calc, '/** Mehrbedarf Alleinerziehende (§ 30 Abs. 3 SGB XII): 12 % je weiterem Kind unter 16. */', '/** Vergleichsvariante Alleinerziehende (§ 30 Abs. 3 SGB XII): 12 % je minderjährigem Kind. */')
edit(calc, 'die KdU-Parameter (Warmwasser-Abzug, Angemessenheitsgrenze) sind deaktiviert.', 'die KdU-Angemessenheitsgrenze ist deaktiviert.')
edit(calc, '''        // Optionaler örtlicher Abzug nur bei zentraler Warmwasserbereitung: nur dort stecken
        // Warmwasserkosten in den Heizkosten (§ 35 Abs. 5). Bei dezentraler Erzeugung gilt
        // stattdessen der Mehrbedarf nach § 30 Abs. 7 — ein Abzug wäre eine Doppelkürzung.
        BigDecimal warmwasserAbzugKdu = !fall.warmwasser()
                ? fall.kduHeizung().multiply(kduParameter.warmwasserAbzugHeizungProzent())
                        .setScale(SCALE, RoundingMode.HALF_UP)
                : BigDecimal.ZERO.setScale(SCALE);
        BigDecimal kduOhneWarmwasser = kduRoh.subtract(warmwasserAbzugKdu).max(BigDecimal.ZERO)
                .setScale(SCALE, RoundingMode.HALF_UP);''', '''        // § 35 Abs. 5 SGB XII schließt zentrale Warmwasserkosten in den Heizbedarf ein.
        // Der frühere Abzugsparameter bleibt einlesbar, mindert aber keinen Bedarf mehr.
        BigDecimal warmwasserAbzugKdu = BigDecimal.ZERO.setScale(SCALE);
        BigDecimal kduVorGrenze = kduRoh.max(BigDecimal.ZERO).setScale(SCALE, RoundingMode.HALF_UP);''')
edit(calc, 'kduOhneWarmwasser', 'kduVorGrenze')
edit(calc, '''     * Regelbedarfsstufe 1: bei Kind unter 7 oder zwei/drei Kindern unter 16 einmal 36 %
     * (Nr. 1), sonst 12 % je minderjährigem Kind (Nr. 2); gedeckelt auf 60 % der RBS 1.''', '''     * Regelbedarfsstufe 1: 36 % bei Kind unter 7 oder zwei/drei Kindern unter 16 (Nr. 1)
     * werden mit 12 % je minderjährigem Kind (Nr. 2) verglichen; der höhere Betrag gilt,
     * gedeckelt auf 60 %. Auslegung: Wissenschaftliche Dienste, WD 6-046/24, S. 8–11.
     * Abweichender Einzelfallbedarf und die tatsächliche alleinige Erziehung sind hier
     * nicht eigenständig modelliert; Kinderzahlen bilden die erfasste Standardkonstellation ab.''')
edit(calc, '''        BigDecimal anteil = nr1
                ? MEHRBEDARF_ALLEINERZIEHEND_36
                : MEHRBEDARF_ALLEINERZIEHEND_JE_KIND.multiply(BigDecimal.valueOf(minderjaehrig));''', '''        BigDecimal anteil = MEHRBEDARF_ALLEINERZIEHEND_JE_KIND.multiply(BigDecimal.valueOf(minderjaehrig));
        if (nr1) anteil = anteil.max(MEHRBEDARF_ALLEINERZIEHEND_36);''')
edit(calc, '/** Örtliche Parameter der KdU-Prüfung (§ 42a i.V.m. § 35 SGB XII); Default: deaktiviert. */', '''/**
     * Örtliche KdU-Grenze (§ 42a i.V.m. § 35 SGB XII); Default: deaktiviert.
     * {@code warmwasserAbzugHeizungProzent} wird aus Kompatibilitätsgründen weiter
     * angenommen und validiert, hat aber keine Rechenwirkung (§ 35 Abs. 5 SGB XII).
     */''')
edit(calc, '/** Prüfung deaktiviert: kein Warmwasser-Abzug, keine Angemessenheitsgrenze. */', '/** Keine Angemessenheitsgrenze; der Altparameter Warmwasserabzug ist wirkungslos. */')

java = 'testsweet/src/main/java/de/allgemein/testsweet/LlmCalculationReference.java'
edit(java, '''            BigDecimal single = minor == 0 ? ZERO : cents(d("563").multiply(u7 > 0 || u16 >= 2 && u16 <= 3 ? d(".36") : d(".12").multiply(d(Integer.toString(minor))))).min(d("337.80"));''', '''            // Vergleich der beiden Alternativen; die 36-Prozent-Konstellation ist keine Obergrenze.
            BigDecimal childRate = d(".12").multiply(d(Integer.toString(minor)));
            if (u7 > 0 || Math.max(u7, u16) >= 2 && Math.max(u7, u16) <= 3) childRate = childRate.max(d(".36"));
            BigDecimal single = minor == 0 ? ZERO : cents(d("563").multiply(childRate)).min(d("337.80"));''')
edit(java, '''            BigDecimal kduDeduction = decentralized ? ZERO : cents(d(required(in, "kdu_heizung")).multiply(deductionRate));
            BigDecimal kdu = sum(in, "kdu_miete", "kdu_betrieb", "kdu_heizung").subtract(kduDeduction).max(ZERO);''', '''            // Altparameter wird validiert, aber zentrale Warmwasserkosten bleiben Heizbedarf.
            BigDecimal kduDeduction = ZERO;
            BigDecimal kdu = sum(in, "kdu_miete", "kdu_betrieb", "kdu_heizung").max(ZERO);''')

node = 'doc/testzertifikat-werkzeug/llm-reference.js'
edit(node, 'const single=minor === 0 ? 0n : min(percentage(56300n,BigInt(u7>0 || u16>=2 && u16<=3 ? 36 : 12*minor)),33780n);', '''const preferredRate=Math.max(12*minor,u7>0 || Math.max(u7,u16)>=2 && Math.max(u7,u16)<=3 ? 36 : 0);
    const single=minor === 0 ? 0n : min(percentage(56300n,BigInt(preferredRate)),33780n);''')
edit(node, 'const kduDeduction=decentralized?0n:percentage(money("kdu_heizung"),rate,rateDenominator),rawKdu=max(sum("kdu_miete","kdu_betrieb","kdu_heizung")-kduDeduction,0n);', '''// Altparameter bleibt lesbar; zentrale Warmwasserkosten sind Heizbedarf (§ 35 Abs. 5).
    const kduDeduction=0n,rawKdu=max(sum("kdu_miete","kdu_betrieb","kdu_heizung"),0n);''')

py = 'doc/testzertifikat-werkzeug/nachrechnen_100.py'
edit(py, '        anteil = D("0.36") if (p["u7"] >= 1 or 2 <= p["u16"] <= 3) else D("0.12") * minderj', '''        anteil = D("0.12") * minderj
        if p["u7"] >= 1 or 2 <= max(p["u7"], p["u16"]) <= 3:
            anteil = max(anteil, D("0.36"))  # günstigere Alternative, WD 6-046/24, S. 8–11''')
edit(py, '''    abzug = R2(p["heizung"] * abzug_anteil) if not p["ww"] else D("0.00")
    kdu = max(D("0.00"), p["kdu"] - abzug)''', '''    abzug = D("0.00")  # Altparameter ohne Rechenwirkung; § 35 Abs. 5 SGB XII
    kdu = max(D("0.00"), p["kdu"])''')

scenario = 'testsweet/src/main/java/de/allgemein/testsweet/SzenarioBibliothek.java'
edit(scenario, 'nr == 17 ? new Leistungsberechnung.KduParameter(new BigDecimal("0.10"), BigDecimal.ZERO)', 'nr == 17 ? new Leistungsberechnung.KduParameter(new BigDecimal("0.20"), BigDecimal.ZERO)')
edit(scenario, '''        persons.add(grenzPerson(rbs, nr == 16, nr == 11 || nr == 16, children, nr == 16,
                nr == 17 || nr == 18 ? "350" : "300", nr == 17 || nr == 18 ? "50" : "0",
                nr == 17 || nr == 18 ? "100" : "0", nr == 11 ? "2026-10" : null));''', '''        int childrenU7 = nr == 13 || nr == 15 ? 1 : 0;
        int childrenU16 = nr == 13 ? 2 : nr == 14 || nr == 15 ? 3 : 0;
        persons.add(new SozialFall(0, 0, rbs, nr == 16, nr == 11 || nr == 16,
                childrenU7, childrenU16, children, nr == 16,
                new BigDecimal(nr == 17 || nr == 18 ? "350" : "300"),
                new BigDecimal(nr == 17 || nr == 18 ? "50" : "0"),
                new BigDecimal(nr == 17 || nr == 18 ? "100" : "0"),
                BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO,
                BigDecimal.ZERO, BigDecimal.ZERO, nr == 11 ? "2026-10" : null, 0));''')
edit(scenario, '        for (int i = 0; i < children; i++) persons.add(grenzPerson(4, false, false, 0, false, "0", "0", "0", null));', '''        // Passende Beispielalter: U7-Kinder Stufe 6, übrige U16-Kinder Stufe 5, 16/17 Jahre Stufe 4.
        for (int i = 0; i < children; i++) persons.add(grenzPerson(i < childrenU7 ? 6 : i < childrenU16 ? 5 : 4,
                false, false, 0, false, "0", "0", "0", null));''')
edit(scenario, '''            expectations.add(Erwartung.betrag("Zahlbetrag " + month, "SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE BG_ID = ? AND ZAHLUNGSMONAT = ?",
                    ctx -> List.of(ctx.get("bgId"), month), result.zahlbetrag().toPlainString()));''', '''            // Vorab handgerechnete Beträge sichern die reparierten Grenzfälle unabhängig vom Produktrechner.
            String paymentExpected = switch (nr) {
                case 13 -> "2822.24"; // 563 + 270,24 + 300 + 357 + 390 + 2 × 471
                case 14 -> "3312.80"; // 563 + 337,80 + 300 + 3 × 390 + 2 × 471
                case 15 -> "3750.80"; // 563 + 337,80 + 300 + 357 + 2 × 390 + 3 × 471
                case 17 -> "1063.00"; // 563 + 350 + 50 + 100; Altparameter 20 % ohne Abzug
                default -> result.zahlbetrag().toPlainString();
            };
            expectations.add(Erwartung.betrag("Zahlbetrag " + month, "SELECT AUSZAHLUNGSBETRAG FROM ZAHLUNG WHERE BG_ID = ? AND ZAHLUNGSMONAT = ?",
                    ctx -> List.of(ctx.get("bgId"), month), paymentExpected));''')

catalog = 'testsweet/src/main/java/de/allgemein/testsweet/TestfallKatalog.java'
edit(catalog, 'Feste vier minderjährige Kinder ohne U7-/U16-Merkmal: 48 % der RBS 1; vollständiger Haushalt und Zahlbetrag.', 'Vier minderjährige Kinder, davon ein U7- und zwei U16-Kinder: Vergleich 36 % gegen 48 % der RBS 1 ergibt 270,24 EUR. Altersgruppen Stufe 6/5/4/4; handgerechnete BG-Auszahlung 2.822,24 EUR per SQL.')
edit(catalog, 'Feste fünf minderjährige Kinder: 60 % der RBS 1; vollständiger Haushalt und Zahlbetrag.', 'Fünf minderjährige Kinder, davon drei U16 und kein U7: 60 % schlagen die ebenfalls erfüllte 36-Prozent-Alternative. Stufen 5/5/5/4/4; handgerechnete BG-Auszahlung 3.312,80 EUR per SQL.')
edit(catalog, 'Feste sechs minderjährige Kinder: 72 % roh, auf 60 % der RBS 1 gekappt; vollständiger Haushalt und Zahlbetrag.', 'Sechs minderjährige Kinder, davon ein U7- und drei U16-Kinder: 72 % roh, günstiger als 36 %, auf 60 % gekappt. Stufen 6/5/5/4/4/4; handgerechnete BG-Auszahlung 3.750,80 EUR per SQL.')
edit(catalog, '"Örtlicher zentraler Warmwasserabzug", "Auftrag 17", "Eigene unveränderliche Servicekonfiguration: 10 % der Heizkosten bei zentralem Warmwasser. Parameter und Abzug stehen im Rechenblock; keine globale Konfigurationsmutation."', '"Zentrale Warmwasserkosten vollständig anerkennen", "Auftrag 17", "Altparameter 20 % bleibt einlesbar und wirkungslos. Angemessene Wohnkosten 350 + 50 + 100 EUR sind vollständig Heiz-/Unterkunftsbedarf (§ 35 Abs. 5); kein dezentraler Mehrbedarf. Handgerechnete Auszahlung 1.063 EUR per SQL; eigene unveränderliche Servicekonfiguration."')

md = 'testsweet/src/main/java/de/allgemein/testsweet/MdBericht.java'
edit(md, '''        md.append("mehrbedarf_alleinerziehend = 0.36 * rbs1 bei kind_u7>=1 oder 2<=kinder_u16<=3, "
                + "sonst 0.12 * rbs1 je minderjaehrigem kind; deckel 0.60 * rbs1 = 337.80  (§ 30 Abs. 3)\\n");''', '''        md.append("mehrbedarf_alleinerziehend = guenstigere Alternative aus 0.36 * rbs1 (bei kind_u7>=1 oder 2<=kinder_u16<=3) "
                + "und 0.12 * rbs1 je minderjaehrigem kind; deckel 0.60 * rbs1 = 337.80 (§ 30 Abs. 3; WD 6-046/24, S. 8–11). Abweichender Einzelfallbedarf nicht modelliert.\\n");''')
edit(md, 'kdu = kaltmiete + betriebskosten + heizung - zentraler warmwasserabzug; gekappt auf verbleibende BG-Grenze, sofern > 0. Parameter stehen je Block.', 'kdu = kaltmiete + betriebskosten + heizung einschließlich zentraler Warmwasserkosten (§ 35 Abs. 5); gekappt auf verbleibende BG-Grenze, sofern > 0. Altparameter kdu_warmwasser_abzug_anteil bleibt dokumentiert, hat aber keine Rechenwirkung; kdu_warmwasser_abzug = 0.')

pdf = 'testsweet/src/main/java/de/allgemein/testsweet/Testdokumentation.java'
edit(pdf, '• Alleinerziehende: 36 % der Stufe 1 bei 1 Kind < 7 oder 2–3 Kindern < 16, sonst 12 % je minderjährigem Kind; Obergrenze 60 % der Stufe 1 = 337,80 EUR (Abs. 3)', '• Alleinerziehende: Vergleich von 36 % der Stufe 1 (bei Kind < 7 oder 2–3 Kindern < 16) mit 12 % je minderjährigem Kind: höherer Betrag, höchstens 60 % = 337,80 EUR (Abs. 3; kein abweichender Einzelfallbedarf)')
edit(pdf, '''                    + " - örtlicher zentraler Warmwasserabzug " + euro(f.kduWarmwasserAbzug())
                    + " (Anteil " + block.kduParameter().warmwasserAbzugHeizungProzent().toPlainString()
                    + "; BG-Grenze "''', '''                    + " (zentrale Warmwasserkosten eingeschlossen; Alt-Abzugsparameter "
                    + block.kduParameter().warmwasserAbzugHeizungProzent().toPlainString() + " ohne Rechenwirkung"
                    + "; BG-Grenze "''')
edit(pdf, '''        if (fall.anzKinderUnter7() >= 1) {
            return "36 % der Stufe 1 (Kind unter 7 im Haushalt), also 0,36 × 563,00";
        }
        if (kinderU16 >= 2 && kinderU16 <= 3) {
            return "36 % der Stufe 1 (2–3 Kinder unter 16), also 0,36 × 563,00";
        }
        return "12 % der Stufe 1 je minderjährigem Kind (" + fall.anzKinderMinderjaehrig()
                + " × 0,12 × 563,00)";''', '''        int minor = Math.max(fall.anzKinderMinderjaehrig(), kinderU16);
        boolean nr1 = fall.anzKinderUnter7() >= 1 || kinderU16 >= 2 && kinderU16 <= 3;
        if (nr1 && minor <= 3) {
            return "36 % der Stufe 1 sind mindestens so hoch wie " + minor + " × 12 % (Altersvoraussetzung erfüllt)";
        }
        return "12 % der Stufe 1 je minderjährigem Kind (" + minor
                + " × 0,12 × 563,00), höchstens 60 %" + (nr1 ? "; günstiger als 36 %" : "");''')

law = 'doc/testzertifikat-werkzeug/gesetzesgrundlagen-2026.md'
edit(law, 'Rechengrundlage für LLM-Nachrechnungen der testdokumentation.md.', '''Rechengrundlage für LLM-Nachrechnungen der testdokumentation.md.

Nachprüfung **2026-10-15**: [§ 30 Abs. 3 SGB XII](https://www.gesetze-im-internet.de/sgb_12/__30.html),
[§ 35 Abs. 5 SGB XII](https://www.gesetze-im-internet.de/sgb_12/__35.html) und
[Wissenschaftliche Dienste WD 6-046/24, S. 8–11](https://www.bundestag.de/resource/blob/1019234/WD-6-046-24-pdf.pdf).
Die Ausarbeitung erläutert den Vergleich der günstigeren Alternative und überträgt ihn
auf § 30 Abs. 3; sie ist eine Auslegungshilfe, keine bindende Einzelfallentscheidung.''')
edit(law, '| 3 | 451,00 EUR | erwachsene Person ohne eigene Wohnung im Haushalt |', '| 3 | 451,00 EUR | erwachsene Person mit Lebensunterhalt in stationärer Einrichtung (§ 27b) |')
edit(law, '36 % der **Stufe 1** bei mind. einem Kind unter 7 J. oder 2–3 Kindern unter 16 J.; sonst 12 % je minderjährigem Kind', 'Günstigere Alternative: 36 % der **Stufe 1** bei mind. einem Kind unter 7 J. oder 2–3 Kindern unter 16 J., verglichen mit 12 % je minderjährigem Kind')
edit(law, '''- Bei zentraler Warmwasserbereitung kann örtlich ein Warmwasseranteil von den Heizkosten
  abgezogen werden (parametrisierbar, Standard: aus); bei dezentraler Erzeugung gibt es
  stattdessen den §-30-Abs.-7-Zuschlag — niemals beides.''', '''- Zentrale Warmwasserkosten gehören zu den Heizkosten (§ 35 Abs. 5). Kein zusätzlicher
  Abzug; der frühere Abzugsparameter bleibt zur Kompatibilität einlesbar, wirkt aber nicht.
  Bei dezentraler Erzeugung wird stattdessen der §-30-Abs.-7-Mehrbedarf erfasst.''')
edit(law, '## Wohnkosten — Kosten der Unterkunft', '''Die Standardrechnung setzt alleinige Pflege und Erziehung sowie keinen abweichenden
Einzelfallbedarf voraus. Kinderzahlen allein beweisen diese Voraussetzungen nicht;
die Öffnungsklausel und wechselnde Betreuung sind nicht eigenständig modelliert.
Vorab handgerechnete Kontrollwerte bei RBS 1 = 563 EUR: vier Minderjährige mit
U7/U16-Konstellation 48 % = 270,24 EUR, fünf 60 % = 337,80 EUR, sechs auf
60 % = 337,80 EUR gekappt. Auch wenn zugleich die 36-Prozent-Alternative erfüllt ist,
wird der höhere zulässige Betrag angesetzt.

## Wohnkosten — Kosten der Unterkunft''')

# Tests: feste Geldwerte stammen aus der obigen Rechnung, nicht aus einem Produktaufruf.
unit = 'src/test/java/de/allgemein/lmg/calc/LeistungsberechnungTest.java'
edit(unit, 'void warmwasserAbzugVonHeizkostenNurBeiZentralemWarmwasser()', 'void zentraleWarmwasserkostenBleibenAuchMitAltemAbzugsparameterVollstaendigBedarf()')
edit(unit, '// zentrales Warmwasser (Flag aus): Heizung 100 EUR, örtlicher Anteil 10 % → −10 EUR', '// § 35 Abs. 5: zentrale Warmwasserkosten sind Heizbedarf. Altparameter 20 % ohne Kürzung.')
edit(unit, '''new Leistungsberechnung.KduParameter(new BigDecimal("0.10"), BigDecimal.ZERO));
        assertEquals(eur("10.00"), ergebnis.kduWarmwasserAbzug());
        assertEquals(eur("490.00"), ergebnis.kdu());''', '''new Leistungsberechnung.KduParameter(new BigDecimal("0.20"), BigDecimal.ZERO));
        assertEquals(eur("0.00"), ergebnis.kduWarmwasserAbzug());
        assertEquals(eur("500.00"), ergebnis.kdu());
        assertEquals(eur("1063.00"), ergebnis.zahlbetrag());
        assertEquals(eur("0.00"), ergebnis.mehrbedarfWarmwasser());''')
edit(unit, '    void alleinerziehendDeckel60ProzentDerRbs1()', '''    void alleinerziehendVergleichtBeiVierBisSechsKindernBeideAlternativen() {
        int[][] children = {{1, 2, 4}, {0, 3, 5}, {1, 3, 6}};
        String[] expected = {"270.24", "337.80", "337.80"};
        for (int i = 0; i < children.length; i++) {
            var c = children[i];
            var f = new SozialFall(1, 1, 1, false, false, c[0], c[1], c[2], false,
                    eur("0"), eur("0"), eur("0"), eur("0"), eur("0"),
                    eur("0"), eur("0"), eur("0"), eur("0"), 1);
            assertEquals(eur(expected[i]), Leistungsberechnung.berechneFall(f).mehrbedarfAlleinerziehend());
        }
    }

    @Test
    void alleinerziehendDeckel60ProzentDerRbs1()''')

jt = 'testsweet/src/test/java/de/allgemein/testsweet/LlmCalculationReferenceTest.java'
edit(jt, 'localHeatingDeductionAndSharedHouseholdLimitHaveHandComputedValues', 'legacyHeatingParameterDoesNotReduceCentralCostsAndSharedLimitStillApplies')
edit(jt, 'assertEquals("7.50",person(b,0).get("kdu_warmwasser_abzug"));', 'assertEquals("0.00",person(b,0).get("kdu_warmwasser_abzug"));')
edit(jt, 'assertEquals("492.50",person(b,0).get("kdu"));', 'assertEquals("500.00",person(b,0).get("kdu"));')
edit(jt, 'assertEquals("107.50",person(b,1).get("kdu"));', 'assertEquals("100.00",person(b,1).get("kdu"));')
edit(jt, '    private static Map<?,?> block(String text)', '''    @Test void fourFiveSixChildrenWithYoungChildrenUseMoreFavourableAlternative() {
        int[][] counts = {{1,2,4},{0,3,5},{1,3,6}};
        String[] single = {"270.24","337.80","337.80"};
        String[] payout = {"833.24","900.80","900.80"};
        for (int i = 0; i < counts.length; i++) {
            int[] c = counts[i];
            var p = person(block("block: Gold\\nzahlungsmonat = 2026-10\\nvermoegen = 0.00\\nschonvermoegen = 10000.00\\nbudget_start = -\\n"
                    + input(1,1,false,false,"-",c[0],c[1],c[2],false,"0","0","0","0","0","0")),0);
            assertEquals(single[i],p.get("mehrbedarf_alleinerziehend"));
            assertEquals(payout[i],p.get("zahlbetrag"));
        }
    }
    @Test void centralHotWaterHasNoAdditionalDeductionDespiteLegacyTwentyPercentParameter() {
        var p = person(block("block: Zentral\\nzahlungsmonat = 2026-10\\nvermoegen = 0.00\\nschonvermoegen = 10000.00\\nbudget_start = -\\nkdu_warmwasser_abzug_anteil = 0.20\\nkdu_bg_grenze = 0.00\\n"
                + input(1,1,false,false,"-",0,0,0,false,"400","0","100","0","0","0")),0);
        assertEquals("0.00",p.get("kdu_warmwasser_abzug"));
        assertEquals("0.00",p.get("mehrbedarf_warmwasser"));
        assertEquals("500.00",p.get("kdu"));
        assertEquals("1063.00",p.get("zahlbetrag"));
    }
    private static Map<?,?> block(String text)''')

coverage = 'testsweet/src/test/java/de/allgemein/testsweet/SzenarioAbdeckungTest.java'
edit(coverage, 'assertEquals("10.00",heating.kduWarmwasserAbzug().toPlainString());assertEquals("490.00",heating.kdu().toPlainString());', 'assertEquals("0.00",heating.kduWarmwasserAbzug().toPlainString());assertEquals("500.00",heating.kdu().toPlainString());\n        assertEquals("1063.00",heating.zahlbetrag().toPlainString());')
edit(coverage, '    @Test void kduServicesRemainImmutableAndSeparateAcrossParallelScenarioParameters()', '''    @Test void reparierteGrenzfaellePruefenJungeKinderUndFesteSqlSollwerteStattProduktSollwerte() {
        var cases = new SzenarioBibliothek(42).erzeuge(19);
        int[][] counts = {{1,2,4},{0,3,5},{1,3,6}};
        String[] expected = {"2822.24","3312.80","3750.80"};
        for (int i = 0; i < counts.length; i++) {
            var order = cases.get(12 + i);
            var parent = order.rechenbloecke.getFirst().faelle().getFirst();
            assertEquals(counts[i][0],parent.anzKinderUnter7());
            assertEquals(counts[i][1],parent.anzKinderUnter16());
            assertEquals(counts[i][2],parent.anzKinderMinderjaehrig());
            assertEquals(expected[i],order.rechenbloecke.getFirst().ergebnis().zahlbetrag().toPlainString());
            var sql = order.erwartungen.stream().filter(e -> e.sql().startsWith("SELECT AUSZAHLUNGSBETRAG")).findFirst().orElseThrow();
            assertEquals(expected[i],sql.erwartet());
        }
        var central = cases.get(16);
        assertEquals("0.20",central.rechenbloecke.getFirst().kduParameter().warmwasserAbzugHeizungProzent().toPlainString());
        assertEquals("1063.00",central.erwartungen.stream().filter(e -> e.sql().startsWith("SELECT AUSZAHLUNGSBETRAG")).findFirst().orElseThrow().erwartet());
    }

    @Test void kduServicesRemainImmutableAndSeparateAcrossParallelScenarioParameters()''')

pt = 'doc/testzertifikat-werkzeug/test_nachrechnen.py'
edit(pt, 'test_central_deduction_and_shared_limit', 'test_legacy_central_parameter_has_no_effect_and_shared_limit_still_applies')
edit(pt, 'self.assertEqual(D("7.50"), result["personen"][0]["kdu_warmwasser_abzug"])', 'self.assertEqual(D("0.00"), result["personen"][0]["kdu_warmwasser_abzug"])')
edit(pt, 'self.assertEqual(D("492.50"), result["personen"][0]["kdu"])', 'self.assertEqual(D("500.00"), result["personen"][0]["kdu"])')
edit(pt, 'self.assertEqual(D("107.50"), result["personen"][1]["kdu"])', 'self.assertEqual(D("100.00"), result["personen"][1]["kdu"])')
edit(pt, '    @staticmethod\n    def input', '''    def test_four_five_six_children_compare_both_alternatives(self):
        for u7, u16, minors, expected in [(1, 2, 4, "270.24"), (0, 3, 5, "337.80"), (1, 3, 6, "337.80")]:
            with self.subTest(children=(u7, u16, minors)):
                entry = self.input(1, 1).replace("kinder_u7=0, kinder_u16=0, kinder_minderjaehrig=0",
                        f"kinder_u7={u7}, kinder_u16={u16}, kinder_minderjaehrig={minors}")
                result = rechne_block("block: Gold\\nzahlungsmonat = 2026-10\\nvermoegen = 0.00\\nbudget_start = -\\n" + entry)
                self.assertEqual(D(expected), result["personen"][0]["mehrbedarf_alleinerziehend"])

    def test_central_twenty_percent_parameter_does_not_reduce_heating_need(self):
        result = rechne_block("block: Zentral\\nzahlungsmonat = 2026-10\\nvermoegen = 0.00\\nbudget_start = -\\nkdu_warmwasser_abzug_anteil = 0.20\\nkdu_bg_grenze = 0.00\\n" + self.input(1, 1))
        self.assertEqual(D("0.00"), result["personen"][0]["kdu_warmwasser_abzug"])
        self.assertEqual(D("1063.00"), result["zahl"])

    @staticmethod
    def input''')

manifest = []
for name, content in FILES.items():
    target = OUT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding='utf-8', newline='\r\n' if name.endswith('.java') else '\n')
    manifest.append({'path': name, 'sourceSha256': hashlib.sha256((ROOT / name).read_bytes()).hexdigest(), 'preparedSha256': hashlib.sha256(target.read_bytes()).hexdigest()})
(OUT.parent / 'prepared-manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print(f'{len(manifest)} Fachdateien nur im neuen Belegordner vorbereitet.')
