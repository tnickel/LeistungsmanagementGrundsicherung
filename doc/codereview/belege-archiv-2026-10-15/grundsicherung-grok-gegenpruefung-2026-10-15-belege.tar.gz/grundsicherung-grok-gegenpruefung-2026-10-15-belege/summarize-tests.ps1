$ErrorActionPreference = 'Stop'
$reviewRoot = (Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
$reviewChecks = @()
$reviewFingerprint = $null
foreach ($reviewName in @('main-db','main-config','testsweet-db')) {
    $reviewMarker = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot "$reviewName-test-evidence.json") | ConvertFrom-Json
    if ($reviewMarker.state -ne 'COMPLETED' -or !$reviewMarker.buildEvidence.sourceArtifactsMatch) {
        throw "Unvollständiger oder nicht buildgebundener Nachweis: $reviewName"
    }
    if ($reviewFingerprint -and $reviewFingerprint -ne $reviewMarker.sourceSha256) { throw 'Unterschiedliche Quellstände' }
    $reviewFingerprint = $reviewMarker.sourceSha256
    $reviewCounts = [ordered]@{tests=0; failures=0; errors=0; skipped=0}
    foreach ($reviewReport in $reviewMarker.reports) {
        $reviewPath = Join-Path $reviewRoot $reviewReport.path
        if ((Get-FileHash -LiteralPath $reviewPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $reviewReport.sha256) {
            throw 'XML-Beleg wurde verändert'
        }
        $reviewXml = [xml](Get-Content -Raw -LiteralPath $reviewPath)
        foreach ($reviewCount in @('tests','failures','errors','skipped')) {
            $reviewCounts[$reviewCount] += [int]$reviewXml.testsuite.$reviewCount
        }
    }
    $reviewChecks += [ordered]@{name=$reviewName; runId=$reviewMarker.runId;
        startedAt=$reviewMarker.startedAt; completedAt=$reviewMarker.completedAt;
        state=$reviewMarker.state; buildMatches=$reviewMarker.buildEvidence.sourceArtifactsMatch; counts=$reviewCounts}
}
$reviewDrift = @()
foreach ($reviewSource in $reviewMarker.sourceInventory) {
    $reviewPath = Join-Path $reviewRoot $reviewSource.path
    if (!(Test-Path -LiteralPath $reviewPath) -or
        (Get-FileHash -LiteralPath $reviewPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $reviewSource.sha256) {
        $reviewDrift += $reviewSource.path
    }
}
$reviewSteps = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'test-results.json') | ConvertFrom-Json
if ($reviewSteps.Count -ne 5 -or @($reviewSteps | Where-Object exitCode -ne 0).Count -ne 0) { throw 'Prüfschritte nicht vollständig erfolgreich' }
$reviewNodeLog = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'node-tests.log')
$reviewNode = [ordered]@{log='node-tests.log'}
foreach ($reviewField in @('tests','pass','fail','skipped')) {
    $reviewMatch = [regex]::Match($reviewNodeLog, ('(?m)^# {0} (\d+)\r?$' -f [regex]::Escape($reviewField)))
    if (!$reviewMatch.Success) { throw "Node-Zähler fehlt: $reviewField" }
    $reviewNode[$reviewField] = [int]$reviewMatch.Groups[1].Value
}
$reviewPythonLog = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'python-reference.log')
$reviewPythonMatch = [regex]::Match($reviewPythonLog, 'Ran (\d+) tests')
if (!$reviewPythonMatch.Success -or ![regex]::IsMatch($reviewPythonLog, '(?m)^OK\r?$')) { throw 'Python-Prüfung nicht vollständig erfolgreich' }
$reviewSummary = [ordered]@{sourceSha256=$reviewFingerprint;
    sourceFiles=$reviewMarker.sourceInventory.Count; sourceDrift=$reviewDrift; java=$reviewChecks;
    node=$reviewNode;
    python=[ordered]@{tests=[int]$reviewPythonMatch.Groups[1].Value; state='OK'; log='python-reference.log'};
    simulatorFullRuns='NOT_RUN'; glm='NOT_RUN'; overallCertificate='NOT_EXPORTED'}
$reviewSummary | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $PSScriptRoot 'verification-summary.json')
$reviewSummary | ConvertTo-Json -Depth 8
if ($reviewDrift.Count -ne 0) { throw 'Quellen nach Prüfung verändert' }
