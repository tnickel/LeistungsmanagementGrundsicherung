# Belege zur Grok-Gegenprüfung vom 15.10.2026

Zusammenführender Bericht: [Gegenprüfung](../grundsicherung-grok-gegenpruefung-2026-10-15.md).

`run-tests.ps1` führt beide Maven-Suiten, die separate Konfigurationsprüfung sowie
Node/Python aus. Die Oracle-Zugangsdaten kommen ausschließlich aus einer lokalen,
ignorierten Umgebungsdatei. `summarize-tests.ps1` prüft abgeschlossene Laufmarker,
identische Quellstände, Buildbindung, XML-Hashes und die aktuellen Quelldateien.
Die Zähler werden aus den tatsächlichen XML-Dateien bzw. Ausführungslogs gelesen.
`check-junit-reader.js` prüft beide Module mit dem produktiven Zertifikatsleser.

Die kompakten JSON-Laufmarker, Zusammenfassungen und Prüfskripte können versioniert
werden. Vollständige Maven-/Node-/Python-Logs, Surefire-XML und Buildausgaben bleiben
lokale Rohbelege. Der erste fehlgeschlagene Lauf ist gesondert erhalten; er wird nicht
als aktueller Erfolg übernommen. Die aufgeführten Laufdateien und Hashes beziehen
sich auf den tatsächlich ausgeführten lokalen Stand, nicht auf einen vollständig
in Git enthaltenen Rohdatenexport. Kein Gesamtzertifikat wurde exportiert.
