param([Parameter(Mandatory=$true)][string]$EnvironmentFile)
$ErrorActionPreference = 'Stop'
$reviewRoot = (Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
Set-Location -LiteralPath $reviewRoot
$reviewConnection = @{}
foreach ($reviewLine in Get-Content -LiteralPath $EnvironmentFile) {
    $reviewPair = $reviewLine.Split('=', 2)
    if ($reviewPair.Length -eq 2) { $reviewConnection[$reviewPair[0]] = $reviewPair[1] }
}
if ($reviewConnection['TX_USER'] -ne 'GROK_FIX_20261015') { throw 'Nur das eigene Fixschema verwenden.' }
foreach ($reviewKey in @('TX_URL','TX_USER','TX_PASS')) {
    [Environment]::SetEnvironmentVariable($reviewKey, $reviewConnection[$reviewKey], 'Process')
}
$reviewResults = @()
function Invoke-ReviewCheck([string]$Name, [scriptblock]$Action) {
    $reviewStart = [DateTimeOffset]::Now
    & $Action *> (Join-Path $PSScriptRoot "$Name.log")
    $reviewExit = $LASTEXITCODE
    $script:reviewResults += [ordered]@{name=$Name; startedAt=$reviewStart.ToString('o');
        finishedAt=[DateTimeOffset]::Now.ToString('o'); exitCode=$reviewExit; log="$Name.log"}
    $script:reviewResults | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $PSScriptRoot 'test-results.json')
    Write-Output "$Name exit=$reviewExit"
    if ($reviewExit -ne 0) { throw "Prüfung $Name fehlgeschlagen; vollständiges Log prüfen." }
}
Invoke-ReviewCheck 'main-install-db' { & mvn -B install '-Dstyle.color=never' }
Copy-Item -LiteralPath 'target/test-evidence.json' -Destination (Join-Path $PSScriptRoot 'main-db-test-evidence.json')
Remove-Item Env:TX_URL,Env:TX_USER,Env:TX_PASS
Invoke-ReviewCheck 'main-config-without-db' { & mvn -B '-Dtest=LmgConfigTest' test '-Dstyle.color=never' }
Copy-Item -LiteralPath 'target/test-evidence.json' -Destination (Join-Path $PSScriptRoot 'main-config-test-evidence.json')
foreach ($reviewKey in @('TX_URL','TX_USER','TX_PASS')) {
    [Environment]::SetEnvironmentVariable($reviewKey, $reviewConnection[$reviewKey], 'Process')
}
Invoke-ReviewCheck 'testsweet-db' { & mvn -B -f testsweet/pom.xml test '-Dstyle.color=never' }
Copy-Item -LiteralPath 'testsweet/target/test-evidence.json' -Destination (Join-Path $PSScriptRoot 'testsweet-db-test-evidence.json')
Invoke-ReviewCheck 'node-tests' {
    & node --test doc/testzertifikat-werkzeug/certificate-evidence.test.js doc/testzertifikat-werkzeug/llm-answer-parity.test.js doc/testzertifikat-werkzeug/llm-reference.test.js testsweet/src/test/js/llm-ui.test.js testsweet/src/test/js/produkt-ui-review.test.js
}
Invoke-ReviewCheck 'python-reference' { & python -m unittest discover -s doc/testzertifikat-werkzeug -p test_nachrechnen.py }
Write-Output 'Beide Java-Module, Konfiguration, Node- und Python-Prüfungen abgeschlossen.'
